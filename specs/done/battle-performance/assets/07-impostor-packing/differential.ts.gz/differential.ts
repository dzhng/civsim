// Scratch: bit-for-bit differential between the pre-edit packer (orig.ts) and
// the rewritten one over randomized crowds. Throwaway.
import { packImpostors as next } from "../../packages/battle-renderer/src/impostorData";
import { packImpostors as prev } from "./orig";
import type { CrowdInstance } from "../../packages/crowd-runtime/src/instanceData";

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
}
const next01 = rng(20260920);
const span = (lo: number, hi: number) => lo + next01() * (hi - lo);

let mismatch = 0;
let records = 0;
for (let trial = 0; trial < 60; trial++) {
  const atlas = {
    columns: trial % 3 === 0 ? 4 : 8,
    rows: trial % 5 === 0 ? 6 : 8,
    tileSize: 96,
    center: [span(-1, 1), span(-1, 1), span(0, 2)] as [number, number, number],
    worldSpan: span(0.5, 6),
  };
  const view = {
    right: [1, 0, 0] as [number, number, number],
    up: [0, 0, 1] as [number, number, number],
    eye: [span(-200, 200), span(-200, 200), span(-50, 300)] as [number, number, number],
    fovY: trial % 7 === 0 ? 0 : span(0.05, 1.5),
  };
  const instances: CrowdInstance[] = [];
  for (let i = 0; i < 400; i++) {
    const alive = next01() < 0.6;
    instances.push({
      // Include exact eye coincidence and huge distances.
      x: i === 0 ? view.eye[0] : span(-2000, 2000),
      y: i === 0 ? view.eye[1] : span(-2000, 2000),
      facing: span(-12, 12),
      classId: 0,
      faction: (i % 3) as 0 | 1 | 2,
      alive,
      clip: "idle",
      phase: 0,
      seed: i,
      mounted: false,
      lod: 3,
      ...(i === 0 ? { elevation: view.eye[2] } : next01() < 0.2 ? {} : { elevation: span(-20, 60) }),
      ...(alive || next01() < 0.3
        ? {}
        : {
            playback: {
              appearanceId: 0,
              base: {
                source: { kind: "clip" as const, sample: { clip: "idle", phase: 0 } },
                destination: { clip: "death", phase: span(0, 1) },
                weight: span(0, 1),
              },
            },
          }),
    });
  }
  const a = new Uint8Array(prev(atlas, instances, view).buffer);
  const b = new Uint8Array(next(atlas, instances, view).buffer);
  if (a.length !== b.length) throw new Error(`length ${a.length} vs ${b.length}`);
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) mismatch++;
  records += instances.length;
}
// Empty and single-instance edges.
for (const count of [0, 1]) {
  const instances = Array.from({ length: count }, () => ({
    x: 1, y: 2, facing: 0.3, classId: 0, faction: 0 as const, alive: true,
    clip: "idle", phase: 0, seed: 0, mounted: false, lod: 3,
  }));
  const view = { right: [1,0,0] as [number,number,number], up: [0,0,1] as [number,number,number], eye: [0,-10,5] as [number,number,number], fovY: 0.8 };
  const atlas = { columns: 8, rows: 8, tileSize: 96, center: [0.1,0.2,0.9] as [number,number,number], worldSpan: 2 };
  const a = prev(atlas, instances, view), b = next(atlas, instances, view);
  if (a.length !== b.length) throw new Error("edge length");
  for (let i = 0; i < a.length; i++) if (!Object.is(a[i], b[i])) mismatch++;
}
console.log(`records=${records} mismatched bytes=${mismatch}`);
