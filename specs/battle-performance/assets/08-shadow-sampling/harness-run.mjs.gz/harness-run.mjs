import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn,execFileSync} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
const root=process.cwd(),out=root+'/throwaway/shadow-sampling-review/timing';await mkdir(out,{recursive:true});
const runs=[];
for(const [run,arm] of ['control','candidate','candidate','control'].entries()){
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config','apps/battle-perf-lab/src/live/vite.config.mts','--outDir',root+'/throwaway/shadow-sampling-review/'+arm,'--port','5298','--strictPort'],{env:{...process.env,BATTLE_NATIVE_BACKEND:'raw'},stdio:['ignore','pipe','pipe']});let log='',browser;server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
 try{
 await new Promise((resolve,reject)=>{const start=Date.now(),timer=setInterval(()=>{if(log.includes('Local:')){clearInterval(timer);resolve();}else if(server.exitCode!==null||Date.now()-start>30000){clearInterval(timer);reject(Error(log));}},100);});
 await writeFile(out+'/'+run+'-processes.txt',execFileSync('ps',['-axo','pid,pcpu,comm']));
 browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});
 for(const pose of ['tactical','horizon']){
 const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:2}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://localhost:5298/?map=A&ai=off&shadows=single');await page.waitForFunction(()=>window.__ready===true,undefined,{timeout:120000});await page.evaluate(()=>window.__game.freezeAtTick(30));await page.waitForFunction(()=>window.__game.frameMetrics()?.renderer.skippedFrozenFrame===true);
 const result=await page.evaluate(async(pose)=>{
 const api=window.__game,events=[],samples=[];let cursor=window.__sampleGpuEvents(0).nextSequence,gaps=0;
 const collect=()=>{const r=window.__sampleGpuEvents(cursor);if(!r)throw Error('No timestamps');if(r.cursorGap)gaps++;cursor=r.nextSequence;events.push(...r.events);};
 for(let i=0;i<240;i++){
 const old=api.frameMetrics().renderer.renderedFrameId;const x=20+Math.sin(i/30)*30;
 api.setCamera(x,-625,pose==='tactical'?7.884923:6.8,-Math.PI/2,pose==='tactical'?.4526155:.12);
 const began=performance.now();
 while(true){await new Promise(requestAnimationFrame);collect();const m=api.frameMetrics()?.renderer;if(m?.renderedFrameId>old&&m.skippedFrozenFrame){samples.push({i,warmup:i<60,identity:m.gpuSubmission,camera:api.stats().renderStats.native.camera});break;}if(performance.now()-began>10000)throw Error('Camera submission stalled');}
 }
 for(let i=0;i<10;i++){await new Promise(requestAnimationFrame);collect();}
 return {pose,tick:api.tickCount(),hash:api.stateHash(),gaps,samples,events,stats:api.stats().renderStats};
 },pose);
 const data={run,arm,errors,...result};runs.push(data);await writeFile(out+'/'+run+'-'+arm+'-'+pose+'.json',JSON.stringify(data));console.log(run,arm,pose,result.samples.length,result.events.length,result.gaps,errors);await page.close();
 }
 }finally{await browser?.close();server.kill('SIGTERM');await new Promise(resolve=>server.exitCode!==null?resolve():server.once('exit',resolve));await writeFile(out+'/'+run+'-server.log',log);}
}
await writeFile(out+'/manifest.json',JSON.stringify({scope:'Frozen tick30 deterministic camera steps; GPU per-submission cost only, not live FPS/input latency. ABBA predeclared. Both candidate medians must beat both controls per pose; incomplete joins fail. External busy host disallows final acceptance.',runs:runs.map(({run,arm,pose,errors,tick,hash,gaps})=>({run,arm,pose,errors,tick,hash,gaps}))},null,2));
if(runs.some(r=>r.errors.length||r.gaps||r.hash!=='15927906182668164452'))process.exitCode=1;
