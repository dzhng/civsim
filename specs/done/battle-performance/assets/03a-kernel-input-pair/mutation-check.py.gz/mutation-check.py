from pathlib import Path
import subprocess,os,json
root=Path('/Users/david/dev/game-battle-target-live-inputs');out=Path('/Users/david/dev/game-battle-performance-spec/throwaway/kernel-input-pair')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='1';results=[]
cases=[('no-live-friend-flag','crates/sim/src/combat.rs','fighting: fighting[self.owner as usize] == 1,','fighting: false,',['--lib','a_comrade_who_entered_the_fight_earlier_in_this_pass_blocks_the_frontage_behind_him']),('stale-unit-facing','crates/sim/src/separation/mod.rs','    unit_aim.clear();\n    unit_aim.extend(units.iter().map(|u| crate::math::dir(u.facing)));','    if unit_aim.len() != units.len() {\n        unit_aim.clear();\n        unit_aim.extend(units.iter().map(|u| crate::math::dir(u.facing)));\n    }',['--test','mechanics_impact','a_wheeling_charge_delivers_its_shock_along_the_heading_it_rides'])]
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root).strip()
for name,path,old,new,args in cases:
 p=root/path;original=p.read_bytes();s=original.decode();assert s.count(old)==1
 try:
  p.write_text(s.replace(old,new))
  with (out/f'{name}-red.log').open('x') as log:
   r=subprocess.run(['cargo','test','-p','sim',*args,'--','--nocapture'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  evidence=(out/f'{name}-red.log').read_text();assert r.returncode!=0 and 'test result: FAILED' in evidence,(name,r.returncode)
  results.append({'mutation':name,'exitCode':r.returncode,'failedBehavioralTest':True});print(name,'failed as intended',flush=True)
 finally:p.write_bytes(original)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root).strip()
(out/'mutation-outcomes.json').write_text(json.dumps(results,indent=2)+'\n')
print('RESTORED all tracked candidate files',flush=True)
