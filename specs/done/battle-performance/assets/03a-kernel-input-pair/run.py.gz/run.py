from pathlib import Path
import subprocess,json
root=Path('/Users/david/dev/game-battle-performance-spec');out=root/'throwaway/kernel-input-pair';reports=out/'runs'
reports.mkdir(exist_ok=False)
results=[]
for index,arm in enumerate(['control','candidate','candidate','control']):
 report=reports/f'{index}-{arm}.json'
 with (reports/f'{index}-{arm}.log').open('x') as log:
  result=subprocess.run(['node',str(out/'kernel-window.mjs'),str(root),str(report),str(out/arm),arm,str(index//2)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(index=index,arm=arm,exitCode=result.returncode));(reports/'outcomes.json').write_text(json.dumps(results,indent=2)+'\n');print('END',index,arm,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
