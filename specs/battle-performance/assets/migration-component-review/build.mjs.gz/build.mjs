import {build} from '../../web/node_modules/vite/dist/node/index.js';
const root=process.cwd();
for(const [name,config] of [['water','src/raw/water.vite.config.mts'],['post','candidates/raw-post/post.vite.config.mts']]) await build({configFile:root+'/apps/battle-perf-lab/'+config,build:{outDir:root+'/throwaway/migration-component-review/'+name,copyPublicDir:false}});
