import { SingleShadowPolicy, ShadowFitStabilizer, viewShadowFit, SINGLE_MAP_SIZE } from '../../packages/game-renderer/src/battle/shadowPolicy';
import { CIVSIM_ENVIRONMENTS } from '../../packages/game-renderer/src/environment/environment';
import { photorealEnvironment } from '../../packages/game-renderer/src/environment/physicalEnvironment';
const sun=photorealEnvironment(CIVSIM_ENVIRONMENTS.golden).sunDirection;
const rect:[number,number,number,number]=[-1200,-800,2400,1600];
const elevation:[number,number]=[-3,12];
const policy=new SingleShadowPolicy(sun), stabilizer=new ShadowFitStabilizer();policy.setWorldRect(rect,elevation);
const observations=[];
for(let i=0;i<256;i++){
 const camera={target:[i*.001,i*.001,0] as [number,number,number],distance:160,pitch:.5,yaw:-Math.PI/2,fovY:.85,aspect:1.6,near:1};
 const revision=policy.refits;policy.update(camera);
 const fresh=viewShadowFit({camera,rect,elevation,unitSunDirection:sun,mapSize:SINGLE_MAP_SIZE,stabilizer});
 const held=policy.fit;
 if(policy.refits===revision && held.crowdNear!==fresh.crowdNear){
  observations.push({i,camera,revision,mapEqual:held.extent===fresh.extent&&held.near===fresh.near&&held.far===fresh.far&&held.position.every((v,k)=>v===fresh.position[k]),heldCrowdNear:held.crowdNear,freshCrowdNear:fresh.crowdNear,delta:fresh.crowdNear-held.crowdNear});
  if(observations.length===3)break;
 }
}
console.log(JSON.stringify({scope:'Synthetic CPU fit identity, not the observed88 cause or missing-caster proof',observations},null,2));
