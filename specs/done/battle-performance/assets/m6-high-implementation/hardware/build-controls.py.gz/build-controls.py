from pathlib import Path
import subprocess,os,json
root=Path.cwd();out=root/'throwaway/high-shadow-review/builds';out.mkdir(exist_ok=True)
assert not any(out.iterdir())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=root).strip()
cases={'menu':'apps/battle-perf-lab/src/live/vite.config.mts',**{n:f'apps/battle-perf-lab/src/raw/{c}.vite.config.mts' for n,c in [('shadow','shadow'),('frame','frame'),('scene','scene'),('terrain','terrainScene'),('lifecycle','frame-lifecycle')]}}
records=[]
for name,config in cases.items():
 env={**os.environ,'BATTLE_NATIVE_BACKEND':'raw'};env.pop('BATTLE_NATIVE_ATLAS_CATALOG',None)
 cmd=[str(root/'web/node_modules/.bin/vite'),'build','--config',config,'--outDir',str(out/name)]
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'head':head,'command':cmd,'exit':r.returncode,'atlasOverride':False});(out/'builds.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 for p in (root/'web/public').iterdir():
  target=out/name/p.name
  if not target.exists():target.symlink_to(p,target_is_directory=p.is_dir())
  elif p.is_dir():
   for asset in p.iterdir():
    t=target/asset.name
    if not t.exists():t.symlink_to(asset,target_is_directory=asset.is_dir())
 if name=='scene':(out/name/'battle-atlas').symlink_to(root/'web/public/assets/soldiers/impostors',target_is_directory=True)
