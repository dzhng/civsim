from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/Users/david/dev/game-battle-native-target-preparation');out=Path('/Users/david/dev/game-battle-performance-spec/throwaway/native-target-review')
run=root/'crates/sim/src/combat/run.rs';combat=root/'crates/sim/src/combat.rs'
cases=[('position-guard',run,'live.x.to_bits() == scanned_at.x.to_bits() && live.y.to_bits() == scanned_at.y.to_bits()','true','the_batched_preparation_walks_the_serial_trajectory_bit_for_bit'),('later-batch',run,'start += 3 * BATCH;','start = n;','ordered_completion_matches_across_multiple_target_batches'),('live-fighting',combat,'fighting: fighting[self.owner as usize] == 1,','fighting: false,','a_comrade_who_entered_the_fight_earlier_in_this_pass_blocks_the_frontage_behind_him')]
results=[]
for name,path,old,new,test in cases:
 original=path.read_bytes();text=original.decode();assert text.count(old)==1
 try:
  path.write_text(text.replace(old,new,1))
  command=['cargo','test','-p','sim','--features','parallel','--lib',test]
  r=subprocess.run(command,cwd=root,env={**os.environ,'CARGO_BUILD_JOBS':'1'},capture_output=True,text=True)
  log=r.stdout+r.stderr;(out/(name+'-red.log')).write_text(log)
  assert r.returncode!=0 and 'test result: FAILED' in log and test in log,(name,r.returncode,log[-500:])
 finally:path.write_bytes(original)
 assert path.read_bytes()==original
 results.append({'mutation':name,'test':test,'exit':r.returncode,'restoredSha256':hashlib.sha256(original).hexdigest()});print(results[-1],flush=True)
(out/'root-mutations.json').write_text(json.dumps(results,indent=2)+'\n')
for flags,name in [(['--features','parallel'],'parallel'),([], 'serial')]:
 command=['cargo','test','-p','sim',*flags,'--lib']
 r=subprocess.run(command,cwd=root,env={**os.environ,'CARGO_BUILD_JOBS':'1'},capture_output=True,text=True);(out/(name+'-restored-green.log')).write_text(r.stdout+r.stderr)
 print(name,r.returncode,flush=True);assert r.returncode==0
