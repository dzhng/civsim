// Scratch: dump the CURRENT packImpostors output for the golden scene so the
// test can pin bytes captured before any edit. Throwaway; not part of the app.
import { packImpostors, type ImpostorView } from "../../packages/battle-renderer/src/impostorData";
import type { CrowdInstance } from "../../packages/crowd-runtime/src/instanceData";
import type { SoldierPlayback } from "../../packages/crowd-runtime/src/actionTimeline";

const atlas = {
  columns: 8,
  rows: 8,
  tileSize: 96,
  center: [0.1875, -0.0625, 0.9375] as const,
  worldSpan: 2.5,
};

const corpse = (weight: number): SoldierPlayback => ({
  appearanceId: 0,
  base: {
    source: { kind: "clip", sample: { clip: "idle", phase: 0 } },
    destination: { clip: "death", phase: 0.8 },
    weight,
  },
});

const soldier = (over: Partial<CrowdInstance>): CrowdInstance => ({
  x: 0,
  y: 0,
  facing: 0,
  classId: 0,
  faction: 0,
  alive: true,
  clip: "idle",
  phase: 0,
  seed: 1,
  mounted: false,
  lod: 3,
  ...over,
});

const scene: CrowdInstance[] = [
  soldier({ x: -6, y: 2, facing: 0, elevation: 0.5, faction: 0 }),
  soldier({ x: 3, y: -4, facing: Math.PI / 2, faction: 1 }),
  soldier({ x: 0, y: 0, facing: Math.PI, elevation: -1.25, faction: 2 }),
  soldier({ x: 8, y: 9, facing: 4.2, elevation: 0.1, faction: 1, alive: false, playback: corpse(0.5) }),
  soldier({ x: -15, y: -12, facing: 2.6, elevation: 0, faction: 0, alive: false }),
  soldier({ x: 400, y: -900, facing: 5.5, elevation: 3, faction: 2 }),
  soldier({ x: 0.2, y: 0.1, facing: 0.7, elevation: 20.9, faction: 0, alive: false, playback: corpse(0) }),
  soldier({ x: 1, y: -2, facing: -2.1, elevation: 26, faction: 1 }),
];

const view: ImpostorView = {
  right: [1, 0, 0],
  up: [0, 0, 1],
  eye: [12, -34, 21],
  fovY: 0.9,
};

const packed = packImpostors(atlas, scene, view);
const rows: string[] = [];
for (let i = 0; i < scene.length; i++) {
  const r = Array.from(packed.subarray(i * 12, i * 12 + 12));
  rows.push(`  ${r.map((v) => String(v)).join(", ")},`);
}
console.log("[\n" + rows.join("\n") + "\n]");
