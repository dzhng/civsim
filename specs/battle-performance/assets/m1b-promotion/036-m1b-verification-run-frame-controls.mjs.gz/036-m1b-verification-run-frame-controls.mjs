import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
const root=process.cwd(),dir=root+'/throwaway/m1b-verification/frame-controls';await mkdir(dir,{recursive:true});
const results=[];
for(const [name,config,artifact,pageName,key] of [
 ['frame','frame','frame','frame-check.html','__frameCheck'],
 ['lifecycle','frame-lifecycle','lifecycle','frame-lifecycle-check.html','__frameLifecycle']]) {
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config',`apps/battle-perf-lab/src/raw/${config}.vite.config.mts`,'--outDir',root+`/throwaway/m1b-verification/promoted/${artifact}`,'--port','5298','--strictPort'],{stdio:['ignore','pipe','pipe']});
 let log='';server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);let browser;
 try {
  await new Promise((resolve,reject)=>{const begin=Date.now();const timer=setInterval(()=>{if(log.includes('Local:')){clearInterval(timer);resolve();}else if(server.exitCode!==null||Date.now()-begin>30000){clearInterval(timer);reject(Error(log));}},100);});
  browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});
  for(const samples of name==='frame'?[1,4]:[null]) {
   const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(['warning','error'].includes(m.type()))errors.push(m.text());});
   const url=`http://localhost:5298/${pageName}`+(samples?`?backend=raw&samples=${samples}&shadows=1&scenery=1`:'');
   await page.goto(url);await page.waitForFunction(key=>window[key]!==undefined,key,{timeout:120000});
   const report=await page.evaluate(key=>window[key],key);const record={name,samples,url,errors,report,scope:'hardware correctness; no performance conclusion'};
   await writeFile(`${dir}/${name}-${samples??'all'}.json`,JSON.stringify(record,null,2)+'\n');results.push({name,samples,passed:report.passed===true&&errors.length===0});console.log(results.at(-1));await page.close();
  }
 } finally {await browser?.close();server.kill('SIGTERM');await writeFile(`${dir}/${name}-preview.log`,log);await new Promise(resolve=>server.exitCode!==null?resolve():server.once('exit',resolve));}
}
await writeFile(dir+'/outcomes.json',JSON.stringify(results,null,2)+'\n');if(results.some(r=>!r.passed))process.exitCode=1;
