# Lifecycle fixture repair

Five existing tests fail during ready(), before reaching their assertions,
because the mocked crowd no longer implements reproject. The production method
returns whether a camera change needs new pose work. The fixture's empty audience
and unchanged camera should return false. Add that method and clarify the existing
pose test's name to state unchanged demand. No expectation or production code
changes; all14 tests across5 TypeGPU files pass. No render or timing claim follows.
