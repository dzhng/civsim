from pathlib import Path
import subprocess,os,hashlib,json
main=Path('/Users/david/dev/game-battle-performance-spec')
worker=Path('/Users/david/dev/game-battle-target-live-inputs')
out=main/'throwaway/kernel-input-pair'
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(main/'target'),CARGO_PROFILE_RELEASE_LTO='fat',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1',RUSTFLAGS='-C target-feature=+simd128')
records=[]
for arm,root in [('control',main),('candidate',worker)]:
 target=out/arm
 if target.exists():raise RuntimeError('Existing immutable build: '+str(target))
 subprocess.run(['git','diff','HEAD','--exit-code'],cwd=root,check=True,stdout=subprocess.DEVNULL)
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 with (out/f'{arm}-build.log').open('x') as log:
  subprocess.run(['wasm-pack','build','crates/game-wasm','--target','web','--release','--out-dir',str(target)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 digest=hashlib.sha256((target/'game_wasm_bg.wasm').read_bytes()).hexdigest()
 if arm=='control':assert digest=='b42782f4d67ff8b2efca21978166267e500111102f233b68af06e1f9f5f365e1',digest
 records.append(dict(arm=arm,root=str(root),commit=commit,sha256=digest))
 (out/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
 print(arm,digest,flush=True)
