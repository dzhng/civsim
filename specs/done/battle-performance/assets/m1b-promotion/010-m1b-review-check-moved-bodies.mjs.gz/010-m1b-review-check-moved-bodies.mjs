import ts from '../../web/node_modules/typescript/lib/typescript.js';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const commit='2c8eaad0';
const rows=execFileSync('git',['diff',`${commit}^`,commit,'--name-status','-M'],{encoding:'utf8'}).trim().split('\n').map(l=>l.split('\t')).filter(r=>r[0].startsWith('R')&&r[1].endsWith('.ts'));
rows.push(['manual','apps/battle-perf-lab/src/sceneTypes.ts','packages/battle-renderer/src/sceneTypes.ts']);
function body(rev,path){const text=execFileSync('git',['show',`${rev}:${path}`],{encoding:'utf8'});const file=ts.createSourceFile('module.ts',text,ts.ScriptTarget.Latest,true);const changed=ts.factory.updateSourceFile(file,file.statements.filter(s=>!ts.isImportDeclaration(s)));return ts.createPrinter({removeComments:true}).printFile(changed);}
const results=rows.map(([,oldPath,newPath])=>({oldPath,newPath,equalNonImportStatements:body(`${commit}^`,oldPath)===body(commit,newPath)}));
writeFileSync('throwaway/m1b-review/moved-bodies.json',JSON.stringify(results,null,2)+'\n');
console.log({modules:results.length,unexpected:results.filter(r=>!r.equalNonImportStatements)});
