from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/Users/david/dev/game-battle-performance-spec')
out=root/'throwaway/m1b-verification/promoted'
out.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
cases={'menu':'apps/battle-perf-lab/src/live/vite.config.mts','scene':'apps/battle-perf-lab/src/raw/scene.vite.config.mts','frame':'apps/battle-perf-lab/src/raw/frame.vite.config.mts','lifecycle':'apps/battle-perf-lab/src/raw/frame-lifecycle.vite.config.mts','pose':'apps/battle-perf-lab/src/raw/pose.vite.config.mts'}
records=[]
for name,config in cases.items():
 env={**os.environ,'BATTLE_NATIVE_BACKEND':'raw','BATTLE_NATIVE_ATLAS_CATALOG':'/battle-atlas/catalog.json'}
 cmd=[str(root/'web/node_modules/.bin/vite'),'build','--config',config,'--outDir',str(out/name)]
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'case':name,'command':cmd,'exit':r.returncode,'head':head,'environment':{k:env[k] for k in ['BATTLE_NATIVE_BACKEND','BATTLE_NATIVE_ATLAS_CATALOG']}}
 records.append(rec);(out/'builds.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 # Public content is borrowed, independently fingerprinted below; no duplicate assets.
 dest=out/name
 for child in (root/'web/public').iterdir():
  target=dest/child.name
  if not target.exists():target.symlink_to(child,target_is_directory=child.is_dir())
  elif child.is_dir():
   for asset in child.iterdir():
    sub=target/asset.name
    if not sub.exists():sub.symlink_to(asset,target_is_directory=asset.is_dir())
 (dest/'battle-atlas').symlink_to(root/'specs/battle-performance/assets/02-full-atlas',target_is_directory=True)
manifest=[]
for area in [root/'web/public',root/'specs/battle-performance/assets/02-full-atlas']:
 for p in sorted(area.rglob('*')):
  if p.is_file():manifest.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'borrowed-assets.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in cases:
 files=[{'path':str(p.relative_to(out/name)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((out/name).rglob('*')) if p.is_file() and not p.is_symlink()]
 (out/(name+'-files.json')).write_text(json.dumps(files,indent=2)+'\n')
print('COMPLETE',head,flush=True)
