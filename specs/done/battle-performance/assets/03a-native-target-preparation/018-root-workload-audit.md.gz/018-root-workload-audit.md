# Native probe scope

The existing file is crates/sim/src/bin/profile_tick.rs (not examples/).
Its fighting mode uses Sim seed7 and MapRecipe seed7, enables AI for both teams,
optionally spawns 500-person heavy-sword units to reach a population target,
waits for contact then60 ticks and an optional earliest tick, and measures300
Battle::tick calls twice. Its default mode also uses the supplied seed for Sim.

The canonical WASM driver instead uses Game seed0x5eedc0de, generated map seed7,
AI team1 only, initial nearest-enemy attack orders for team0, and windows
9001..9308/12001..12308. Game.advance_ticks includes export refresh. Thus the
existing native fighting command is a different workload and cannot reuse the
five canonical hash values, the browser30k floor, or the existing35ms native
threshold as an acceptance criterion. Native comparisons must hold their own
setup, commands, source/artifact and thread configuration constant. Native
relative speed can justify a separately researched WASM feasibility step only.
