import {PNG} from '../../web/node_modules/pngjs/lib/png.js';
import {readFile,writeFile} from 'node:fs/promises';
const base='throwaway/m1b-verification/';const images=[];
for(const folder of ['reference-scene','promoted-scene','reference-repeat-scene'])images.push(PNG.sync.read(await readFile(base+folder+'/tactical-initial-actual.png')));
const points=[];
for(let i=0;i<images[0].data.length;i+=4){const a=[...images[0].data.subarray(i,i+4)],b=[...images[1].data.subarray(i,i+4)],c=[...images[2].data.subarray(i,i+4)];if(a.some((v,k)=>v!==b[k]||v!==c[k]))points.push({x:(i/4)%images[0].width,y:Math.floor(i/4/images[0].width),reference:a,promoted:b,repeat:c});}
await writeFile(base+'initial-difference-pixels.json',JSON.stringify(points,null,2)+'\n');console.log({count:points.length,box:[Math.min(...points.map(p=>p.x)),Math.min(...points.map(p=>p.y)),Math.max(...points.map(p=>p.x)),Math.max(...points.map(p=>p.y))],first:points.slice(0,10)});
