/** Differential oracle for the crowd-ownership slice.
 *
 * Baseline (recorded against the code BEFORE the change): the retained records the
 * live facade actually admitted are `capture(buildCrowdInstances(columns, pool))`
 * — a caller-owned intermediate pool copied into the snapshot's pool. The slice
 * makes the snapshot build those records straight from the columns. This file
 * pins the baseline as a structural encoding (see `encode.ts`: slot reuse, blend
 * aliasing, frozen-array identity, absent-vs-undefined optionals) and, once
 * `CrowdFrameSnapshot.build` exists, asserts the single-owner path reproduces it
 * exactly over a sequence that shrinks, regrows, empties and changes pose shape.
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { expect, test } from "vitest";
import {
  buildCrowdInstances,
  type CrowdBuildInputs,
  type CrowdInstance,
} from "../../packages/crowd-runtime/src/instanceData";
import { CrowdFrameSnapshot } from "../../packages/crowd-runtime/src/frameSnapshot";
import { bareFrame, frame, MOUNTED_CLASSES, type Frame } from "./columns";
import { encode, IdentityRegistry } from "./encode";

const BASELINE = new URL("./baseline.json", import.meta.url);

/** Everything the caller still owns after a submission: the typed columns the
 *  frontend refills and the playback objects its timeline mutates in place. */
function mutateCallerState(f: Frame) {
  const { positions, facings, alive } = f.inputs;
  for (let i = 0; i < positions.length; i++) positions[i] = -positions[i] - 7;
  if (facings) for (let i = 0; i < facings.length; i++) facings[i] = facings[i] + 1.5;
  if (alive) for (let i = 0; i < alive.length; i++) alive[i] = alive[i] ? 0 : 1;
  for (const [i, playback] of f.playback.entries()) {
    playback.appearanceId += 100;
    playback.base.weight = 0.0625;
    playback.base.destination.clip = "mutated";
    playback.base.destination.phase = 0.999;
    if (playback.base.source.kind === "clip") {
      playback.base.source.sample.clip = "mutated-source";
      playback.base.source.sample.phase = 0.111;
    }
    if (playback.riderUpperBody) {
      if (i % 2) delete playback.riderUpperBody;
      else playback.riderUpperBody.weight = 0.0078125;
    } else if (i % 3 === 0) {
      playback.riderUpperBody = {
        source: { kind: "clip", sample: { clip: "late", phase: 0.4 } },
        destination: { kind: "base" },
        weight: 1,
      };
    }
  }
}

function sequence(): Frame[] {
  const dropped = frame("overlay-dropped", 12, 8, 3);
  for (const playback of dropped.playback) delete playback.riderUpperBody;
  return [
    frame("wide", 12, 1),
    frame("moved", 12, 2),
    frame("reshaped", 12, 3, 2),
    bareFrame("bare-optionals", 12, 4),
    dropped,
    frame("shrunk", 4, 5),
    frame("regrown", 17, 6),
    frame("empty", 0, 7),
    frame("after-empty", 5, 9),
  ];
}

function run(submit: (inputs: CrowdBuildInputs) => readonly CrowdInstance[]) {
  const registry = new IdentityRegistry();
  const log: unknown[] = [];
  for (const f of sequence()) {
    const records = submit(f.inputs);
    log.push({ label: f.label, records: encode(records, registry) });
    mutateCallerState(f);
    log.push({ label: `${f.label}:after-caller-mutation`, records: encode(records, registry) });
  }
  return log;
}

/** The pre-change production path: the facade's own instance pool, copied into
 *  the audience's frame snapshot at admission. */
function admittedBefore() {
  const pool: CrowdInstance[] = [];
  const snapshot = new CrowdFrameSnapshot();
  return run((inputs) => snapshot.capture(buildCrowdInstances(inputs, pool).instances));
}

test("the recorded baseline is the pre-change admitted record set", () => {
  const observed = admittedBefore();
  if (!existsSync(BASELINE)) {
    writeFileSync(BASELINE, JSON.stringify(observed, null, 1));
    throw new Error("Baseline recorded; re-run to compare against it");
  }
  expect(observed).toEqual(JSON.parse(readFileSync(BASELINE, "utf8")));
});

const snapshotBuild = (
  CrowdFrameSnapshot.prototype as CrowdFrameSnapshot & {
    build?: (inputs: CrowdBuildInputs) => CrowdInstance[];
  }
).build;

test.skipIf(!snapshotBuild)("one owner builds the same records straight from the columns", () => {
  const snapshot = new CrowdFrameSnapshot() as CrowdFrameSnapshot & {
    build(inputs: CrowdBuildInputs): CrowdInstance[];
  };
  const observed = run((inputs) => snapshot.build(inputs));
  expect(observed).toEqual(admittedBefore());
  expect(observed).toEqual(JSON.parse(readFileSync(BASELINE, "utf8")));
});

test.skipIf(!snapshotBuild)("a cached mounted-class set matches the per-frame array form", () => {
  const cached = new CrowdFrameSnapshot() as CrowdFrameSnapshot & {
    build(inputs: CrowdBuildInputs): CrowdInstance[];
  };
  const listed = new CrowdFrameSnapshot() as CrowdFrameSnapshot & {
    build(inputs: CrowdBuildInputs): CrowdInstance[];
  };
  const f = frame("mounted", 9, 13);
  const set = new Set(MOUNTED_CLASSES);
  expect(encode(cached.build({ ...f.inputs, mountedClasses: set }), new IdentityRegistry())).toEqual(
    encode(listed.build({ ...f.inputs, mountedClasses: MOUNTED_CLASSES }), new IdentityRegistry()),
  );
  expect([...f.playback].some((_, i) => cached.instances[i].mounted)).toBe(true);
});

test.skipIf(!snapshotBuild)("a count mismatch is refused before anything is admitted", () => {
  const snapshot = new CrowdFrameSnapshot() as CrowdFrameSnapshot & {
    build(inputs: CrowdBuildInputs): CrowdInstance[];
  };
  const good = frame("good", 6, 11);
  snapshot.build(good.inputs);
  const before = encode(snapshot.instances, new IdentityRegistry());
  expect(() =>
    snapshot.build({ ...good.inputs, playback: good.playback.slice(0, 3) }),
  ).toThrow("Playback count");
  expect(encode(snapshot.instances, new IdentityRegistry())).toEqual(before);
});
