import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import os from 'node:os';
const source = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const wasmDirectory = resolve(process.argv[4]);
const arm = process.argv[5];
const pair = Number(process.argv[6]);
const hostBefore = { utc: new Date().toISOString(), loadAverage: os.loadavg() };
const hashBytes = value => createHash('sha256').update(value).digest('hex');
const { default: init, Game } = await import(pathToFileURL(`${wasmDirectory}/game_wasm.js`));
const { UNIT_INFO: U } = await import(pathToFileURL(`${source}/packages/game-renderer/src/battle/unitInfoLayout.ts`));
const bytes = await readFile(`${wasmDirectory}/game_wasm_bg.wasm`);
const wasm = await init({module_or_path:bytes});
const g = new Game(0x5eedc0de);
g.start_battle_generated(7n); g.set_ai_team(1);
const stride = g.unit_info_stride();
const view = () => new Float32Array(wasm.memory.buffer,g.unit_info_ptr(),g.unit_count()*stride);
const first = view().slice();
const orders = [];
for(let i=0;i<g.unit_count();i++) {
 const o=i*stride; if(first[o+U.team]!==0) continue;
 let target=-1, nearest=Infinity;
 for(let j=0;j<g.unit_count();j++) {
  const e=j*stride; if(first[e+U.team]!==1)continue;
  const d=(first[o+U.centerX]-first[e+U.centerX])**2+(first[o+U.centerY]-first[e+U.centerY])**2;
  if(d<nearest){nearest=d;target=j;}
 }
 orders.push({tick:0,unit:i,target});
}
for(const order of orders)g.set_attack_order(order.unit,order.target);
function state(tick){
 const a=view();let alive=0,engaged=0;
 for(let i=0;i<g.unit_count();i++){alive+=a[i*stride+U.alive];engaged+=a[i*stride+U.engaged];}
 return {tick,hash:g.state_hash().toString(),alive,engaged,projectiles:g.projectile_count(),victor:g.victor()};
}
const initial = state(0), began=performance.now();
for(let tick=30;tick<=9000;tick+=30){g.advance_ticks(30);if(tick%3000===0)console.log(JSON.stringify({preparationTick:tick,elapsedMs:performance.now()-began}));}
const prepared=state(9000), preparationMs=performance.now()-began;
if(prepared.hash!=='9928381812590497427')throw new Error(`Scenario mismatch: ${prepared.hash}`);
g.reset_perf_timing?.();
const batches=[],started=performance.now();
for(let tick=9001;tick<=9308;tick++){const start=performance.now();g.advance_ticks(1);batches.push({tick,ticks:1,elapsedMs:performance.now()-start});if(tick===9300&&g.state_hash().toString()!=="6696754498600804919")throw new Error("tick9300 mismatch");}
const elapsedMs=performance.now()-started, final=state(9308);
const stages=JSON.parse(g.perf_timing_json?.(308) ?? '[]');
if(final.hash!=='13217042291758616190')throw new Error(`Final scenario mismatch: ${final.hash}`);
const values=batches.map(x=>x.elapsedMs).sort((a,b)=>a-b);
const report={stages,kind:'current-wasm-uninstrumented-control',pair,arm,wasmDirectory,hostBefore,hostAfter:{utc:new Date().toISOString(),loadAverage:os.loadavg()},artifactUnchanged:hashBytes(bytes)===hashBytes(await readFile(`${wasmDirectory}/game_wasm_bg.wasm`)),diagnosticOnly:true,hostCondition:'Serialized fresh Node processes in coordinated CPU window. Host load recorded; diagnostic feasibility evidence, not a release timing gate.',createdAt:new Date().toISOString(),source,identity:{node:process.version,v8:process.versions.v8,execArgv:process.execArgv,platform:os.platform(),arch:os.arch(),cpu:os.cpus()[0]?.model,loadAverage:os.loadavg(),wasmBytes:bytes.length,wasmSha256:createHash('sha256').update(bytes).digest('hex'),productionBuildCommandForReference:JSON.parse(await readFile(`${source}/web/package.json`,'utf8')).scripts['build:wasm'],cargoProfile:await readFile(`${source}/Cargo.toml`,'utf8')},orders,initial,prepared,final,preparationMs,elapsedMs,summary:{batchTicks:1,batchCount:batches.length,averageBatchMs:values.reduce((a,b)=>a+b,0)/values.length,p95BatchMs:values[Math.ceil(values.length*.95)-1],averageTickMs:values.reduce((a,b)=>a+b,0)/308,minBatchMs:values[0],maxBatchMs:values.at(-1)},measurement:'Synchronous Game.advance_ticks(1), including commander AI and one unit/posture export refresh. No renderer, browser, V8 tuning flags, or gameplay changes. No inspector profiling is enabled. Batch cost includes unchanged simulation, AI, and export refresh; not isolated Sim::tick alone.',batches};
await writeFile(output,JSON.stringify(report,null,2)); console.log(JSON.stringify({prepared,final,summary:report.summary,output}));
for(let tick=9308;tick<12000;){const n=Math.min(30,12000-tick);g.advance_ticks(n);tick+=n;if(tick%300===8||tick===12000)console.log(JSON.stringify({laterPreparationTick:tick}));}
const laterStart=state(12000);if(laterStart.hash!=="17530755159512483058")throw Error("tick12000 mismatch "+laterStart.hash);g.reset_perf_timing?.();const laterBatches=[];
for(let tick=12001;tick<=12308;tick++){const t=performance.now();g.advance_ticks(1);laterBatches.push({tick,elapsedMs:performance.now()-t});}
const later={scope:'Later canonical-setup combat without stage instrumentation. Node diagnostic, not browser timing.',start:laterStart,final:state(12308),stages:JSON.parse(g.perf_timing_json?.(308) ?? '[]'),averageTickMs:laterBatches.reduce((a,b)=>a+b.elapsedMs,0)/308,batches:laterBatches};if(later.final.hash!=="12041783451115246395")throw Error("tick12308 mismatch "+later.final.hash);await writeFile(output+'.later.json',JSON.stringify(later,null,2));console.log(JSON.stringify({...later,batches:undefined}));g.free();

