// SCRATCH, NOT SHIPPING CODE. Prepared, not run.
//
// The non-tautology check for the aligned water comparison: perturb ONLY the raw
// candidate's ocean shading and confirm the ALIGNED gate goes red. If aligning
// the two rasterizers had made the comparison blind to raw shading, this is where
// it shows. The reference side is untouched, so the original gate should move too.
//
// Build:  node throwaway/aligned-water/build-raw-shading-perturbation.mjs
// Run:    node throwaway/aligned-water/run-raw-shading-perturbation.mjs
// Both from the repo root, on a machine with exclusive GPU access.
import { build } from "../../web/node_modules/vite/dist/node/index.js";

const root = process.cwd();
let perturbed = false;

await build({
  configFile: `${root}/apps/battle-perf-lab/src/raw/water.vite.config.mts`,
  build: { outDir: `${root}/throwaway/aligned-water/dist`, copyPublicDir: false },
  plugins: [
    {
      name: "perturb-raw-ocean-shading",
      enforce: "pre",
      transform(code, id) {
        if (!id.endsWith("/packages/battle-renderer/src/shaders/water.ts")) return;
        // One fragment-stage value in the raw water only: no vertex position,
        // no projection, no invariance, nothing on the Three side. WGSL `let` is
        // immutable, so this binds a new value rather than reassigning.
        const target = "return shadeWorldSurface(albedo,vec3f(0),roughness,";
        if (!code.includes(target)) throw Error("Missing raw water shading target");
        perturbed = true;
        return code.replace(
          target,
          "let perturbedRoughness=roughness+0.02;\n    " +
            target.replace("roughness,", "perturbedRoughness,"),
        );
      },
    },
  ],
});

if (!perturbed) throw Error("Perturbation did not run");
