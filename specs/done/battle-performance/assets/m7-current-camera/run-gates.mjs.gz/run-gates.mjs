import{spawn,execFileSync}from'node:child_process';import{writeFile,mkdir}from'node:fs/promises';
const root=process.cwd(),out=root+'/throwaway/current-camera-review';
for(const mode of ['source-floor','scene-control','scene-candidate'].filter(mode=>!process.argv[2]||mode.startsWith(process.argv[2]))){
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config',mode==='source-floor'?'web/vite.config.ts':'apps/battle-perf-lab/src/raw/scene.vite.config.mts','--outDir',out+'/'+mode,'--port','5298','--strictPort'],{stdio:['ignore','pipe','pipe']});let log='';server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
 try{await new Promise((resolve,reject)=>{const start=Date.now(),t=setInterval(()=>{if(log.includes('Local:')){clearInterval(t);resolve();}else if(server.exitCode!==null||Date.now()-start>30000){clearInterval(t);reject(Error(log));}},100);});
 await writeFile(out+'/'+mode+'-processes.txt',execFileSync('ps',['-axo','pid,pcpu,comm']));
 const args=mode==='source-floor'?['web/scene.mjs','battle-perf-30k']:['apps/battle-perf-lab/src/raw/verify-scene.mjs'];
 const env={...process.env,VERIFY_GPU:'1',VERIFY_GPU_ADAPTER:'hardware',VERIFY_BROWSER_CHANNEL:'chrome',VERIFY_URL:'http://localhost:5298',SCENARIO_REPORT_JSON:out+'/source-floor-report.json',SCENE_CHECK_URL:'http://localhost:5298/scene-check.html?atlasCatalog=/assets/soldiers/impostors/catalog.json',SCENE_EVIDENCE_DIR:out+'/'+mode+'-hardware'};
 const child=spawn(process.execPath,args,{cwd:root,env,stdio:['ignore','pipe','pipe']});let childLog='';child.stdout.on('data',b=>childLog+=b);child.stderr.on('data',b=>childLog+=b);const code=await new Promise(resolve=>child.once('exit',resolve));await writeFile(out+'/'+mode+'-run.log',childLog);console.log(mode,code);if(code)process.exitCode=1;
 }finally{server.kill('SIGTERM');await new Promise(resolve=>server.exitCode!==null?resolve():server.once('exit',resolve));await writeFile(out+'/'+mode+'-preview.log',log);}
}
