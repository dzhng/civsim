import {build} from '../../web/node_modules/vite/dist/node/index.js';import {symlink,readdir,writeFile} from 'node:fs/promises';
const root=process.cwd(),out=root+'/throwaway/shadow-light-diagnosis';process.env.BATTLE_NATIVE_BACKEND='raw';
for(const diagnostic of ['shadow','direct','indirect']){
 let count=0;
 await build({configFile:root+'/apps/battle-perf-lab/src/live/vite.config.mts',plugins:[{name:'scratch-light-separation',enforce:'pre',transform(code,id){
 if(diagnostic==='shadow'&&id.endsWith('/shaders/environment.ts')){const anchor='let lit=standardPbr(base,emissive,roughness,geomRoughness,metal,ao,normalize(normalWorld),normalize(eye-worldPosition),sunDirection,sunRadiance,shadow,environmentIntensity,pmrem,linear,maxMip,dfg,linear);';if(code.split(anchor).length!==2)throw Error('shadow diagnostic anchor mismatch');count++;return code.replace(anchor,'let lit=vec3f(shadow);');}
 if(diagnostic!=='shadow'&&id.endsWith('/shaders/standardPbr.ts')){const anchor='return max((directDiffuse+indirectDiffuse)+(directSpecular+indirectSpecular)+emissive,vec3f(0));';if(code.split(anchor).length!==2)throw Error('light diagnostic anchor mismatch');count++;return code.replace(anchor,diagnostic==='direct'?'return max(directDiffuse+directSpecular,vec3f(0));':'return max(indirectDiffuse+indirectSpecular+emissive,vec3f(0));');}
 }}],build:{outDir:out+'/'+diagnostic,copyPublicDir:false}});
 if(count!==1)throw Error('diagnostic hook missing/duplicate');
 for(const name of await readdir(root+'/web/public')){if(name==='assets'){for(const entry of await readdir(root+'/web/public/assets'))await symlink(root+'/web/public/assets/'+entry,out+'/'+diagnostic+'/assets/'+entry);}else await symlink(root+'/web/public/'+name,out+'/'+diagnostic+'/'+name);}
 await writeFile(out+'/'+diagnostic+'-manifest.json',JSON.stringify({diagnostic,count,scope:'Diagnostic light separation; not a production candidate or timed workload. Geometry/fit/sampling unchanged. Aerial and post retained, so output components are not additive.'}));
}
