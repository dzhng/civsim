// SCRATCH, NOT SHIPPING CODE. Prepared, not run.
//
// The displacement-fidelity check for the aligned water comparison: make the
// aligned clip node read the UNDISPLACED attribute instead of the displaced
// local position, and confirm the geometry probe goes red. This is the failure
// the probe exists to catch — lighting, normals and foam keep animating over a
// flattened sea, so the beauty image alone cannot see it.
//
// EXPECTED: aligned.swell[*].aligned.maxAbs === 0 while .source.maxAbs > 0, so
// aligned.passed is false. The generated-WGSL reader should independently report
// aligned.shaders.aligned.displacedPosition === false.
//
// Build:  node throwaway/aligned-water/build-vertex-flattening.mjs
// Run:    node throwaway/aligned-water/run-vertex-flattening.mjs
// Both from the repo root, on a machine with exclusive GPU access.
import { build } from "../../web/node_modules/vite/dist/node/index.js";

const root = process.cwd();
let flattened = false;

await build({
  configFile: `${root}/apps/battle-perf-lab/src/raw/water.vite.config.mts`,
  build: { outDir: `${root}/throwaway/aligned-water/dist-flat`, copyPublicDir: false },
  plugins: [
    {
      name: "flatten-aligned-clip-vertex",
      enforce: "pre",
      transform(code, id) {
        if (!id.endsWith("/apps/battle-perf-lab/src/alignedWaterReference.ts")) return;
        // `positionLocal` carries the swell; `positionGeometry` is the raw
        // attribute. Everything else — the projector, the invariance, the
        // fragment probe, the source material — is untouched.
        const target = "material.vertexNode = projection.node.mul(vec4(positionLocal, 1));";
        if (!code.includes(target)) throw Error("Missing aligned clip vertex node");
        flattened = true;
        return code
          .replace("positionLocal, uniform", "positionGeometry, positionLocal, uniform")
          .replace(target, target.replace("positionLocal", "positionGeometry"));
      },
    },
  ],
});

if (!flattened) throw Error("Flattening did not run");
