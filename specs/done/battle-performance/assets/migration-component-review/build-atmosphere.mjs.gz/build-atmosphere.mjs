import {build} from '../../web/node_modules/vite/dist/node/index.js';
const root=process.cwd();
for(const [name,config] of [['sky','src/vgpu/sky.vite.config.mts'],['pmrem','src/raw/pmrem.vite.config.mts']]) await build({configFile:root+'/apps/battle-perf-lab/'+config,build:{outDir:root+'/throwaway/migration-component-review/'+name,copyPublicDir:false}});
