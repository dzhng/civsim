import {build} from '../../web/node_modules/vite/dist/node/index.js';
import {mkdir,symlink,writeFile,readdir} from 'node:fs/promises';
const root=process.cwd(),out=root+'/throwaway/current-camera-review', candidate='/Users/david/dev/game-battle-current-camera';
process.env.BATTLE_NATIVE_BACKEND='raw';
for(const [arm,source] of [['control',root],['candidate',candidate]].filter(([arm])=>!process.argv[2]||arm===process.argv[2])){
 let injected=0;
 await build({configFile:source+'/apps/battle-perf-lab/src/live/vite.config.mts',plugins:[{name:'scratch-timing-access',enforce:'pre',transform(code,id){if(!id.endsWith('/live/NativeBattleRenderer.ts'))return;const anchor='this.lastView = view;';if(code.split(anchor).length!==2)throw Error('overlay anchor mismatch');injected++;return code.replace(anchor,anchor+`
 if(globalThis.__overlayReceipts){ globalThis.__overlayReceipts.push({camera:view.camera,standards:c.standards.map(s=>({...s})),readouts:c.readouts.map(s=>({...s,chips:s.chips.map(x=>({...x}))}))});if(globalThis.__overlayReceipts.length>64)globalThis.__overlayReceipts.shift(); }
 if(globalThis.__holdNextOverlay){globalThis.__holdNextOverlay=false; await this.device.queue.onSubmittedWorkDone();globalThis.__overlayHeld=true;await new Promise(resolve=>{globalThis.__releaseOverlay=resolve;});globalThis.__overlayHeld=false;}
`);}}],build:{outDir:out+'/'+arm,copyPublicDir:false}});
 if(injected!==1)throw Error('observation hook not installed once');
 for(const name of await readdir(root+'/web/public')) { if(name==='assets'){ for(const entry of await readdir(root+'/web/public/assets')) await symlink(root+'/web/public/assets/'+entry,out+'/'+arm+'/assets/'+entry); } else await symlink(root+'/web/public/'+name,out+'/'+arm+'/'+name); }
 await writeFile(out+'/'+arm+'-observation.json',JSON.stringify({source,injected}));
}
