import {build} from '../../web/node_modules/vite/dist/node/index.js';
import {readdir,symlink} from 'node:fs/promises';
const main=process.cwd();
for(const [arm,root] of [['control',main],['candidate','/Users/david/dev/game-battle-crowd-ownership']]){
 const out=main+'/throwaway/crowd-ownership-hardware/scene-'+arm;
 await build({configFile:root+'/apps/battle-perf-lab/src/raw/scene.vite.config.mts',build:{outDir:out,copyPublicDir:false}});
 for(const name of await readdir(main+'/web/public')){if(name==='assets'){for(const entry of await readdir(main+'/web/public/assets'))await symlink(main+'/web/public/assets/'+entry,out+'/assets/'+entry);}else await symlink(main+'/web/public/'+name,out+'/'+name);}
}
