import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {PNG} from '../../web/node_modules/pngjs/lib/png.js';
const out='throwaway/m1b-verification/visual-review';await mkdir(out,{recursive:true});
for(const [label,dir] of [['A','reference-scene'],['B','promoted-scene']]) {
 const bytes=await readFile(`throwaway/m1b-verification/${dir}/tactical-initial-actual.png`);await writeFile(`${out}/${label}-full.png`,bytes);
 const source=PNG.sync.read(bytes);
 for(const [name,x,y,w,h] of [['units',500,750,650,500],['cues',1200,650,450,450]]) {
  const scale=2;const dest=new PNG({width:w*scale,height:h*scale});
  for(let dy=0;dy<dest.height;dy++)for(let dx=0;dx<dest.width;dx++){const src=((y+Math.floor(dy/scale))*source.width+x+Math.floor(dx/scale))*4;source.data.copy(dest.data,(dy*dest.width+dx)*4,src,src+4);}
  await writeFile(`${out}/${label}-${name}.png`,PNG.sync.write(dest));
 }
}
