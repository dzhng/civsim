import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
const root=process.cwd(),out=root+'/throwaway/ocean-msaa-position',kind=process.argv[2]??'ocean',samples=Number(process.argv[3]??1),build=process.argv[4]??'candidate';
if(!['ocean','lake'].includes(kind)||![1,4].includes(samples)||!['candidate','flat','shading'].includes(build))throw Error('Invalid case');
const name=`${build}-${kind}-${samples}`;
const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config','apps/battle-perf-lab/src/raw/water.vite.config.mts','--outDir',out+'/'+build,'--port','5298','--strictPort'],{stdio:['ignore','pipe','pipe']});
let log='',browser;server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
try{
 await new Promise((resolve,reject)=>{const start=Date.now(),timer=setInterval(()=>{if(log.includes('Local:')){clearInterval(timer);resolve();}else if(server.exitCode!==null||Date.now()-start>30000){clearInterval(timer);reject(Error(log));}},100);});
 browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});const page=await browser.newPage();const errors=[],warnings=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
 await page.goto(`http://localhost:5298/water-check.html?kind=${kind}&samples=${samples}`);await page.waitForFunction(()=>window.__waterCheck!==undefined,null,{timeout:180000});const report=await page.evaluate(()=>window.__waterCheck);
 await writeFile(out+'/'+name+'.json.gz',gzipSync(JSON.stringify({report,errors,warnings,purpose:'correctness only; CPU review/implementation may overlap, no timing acceptance'})));
 console.log(JSON.stringify({name,passed:report.passed,aligned:report.aligned?.passed,error:report.error,original:report.results?.map(r=>[r.label,r.comparison.maxAbs]),alignedComparisons:report.aligned?.results?.map(r=>[r.label,r.comparison.maxAbs]),shaders:report.aligned?.shaders?Object.fromEntries(Object.entries(report.aligned.shaders).map(([k,v])=>[k,{...v,vertexWgsl:undefined}])):null,swell:report.aligned?.swell,errors,warnings}));
}finally{await browser?.close();server.kill('SIGTERM');await new Promise(r=>server.exitCode!==null?r():server.once('exit',r));await writeFile(out+'/'+name+'-server.log',log);}
