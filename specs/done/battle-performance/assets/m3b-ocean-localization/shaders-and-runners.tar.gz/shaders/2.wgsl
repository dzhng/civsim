// Three.js r185 - Node System

// global
diagnostic( off, derivative_uniformity );


// structs

struct OutputStruct {
	@location( 0 ) color: vec4<f32>
};
var<private> output : OutputStruct;

// uniforms
@binding( 1 ) @group( 1 ) var nodeUniform14_sampler : sampler;
@binding( 2 ) @group( 1 ) var nodeUniform14 : texture_2d<f32>;
@binding( 3 ) @group( 1 ) var nodeUniform20_sampler : sampler;
@binding( 4 ) @group( 1 ) var nodeUniform20 : texture_2d<f32>;
@binding( 5 ) @group( 1 ) var nodeUniform22_sampler : sampler;
@binding( 6 ) @group( 1 ) var nodeUniform22 : texture_2d<f32>;

struct objectStruct {
	nodeUniform0 : f32,
	nodeUniform1 : f32,
	nodeUniform2 : f32,
	nodeUniform3 : f32,
	nodeUniform4 : vec3<f32>,
	nodeUniform5 : f32,
	nodeUniform7 : mat3x3<f32>,
	nodeUniform8 : vec2<f32>,
	nodeUniform13 : mat4x4<f32>,
	nodeUniform15 : f32,
	nodeUniform16 : mat4x4<f32>,
	nodeUniform18 : f32,
	nodeUniform19 : f32,
	nodeUniform21 : f32
};
@binding( 0 ) @group( 1 )
var<uniform> object : objectStruct;

struct renderStruct {
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	nodeUniform11 : vec3<f32>,
	nodeUniform9 : vec3<f32>,
	nodeUniform10 : vec3<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	cameraPosition : vec3<f32>
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

// vars
var<private> DiffuseColor : vec4<f32>;
var<private> nodeVar20 : vec2<f32>;
var<private> nodeVar21 : f32;
var<private> nodeVar22 : f32;
var<private> nodeVar23 : f32;
var<private> nodeVar24 : f32;
var<private> nodeVar25 : f32;
var<private> nodeVar26 : f32;
var<private> nodeVar27 : f32;
var<private> nodeVar28 : f32;
var<private> nodeVar29 : f32;
var<private> nodeVar30 : f32;
var<private> nodeVar31 : f32;
var<private> nodeVar32 : f32;
var<private> nodeVar33 : f32;
var<private> nodeVar34 : f32;
var<private> nodeVar35 : f32;
var<private> nodeVar36 : f32;
var<private> nodeVar37 : f32;
var<private> nodeVar38 : f32;
var<private> nodeVar39 : f32;
var<private> nodeVar40 : f32;
var<private> nodeVar41 : f32;
var<private> nodeVar42 : f32;
var<private> nodeVar43 : f32;
var<private> nodeVar44 : f32;
var<private> nodeVar45 : f32;
var<private> nodeVar46 : f32;
var<private> nodeVar47 : f32;
var<private> nodeVar48 : f32;
var<private> nodeVar49 : f32;
var<private> nodeVar50 : f32;
var<private> nodeVar51 : f32;
var<private> nodeVar52 : f32;
var<private> nodeVar53 : f32;
var<private> nodeVar54 : f32;
var<private> nodeVar55 : f32;
var<private> nodeVar56 : f32;
var<private> nodeVar57 : f32;
var<private> nodeVar58 : f32;
var<private> nodeVar59 : f32;
var<private> nodeVar60 : f32;
var<private> nodeVar61 : f32;
var<private> nodeVar62 : f32;
var<private> nodeVar63 : f32;
var<private> nodeVar64 : f32;
var<private> nodeVar65 : f32;
var<private> nodeVar66 : f32;
var<private> nodeVar67 : f32;
var<private> nodeVar68 : f32;
var<private> nodeVar69 : f32;
var<private> nodeVar70 : f32;
var<private> nodeVar71 : f32;
var<private> nodeVar72 : f32;
var<private> nodeVar73 : f32;
var<private> nodeVar74 : f32;
var<private> nodeVar75 : f32;
var<private> nodeVar76 : f32;
var<private> nodeVar77 : f32;
var<private> nodeVar78 : f32;
var<private> nodeVar79 : f32;
var<private> nodeVar80 : f32;
var<private> nodeVar81 : f32;
var<private> nodeVar82 : f32;
var<private> nodeVar83 : f32;
var<private> nodeVar84 : f32;
var<private> nodeVar85 : f32;
var<private> nodeVar86 : f32;
var<private> nodeVar87 : f32;
var<private> nodeVar88 : f32;
var<private> nodeVar89 : f32;
var<private> nodeVar90 : f32;
var<private> nodeVar91 : f32;
var<private> nodeVar92 : f32;
var<private> nodeVar93 : f32;
var<private> nodeVar94 : f32;
var<private> nodeVar95 : f32;
var<private> nodeVar96 : f32;
var<private> nodeVar97 : f32;
var<private> nodeVar98 : f32;
var<private> nodeVar99 : f32;
var<private> nodeVar100 : f32;
var<private> nodeVar101 : f32;
var<private> nodeVar102 : f32;
var<private> nodeVar103 : f32;
var<private> nodeVar104 : f32;
var<private> nodeVar105 : f32;
var<private> nodeVar106 : f32;
var<private> nodeVar107 : f32;
var<private> nodeVar108 : f32;
var<private> nodeVar109 : f32;
var<private> nodeVar110 : f32;
var<private> nodeVar111 : f32;
var<private> nodeVar112 : f32;
var<private> nodeVar113 : f32;
var<private> nodeVar114 : f32;
var<private> nodeVar115 : f32;
var<private> nodeVar116 : f32;
var<private> nodeVar117 : f32;
var<private> nodeVar118 : f32;
var<private> nodeVar119 : f32;
var<private> nodeVar120 : f32;
var<private> nodeVar121 : f32;
var<private> nodeVar122 : f32;
var<private> nodeVar123 : f32;
var<private> nodeVar124 : f32;
var<private> nodeVar125 : f32;
var<private> nodeVar126 : f32;
var<private> nodeVar127 : vec2<f32>;
var<private> nodeVar128 : vec2<f32>;
var<private> nodeVar129 : vec2<f32>;
var<private> nodeVar130 : vec2<f32>;
var<private> nodeVar131 : vec2<f32>;
var<private> nodeVar132 : vec2<f32>;
var<private> nodeVar133 : vec2<f32>;
var<private> nodeVar134 : vec2<f32>;
var<private> nodeVar135 : vec2<f32>;
var<private> nodeVar136 : vec2<f32>;
var<private> nodeVar137 : vec2<f32>;
var<private> nodeVar138 : vec2<f32>;
var<private> nodeVar139 : f32;
var<private> nodeVar140 : f32;
var<private> nodeVar141 : f32;
var<private> Metalness : f32;
var<private> Roughness : f32;
var<private> SpecularColor : vec3<f32>;
var<private> SpecularColorBlended : vec3<f32>;
var<private> SpecularF90 : f32;
var<private> DiffuseContribution : vec3<f32>;
var<private> EmissiveColor : vec3<f32>;
var<private> Output : vec4<f32>;
var<private> nodeVar142 : vec3<f32>;
var<private> nodeVar143 : f32;
var<private> nodeVar144 : f32;
var<private> nodeVar145 : f32;
var<private> normalView : vec3<f32>;
var<private> nodeVar146 : vec3<f32>;
var<private> nodeVar147 : vec4<f32>;
var<private> nodeVar148 : vec4<f32>;
var<private> nodeVar149 : vec3<f32>;
var<private> nodeVar150 : vec3<f32>;
var<private> nodeVar151 : f32;
var<private> nodeVar152 : vec3<f32>;
var<private> nodeVar153 : vec3<f32>;
var<private> directDiffuse : vec3<f32>;
var<private> nodeVar154 : vec3<f32>;
var<private> nodeVar155 : vec3<f32>;
var<private> nodeVar156 : vec3<f32>;
var<private> directSpecular : vec3<f32>;
var<private> positionViewDirection : vec3<f32>;
var<private> nodeVar157 : vec3<f32>;
var<private> nodeVar158 : f32;
var<private> nodeVar159 : f32;
var<private> nodeVar160 : f32;
var<private> nodeVar161 : vec4<f32>;
var<private> nodeVar162 : vec4<f32>;
var<private> nodeVar163 : vec3<f32>;
var<private> nodeVar164 : f32;
var<private> nodeVar165 : f32;
var<private> nodeVar166 : vec3<f32>;
var<private> nodeVar167 : vec3<f32>;
var<private> nodeVar168 : vec3<f32>;
var<private> radiance : vec3<f32>;
var<private> nodeVar169 : f32;
var<private> nodeVar170 : f32;
var<private> nodeVar171 : f32;
var<private> nodeVar172 : vec3<f32>;
var<private> nodeVar173 : f32;
var<private> nodeVar174 : f32;
var<private> nodeVar175 : f32;
var<private> nodeVar176 : vec2<f32>;
var<private> nodeVar177 : vec4<f32>;
var<private> nodeVar178 : vec3<f32>;
var<private> nodeVar179 : f32;
var<private> nodeVar180 : f32;
var<private> nodeVar181 : f32;
var<private> nodeVar182 : f32;
var<private> nodeVar183 : f32;
var<private> nodeVar184 : vec2<f32>;
var<private> nodeVar185 : vec4<f32>;
var<private> nodeVar186 : vec3<f32>;
var<private> nodeVar187 : vec3<f32>;
var<private> iblIrradiance : vec3<f32>;
var<private> nodeVar188 : f32;
var<private> nodeVar189 : f32;
var<private> nodeVar190 : f32;
var<private> normalWorld : vec3<f32>;
var<private> nodeVar191 : f32;
var<private> nodeVar192 : f32;
var<private> nodeVar193 : f32;
var<private> nodeVar194 : vec2<f32>;
var<private> nodeVar195 : vec4<f32>;
var<private> nodeVar196 : vec3<f32>;
var<private> nodeVar197 : f32;
var<private> nodeVar198 : f32;
var<private> nodeVar199 : f32;
var<private> nodeVar200 : f32;
var<private> nodeVar201 : f32;
var<private> nodeVar202 : vec2<f32>;
var<private> nodeVar203 : vec4<f32>;
var<private> nodeVar204 : vec3<f32>;
var<private> nodeVar205 : vec3<f32>;
var<private> irradiance : vec3<f32>;
var<private> nodeVar206 : vec3<f32>;
var<private> nodeVar207 : vec3<f32>;
var<private> nodeVar208 : vec3<f32>;
var<private> indirectDiffuse : vec3<f32>;
var<private> nodeVar209 : vec3<f32>;
var<private> singleScatteringDielectric : vec3<f32>;
var<private> multiScatteringDielectric : vec3<f32>;
var<private> singleScatteringMetallic : vec3<f32>;
var<private> multiScatteringMetallic : vec3<f32>;
var<private> nodeVar210 : f32;
var<private> nodeVar211 : vec4<f32>;
var<private> nodeVar212 : vec3<f32>;
var<private> nodeVar213 : f32;
var<private> nodeVar214 : vec3<f32>;
var<private> nodeVar215 : vec3<f32>;
var<private> nodeVar216 : vec3<f32>;
var<private> nodeVar217 : vec3<f32>;
var<private> nodeVar218 : vec3<f32>;
var<private> nodeVar219 : vec3<f32>;
var<private> nodeVar220 : vec3<f32>;
var<private> nodeVar221 : f32;
var<private> nodeVar222 : f32;
var<private> nodeVar223 : f32;
var<private> nodeVar224 : vec3<f32>;
var<private> nodeVar225 : vec3<f32>;
var<private> nodeVar226 : vec3<f32>;
var<private> nodeVar227 : vec3<f32>;
var<private> nodeVar228 : vec3<f32>;
var<private> nodeVar229 : vec3<f32>;
var<private> nodeVar230 : f32;
var<private> nodeVar231 : vec4<f32>;
var<private> nodeVar232 : vec3<f32>;
var<private> nodeVar233 : f32;
var<private> nodeVar234 : vec3<f32>;
var<private> nodeVar235 : vec3<f32>;
var<private> nodeVar236 : vec3<f32>;
var<private> nodeVar237 : vec3<f32>;
var<private> nodeVar238 : vec3<f32>;
var<private> nodeVar239 : vec3<f32>;
var<private> nodeVar240 : vec3<f32>;
var<private> nodeVar241 : f32;
var<private> nodeVar242 : f32;
var<private> nodeVar243 : f32;
var<private> nodeVar244 : vec3<f32>;
var<private> nodeVar245 : vec3<f32>;
var<private> nodeVar246 : vec3<f32>;
var<private> nodeVar247 : vec3<f32>;
var<private> nodeVar248 : vec3<f32>;
var<private> nodeVar249 : vec3<f32>;
var<private> nodeVar250 : vec3<f32>;
var<private> nodeVar251 : vec3<f32>;
var<private> nodeVar252 : vec3<f32>;
var<private> nodeVar253 : vec3<f32>;
var<private> nodeVar254 : vec3<f32>;
var<private> nodeVar255 : vec3<f32>;
var<private> nodeVar256 : vec3<f32>;
var<private> nodeVar257 : vec3<f32>;
var<private> nodeVar258 : vec3<f32>;
var<private> nodeVar259 : vec3<f32>;
var<private> nodeVar260 : vec3<f32>;
var<private> nodeVar261 : vec3<f32>;
var<private> nodeVar262 : vec3<f32>;
var<private> indirectSpecular : vec3<f32>;
var<private> nodeVar263 : vec3<f32>;
var<private> nodeVar264 : vec3<f32>;
var<private> ambientOcclusion : f32;
var<private> nodeVar265 : vec3<f32>;
var<private> nodeVar266 : f32;
var<private> nodeVar267 : f32;
var<private> nodeVar268 : f32;
var<private> nodeVar269 : f32;
var<private> nodeVar270 : f32;
var<private> nodeVar271 : f32;
var<private> nodeVar272 : f32;
var<private> nodeVar273 : f32;
var<private> nodeVar274 : f32;
var<private> nodeVar275 : f32;
var<private> nodeVar276 : f32;
var<private> nodeVar277 : vec3<f32>;
var<private> totalDiffuse : vec3<f32>;
var<private> nodeVar278 : vec3<f32>;
var<private> totalSpecular : vec3<f32>;
var<private> nodeVar279 : vec3<f32>;
var<private> outgoingLight : vec3<f32>;
var<private> nodeVar280 : vec3<f32>;
var<private> nodeVar281 : vec3<f32>;
var<private> nodeVar282 : f32;
var<private> nodeVar283 : f32;
var<private> nodeVar284 : f32;
var<private> nodeVar285 : f32;
var<private> nodeVar286 : vec3<f32>;
var<private> nodeVar287 : vec3<f32>;
var<private> nodeVar288 : vec4<f32>;
var<private> nodeVar289 : vec3<f32>;
var<private> nodeVar290 : vec3<f32>;
var<private> nodeVar291 : vec4<f32>;
var<private> nodeVar292 : vec4<f32>;

// codes
fn sRGBTransferEOTF ( color : vec3<f32> ) -> vec3<f32> {

	


	return mix( pow( ( ( color * vec3<f32>( 0.9478672986 ) ) + vec3<f32>( 0.0521327014 ) ), vec3<f32>( 2.4 ) ), ( color * vec3<f32>( 0.0773993808 ) ), vec3<f32>( ( color <= vec3<f32>( 0.04045 ) ) ) );

}

fn V_GGX_SmithCorrelated ( alpha : f32, dotNL : f32, dotNV : f32 ) -> f32 {

	var nodeVar0 : f32;

	nodeVar0 = ( alpha * alpha );

	return ( 0.5 / max( ( ( dotNL * sqrt( ( nodeVar0 + ( ( 1.0 - nodeVar0 ) * ( dotNV * dotNV ) ) ) ) ) + ( dotNV * sqrt( ( nodeVar0 + ( ( 1.0 - nodeVar0 ) * ( dotNL * dotNL ) ) ) ) ) ), 0.000001 ) );

}

fn D_GGX ( alpha : f32, dotNH : f32 ) -> f32 {

	var nodeVar0 : f32;
	var nodeVar1 : f32;

	nodeVar0 = ( alpha * alpha );
	nodeVar1 = ( 1.0 - ( ( dotNH * dotNH ) * ( 1.0 - nodeVar0 ) ) );

	return ( ( nodeVar0 / ( nodeVar1 * nodeVar1 ) ) * 0.3183098861837907 );

}

fn roughnessToMip ( roughness : f32 ) -> f32 {

	var nodeVar0 : f32;

	nodeVar0 = 0.0;

	if ( ( roughness >= 0.8 ) ) {

		nodeVar0 = ( ( ( ( 1.0 - roughness ) * ( -1.0 - -2.0 ) ) / ( 1.0 - 0.8 ) ) + -2.0 );
		

	} else {


		if ( ( roughness >= 0.4 ) ) {

			nodeVar0 = ( ( ( ( 0.8 - roughness ) * ( 2.0 - -1.0 ) ) / ( 0.8 - 0.4 ) ) + -1.0 );
			

		} else {


			if ( ( roughness >= 0.305 ) ) {

				nodeVar0 = ( ( ( ( 0.4 - roughness ) * ( 3.0 - 2.0 ) ) / ( 0.4 - 0.305 ) ) + 2.0 );
				

			} else {


				if ( ( roughness >= 0.21 ) ) {

					nodeVar0 = ( ( ( ( 0.305 - roughness ) * ( 4.0 - 3.0 ) ) / ( 0.305 - 0.21 ) ) + 3.0 );
					

				} else {

					nodeVar0 = ( -2.0 * log2( ( 1.16 * roughness ) ) );
					

				}

				

			}

			

		}

		

	}


	return nodeVar0;

}

fn getFace ( direction : vec3<f32> ) -> f32 {

	var nodeVar0 : vec3<f32>;
	var nodeVar1 : f32;
	var nodeVar2 : f32;
	var nodeVar3 : f32;
	var nodeVar4 : f32;
	var nodeVar5 : f32;

	nodeVar0 = abs( direction );
	nodeVar1 = -1.0;

	if ( ( nodeVar0.x > nodeVar0.z ) ) {


		if ( ( nodeVar0.x > nodeVar0.y ) ) {


			if ( ( direction.x > 0.0 ) ) {

				nodeVar2 = 0.0;

			} else {

				nodeVar2 = 3.0;

			}

			nodeVar1 = nodeVar2;
			

		} else {


			if ( ( direction.y > 0.0 ) ) {

				nodeVar3 = 1.0;

			} else {

				nodeVar3 = 4.0;

			}

			nodeVar1 = nodeVar3;
			

		}

		

	} else {


		if ( ( nodeVar0.z > nodeVar0.y ) ) {


			if ( ( direction.z > 0.0 ) ) {

				nodeVar4 = 2.0;

			} else {

				nodeVar4 = 5.0;

			}

			nodeVar1 = nodeVar4;
			

		} else {


			if ( ( direction.y > 0.0 ) ) {

				nodeVar5 = 1.0;

			} else {

				nodeVar5 = 4.0;

			}

			nodeVar1 = nodeVar5;
			

		}

		

	}


	return nodeVar1;

}

fn getUV ( direction : vec3<f32>, face : f32 ) -> vec2<f32> {

	var nodeVar0 : vec2<f32>;

	nodeVar0 = vec2<f32>( 0.0, 0.0 );

	if ( ( face == 0.0 ) ) {

		nodeVar0 = ( vec2<f32>( direction.z, direction.y ) / vec2<f32>( abs( direction.x ) ) );
		

	} else {


		if ( ( face == 1.0 ) ) {

			nodeVar0 = ( vec2<f32>( ( - direction.x ), ( - direction.z ) ) / vec2<f32>( abs( direction.y ) ) );
			

		} else {


			if ( ( face == 2.0 ) ) {

				nodeVar0 = ( vec2<f32>( ( - direction.x ), direction.y ) / vec2<f32>( abs( direction.z ) ) );
				

			} else {


				if ( ( face == 3.0 ) ) {

					nodeVar0 = ( vec2<f32>( ( - direction.z ), direction.y ) / vec2<f32>( abs( direction.x ) ) );
					

				} else {


					if ( ( face == 4.0 ) ) {

						nodeVar0 = ( vec2<f32>( ( - direction.x ), direction.z ) / vec2<f32>( abs( direction.y ) ) );
						

					} else {

						nodeVar0 = ( vec2<f32>( direction.x, direction.y ) / vec2<f32>( abs( direction.z ) ) );
						

					}

					

				}

				

			}

			

		}

		

	}


	return ( vec2<f32>( 0.5 ) * ( nodeVar0 + vec2<f32>( 1.0 ) ) );

}



@fragment
fn main( @location( 0 ) nodeVarying3 : vec2<f32>,
	@location( 1 ) v_positionViewDirection : vec3<f32>,
	@location( 2 ) v_positionWorld : vec3<f32> ) -> OutputStruct {

	// flow
	// code

	nodeVar20 = nodeVarying3;
	nodeVar21 = abs( ( nodeVar20.x - -200.0 ) );
	nodeVar22 = smoothstep( 12.0, 300.0, nodeVar21 );
	nodeVar23 = ( ( ( dot( vec2<f32>( 0.9936, 0.1132 ), nodeVar20 ) * 0.06816952696105023 ) - ( object.nodeUniform1 * 0.3434621896128685 ) ) + 1.4445185748148395 );
	nodeVar24 = sin( nodeVar23 );
	nodeVar25 = ( ( nodeVar24 * 0.5 ) + 0.5 );
	nodeVar26 = ( ( ( dot( vec2<f32>( 0.9157, 0.4018 ), nodeVar20 ) * 0.07282319541029207 ) - ( object.nodeUniform1 * 0.354992076652964 ) ) + 5.406467639197834 );
	nodeVar27 = sin( nodeVar26 );
	nodeVar28 = ( ( nodeVar27 * 0.5 ) + 0.5 );
	nodeVar29 = ( ( ( dot( vec2<f32>( 0.7585, 0.6517 ), nodeVar20 ) * 0.08923711546655305 ) - ( object.nodeUniform1 * 0.39296742933864454 ) ) + 2.5043572818772324 );
	nodeVar30 = sin( nodeVar29 );
	nodeVar31 = ( ( nodeVar30 * 0.5 ) + 0.5 );
	nodeVar32 = ( ( ( dot( vec2<f32>( 0.4565, 0.8897 ), nodeVar20 ) * 0.09256313052445493 ) - ( object.nodeUniform1 * 0.40022370789657236 ) ) + 2.1629999741538026 );
	nodeVar33 = sin( nodeVar32 );
	nodeVar34 = ( ( nodeVar33 * 0.5 ) + 0.5 );
	nodeVar35 = ( ( ( dot( vec2<f32>( 0.1923, 0.9813 ), nodeVar20 ) * 0.10633246403790828 ) - ( object.nodeUniform1 * 0.42895993717149816 ) ) + 5.517105324695108 );
	nodeVar36 = sin( nodeVar35 );
	nodeVar37 = ( ( nodeVar36 * 0.5 ) + 0.5 );
	nodeVar38 = ( ( ( dot( vec2<f32>( -0.0506, 0.9987 ), nodeVar20 ) * 0.1358232879377432 ) - ( object.nodeUniform1 * 0.4848092682732639 ) ) + 3.797562421550177 );
	nodeVar39 = sin( nodeVar38 );
	nodeVar40 = ( ( nodeVar39 * 0.5 ) + 0.5 );
	nodeVar41 = ( ( ( dot( vec2<f32>( -0.4173, 0.9088 ), nodeVar20 ) * 0.16657437168610817 ) - ( object.nodeUniform1 * 0.5368931784003809 ) ) + 1.8312313893253558 );
	nodeVar42 = sin( nodeVar41 );
	nodeVar43 = ( ( nodeVar42 * 0.5 ) + 0.5 );
	nodeVar44 = ( ( ( dot( vec2<f32>( -0.6739, 0.7388 ), nodeVar20 ) * 0.1871109380583681 ) - ( object.nodeUniform1 * 0.5690276658783798 ) ) + 5.700527025009868 );
	nodeVar45 = sin( nodeVar44 );
	nodeVar46 = ( ( nodeVar45 * 0.5 ) + 0.5 );
	nodeVar47 = ( ( ( dot( vec2<f32>( -0.8617, 0.5075 ), nodeVar20 ) * 0.2278167258883249 ) - ( object.nodeUniform1 * 0.6278799240954691 ) ) + 4.7868431022853235 );
	nodeVar48 = sin( nodeVar47 );
	nodeVar49 = ( ( nodeVar48 * 0.5 ) + 0.5 );
	nodeVar50 = ( ( ( dot( vec2<f32>( -0.9553, 0.2958 ), nodeVar20 ) * 0.21923186671318912 ) - ( object.nodeUniform1 * 0.6159360661929989 ) ) + 2.679924160764698 );
	nodeVar51 = sin( nodeVar50 );
	nodeVar52 = ( ( nodeVar51 * 0.5 ) + 0.5 );
	nodeVar53 = ( ( ( dot( vec2<f32>( -0.9979, -0.0648 ), nodeVar20 ) * 0.31321960618145567 ) - ( object.nodeUniform1 * 0.7362211060430895 ) ) + 0.33144367460928875 );
	nodeVar54 = sin( nodeVar53 );
	nodeVar55 = ( ( nodeVar54 * 0.5 ) + 0.5 );
	nodeVar56 = ( ( ( dot( vec2<f32>( -0.9303, -0.3668 ), nodeVar20 ) * 0.2915631229698376 ) - ( object.nodeUniform1 * 0.7103135359046289 ) ) + 5.59819089683915 );
	nodeVar57 = sin( nodeVar56 );
	nodeVar58 = ( ( nodeVar57 * 0.5 ) + 0.5 );
	nodeVar59 = ( ( ( dot( vec2<f32>( -0.7647, -0.6444 ), nodeVar20 ) * 0.36466542658154383 ) - ( object.nodeUniform1 * 0.7943850993394428 ) ) + 1.5282420422747962 );
	nodeVar60 = sin( nodeVar59 );
	nodeVar61 = ( ( nodeVar60 * 0.5 ) + 0.5 );
	nodeVar62 = ( ( ( dot( vec2<f32>( -0.5166, -0.8563 ), nodeVar20 ) * 0.39943962492053403 ) - ( object.nodeUniform1 * 0.8313987490314052 ) ) + 5.5949659313329345 );
	nodeVar63 = sin( nodeVar62 );
	nodeVar64 = ( ( nodeVar63 * 0.5 ) + 0.5 );
	nodeVar65 = ( ( ( dot( vec2<f32>( -0.2276, -0.9737 ), nodeVar20 ) * 0.4180429341317366 ) - ( object.nodeUniform1 * 0.8505390107620132 ) ) + 0.4345941566544691 );
	nodeVar66 = sin( nodeVar65 );
	nodeVar67 = ( ( nodeVar66 * 0.5 ) + 0.5 );
	nodeVar68 = ( ( ( dot( vec2<f32>( 0.1505, -0.9886 ), nodeVar20 ) * 0.5691291032608696 ) - ( object.nodeUniform1 * 0.9924055658486013 ) ) + 5.530018165763443 );
	nodeVar69 = sin( nodeVar68 );
	nodeVar70 = ( ( nodeVar69 * 0.5 ) + 0.5 );
	nodeVar71 = ( ( ( dot( vec2<f32>( 0.4309, -0.9024 ), nodeVar20 ) * 0.6734389389067524 ) - ( object.nodeUniform1 * 1.0795255016696514 ) ) + 0.6440417181639329 );
	nodeVar72 = sin( nodeVar71 );
	nodeVar73 = ( ( nodeVar72 * 0.5 ) + 0.5 );
	nodeVar74 = ( ( ( dot( vec2<f32>( 0.5983, -0.8013 ), nodeVar20 ) * 0.7059758764044944 ) - ( object.nodeUniform1 * 1.1052963215825677 ) ) + 5.087161441303587 );
	nodeVar75 = sin( nodeVar74 );
	nodeVar76 = ( ( nodeVar75 * 0.5 ) + 0.5 );
	nodeVar77 = ( ( ( dot( vec2<f32>( 0.8359, -0.5488 ), nodeVar20 ) * 0.7699981985294118 ) - ( object.nodeUniform1 * 1.154326454077862 ) ) + 6.0900466283169115 );
	nodeVar78 = sin( nodeVar77 );
	nodeVar79 = ( ( nodeVar78 * 0.5 ) + 0.5 );
	nodeVar80 = ( ( ( dot( vec2<f32>( 0.9869, -0.1611 ), nodeVar20 ) * 0.9119282002902759 ) - ( object.nodeUniform1 * 1.2562154113650723 ) ) + 1.7528584445014586 );
	nodeVar81 = sin( nodeVar80 );
	nodeVar82 = ( ( nodeVar81 * 0.5 ) + 0.5 );
	nodeVar83 = ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( 0.0 + ( ( ( nodeVar25 * nodeVar25 ) - 0.333 ) * 1.7655 ) ) + ( ( ( nodeVar28 * nodeVar28 ) - 0.333 ) * 1.3079 ) ) + ( ( ( nodeVar31 * nodeVar31 ) - 0.333 ) * 1.49435 ) ) + ( ( ( nodeVar34 * nodeVar34 ) - 0.333 ) * 0.8547000000000001 ) ) + ( ( ( nodeVar37 * nodeVar37 ) - 0.333 ) * 1.35135 ) ) + ( ( ( nodeVar40 * nodeVar40 ) - 0.333 ) * 0.6534 ) ) + ( ( ( nodeVar43 * nodeVar43 ) - 0.333 ) * 0.9740500000000001 ) ) + ( ( ( nodeVar46 * nodeVar46 ) - 0.333 ) * 0.52305 ) ) + ( ( ( nodeVar49 * nodeVar49 ) - 0.333 ) * 0.4686 ) ) + ( ( ( nodeVar52 * nodeVar52 ) - 0.333 ) * 0.5890500000000001 ) ) + ( ( ( nodeVar55 * nodeVar55 ) - 0.333 ) * 0.39545 ) ) + ( ( ( nodeVar58 * nodeVar58 ) - 0.333 ) * 0.39435000000000003 ) ) + ( ( ( nodeVar61 * nodeVar61 ) - 0.333 ) * 0.43010000000000004 ) ) + ( ( ( nodeVar64 * nodeVar64 ) - 0.333 ) * 0.33385000000000004 ) ) + ( ( ( nodeVar67 * nodeVar67 ) - 0.333 ) * 0.40095000000000003 ) ) + ( ( ( nodeVar70 * nodeVar70 ) - 0.333 ) * 0.30360000000000004 ) ) + ( ( ( nodeVar73 * nodeVar73 ) - 0.333 ) * 0.33 ) ) + ( ( ( nodeVar76 * nodeVar76 ) - 0.333 ) * 0.2651 ) ) + ( ( ( nodeVar79 * nodeVar79 ) - 0.333 ) * 0.29590000000000005 ) ) + ( ( ( nodeVar82 * nodeVar82 ) - 0.333 ) * 0.27280000000000004 ) );
	nodeVar84 = cos( nodeVar23 );
	nodeVar85 = ( ( nodeVar25 * nodeVar84 ) * 0.2407065996994684 );
	nodeVar86 = cos( nodeVar26 );
	nodeVar87 = ( ( nodeVar28 * nodeVar86 ) * 0.190490914554242 );
	nodeVar88 = cos( nodeVar29 );
	nodeVar89 = ( ( nodeVar31 * nodeVar88 ) * 0.2667029669948871 );
	nodeVar90 = cos( nodeVar32 );
	nodeVar91 = ( ( nodeVar34 * nodeVar90 ) * 0.1582274153185033 );
	nodeVar92 = cos( nodeVar35 );
	nodeVar93 = ( ( nodeVar37 * nodeVar92 ) * 0.2873847505552547 );
	nodeVar94 = cos( nodeVar38 );
	nodeVar95 = ( ( nodeVar40 * nodeVar94 ) * 0.1774938726770428 );
	nodeVar96 = cos( nodeVar41 );
	nodeVar97 = ( ( nodeVar43 * nodeVar96 ) * 0.32450353348170735 );
	nodeVar98 = cos( nodeVar44 );
	nodeVar99 = ( ( nodeVar46 * nodeVar98 ) * 0.19573675230285886 );
	nodeVar100 = cos( nodeVar47 );
	nodeVar101 = ( ( nodeVar49 * nodeVar100 ) * 0.2135098355025381 );
	nodeVar102 = cos( nodeVar50 );
	nodeVar103 = ( ( nodeVar52 * nodeVar102 ) * 0.2582770621748081 );
	nodeVar104 = cos( nodeVar53 );
	nodeVar105 = ( ( nodeVar55 * nodeVar104 ) * 0.2477253865289133 );
	nodeVar106 = cos( nodeVar56 );
	nodeVar107 = ( ( nodeVar58 * nodeVar106 ) * 0.22995583508631093 );
	nodeVar108 = cos( nodeVar59 );
	nodeVar109 = ( ( nodeVar61 * nodeVar108 ) * 0.313685199945444 );
	nodeVar110 = cos( nodeVar62 );
	nodeVar111 = ( ( nodeVar64 * nodeVar110 ) * 0.2667058375594406 );
	nodeVar112 = cos( nodeVar65 );
	nodeVar113 = ( ( nodeVar67 * nodeVar112 ) * 0.3352286288802396 );
	nodeVar114 = cos( nodeVar68 );
	nodeVar115 = ( ( nodeVar70 * nodeVar114 ) * 0.3455751915000001 );
	nodeVar116 = cos( nodeVar71 );
	nodeVar117 = ( ( nodeVar73 * nodeVar116 ) * 0.4444696996784566 );
	nodeVar118 = cos( nodeVar74 );
	nodeVar119 = ( ( nodeVar76 * nodeVar118 ) * 0.37430840966966294 );
	nodeVar120 = cos( nodeVar77 );
	nodeVar121 = ( ( nodeVar79 * nodeVar120 ) * 0.45568493388970593 );
	nodeVar122 = cos( nodeVar80 );
	nodeVar123 = ( ( nodeVar82 * nodeVar122 ) * 0.4975480260783746 );
	nodeVar124 = ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( 0.0 + ( nodeVar85 * 0.9936 ) ) + ( nodeVar87 * 0.9157 ) ) + ( nodeVar89 * 0.7585 ) ) + ( nodeVar91 * 0.4565 ) ) + ( nodeVar93 * 0.1923 ) ) + ( nodeVar95 * -0.0506 ) ) + ( nodeVar97 * -0.4173 ) ) + ( nodeVar99 * -0.6739 ) ) + ( nodeVar101 * -0.8617 ) ) + ( nodeVar103 * -0.9553 ) ) + ( nodeVar105 * -0.9979 ) ) + ( nodeVar107 * -0.9303 ) ) + ( nodeVar109 * -0.7647 ) ) + ( nodeVar111 * -0.5166 ) ) + ( nodeVar113 * -0.2276 ) ) + ( nodeVar115 * 0.1505 ) ) + ( nodeVar117 * 0.4309 ) ) + ( nodeVar119 * 0.5983 ) ) + ( nodeVar121 * 0.8359 ) ) + ( nodeVar123 * 0.9869 ) );
	nodeVar125 = ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( 0.0 + ( nodeVar85 * 0.1132 ) ) + ( nodeVar87 * 0.4018 ) ) + ( nodeVar89 * 0.6517 ) ) + ( nodeVar91 * 0.8897 ) ) + ( nodeVar93 * 0.9813 ) ) + ( nodeVar95 * 0.9987 ) ) + ( nodeVar97 * 0.9088 ) ) + ( nodeVar99 * 0.7388 ) ) + ( nodeVar101 * 0.5075 ) ) + ( nodeVar103 * 0.2958 ) ) + ( nodeVar105 * -0.0648 ) ) + ( nodeVar107 * -0.3668 ) ) + ( nodeVar109 * -0.6444 ) ) + ( nodeVar111 * -0.8563 ) ) + ( nodeVar113 * -0.9737 ) ) + ( nodeVar115 * -0.9886 ) ) + ( nodeVar117 * -0.9024 ) ) + ( nodeVar119 * -0.8013 ) ) + ( nodeVar121 * -0.5488 ) ) + ( nodeVar123 * -0.1611 ) );
	nodeVar126 = ( ( nodeVar124 * nodeVar124 ) + ( nodeVar125 * nodeVar125 ) );
	nodeVar127 = ( ( nodeVar20 * vec2<f32>( 0.5 ) ) + vec2<f32>( ( object.nodeUniform1 * 0.1 ), ( object.nodeUniform1 * 0.05 ) ) );
	nodeVar128 = floor( nodeVar127 );
	nodeVar129 = fract( nodeVar127 );
	nodeVar130 = ( ( nodeVar129 * nodeVar129 ) * ( vec2<f32>( 3.0 ) - ( nodeVar129 * vec2<f32>( 2.0 ) ) ) );
	nodeVar131 = ( ( nodeVar20 * vec2<f32>( 1.3 ) ) - vec2<f32>( ( object.nodeUniform1 * 0.06 ), ( object.nodeUniform1 * 0.09 ) ) );
	nodeVar132 = floor( nodeVar131 );
	nodeVar133 = fract( nodeVar131 );
	nodeVar134 = ( ( nodeVar133 * nodeVar133 ) * ( vec2<f32>( 3.0 ) - ( nodeVar133 * vec2<f32>( 2.0 ) ) ) );
	nodeVar135 = ( ( nodeVar20 * vec2<f32>( 3.0 ) ) + vec2<f32>( ( object.nodeUniform1 * 0.04 ), ( object.nodeUniform1 * -0.07 ) ) );
	nodeVar136 = floor( nodeVar135 );
	nodeVar137 = fract( nodeVar135 );
	nodeVar138 = ( ( nodeVar137 * nodeVar137 ) * ( vec2<f32>( 3.0 ) - ( nodeVar137 * vec2<f32>( 2.0 ) ) ) );
	nodeVar139 = ( ( ( smoothstep( 0.28600000000000003, 0.8525000000000001, nodeVar83 ) * smoothstep( 0.12, 0.58, nodeVar126 ) ) * smoothstep( 0.56, 0.78, ( ( ( mix( mix( fract( ( sin( dot( nodeVar128, vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar128 + vec2<f32>( 1.0, 0.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar130.x ), mix( fract( ( sin( dot( ( nodeVar128 + vec2<f32>( 0.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar128 + vec2<f32>( 1.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar130.x ), nodeVar130.y ) * 0.42 ) + ( mix( mix( fract( ( sin( dot( nodeVar132, vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar132 + vec2<f32>( 1.0, 0.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar134.x ), mix( fract( ( sin( dot( ( nodeVar132 + vec2<f32>( 0.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar132 + vec2<f32>( 1.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar134.x ), nodeVar134.y ) * 0.34 ) ) + ( mix( mix( fract( ( sin( dot( nodeVar136, vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar136 + vec2<f32>( 1.0, 0.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar138.x ), mix( fract( ( sin( dot( ( nodeVar136 + vec2<f32>( 0.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), fract( ( sin( dot( ( nodeVar136 + vec2<f32>( 1.0, 1.0 ) ), vec2<f32>( 127.1, 311.7 ) ) ) * 43758.5453 ) ), nodeVar138.x ), nodeVar138.y ) * 0.24 ) ) ) ) * 0.74 );
	nodeVar140 = smoothstep( 0.0, 3200.0, nodeVar21 );
	nodeVar141 = clamp( ( nodeVar139 * nodeVar140 ), 0.0, 1.0 );
	DiffuseColor = vec4<f32>( sRGBTransferEOTF( mix( mix( mix( vec3<f32>( 0.66, 0.58, 0.4 ), vec3<f32>( 0.22, 0.58, 0.6 ), smoothstep( 0.04, 0.26, nodeVar22 ) ), vec3<f32>( 0.025, 0.095, 0.22 ), nodeVar22 ), vec3<f32>( 0.92, 0.93, 0.94 ), nodeVar141 ) ), 1.0 );
	DiffuseColor.w = ( DiffuseColor.w * object.nodeUniform2 );
	DiffuseColor.w = 1.0;
	Metalness = object.nodeUniform3;
	Roughness = min( ( max( mix( 0.105, 0.78, nodeVar141 ), 0.0525 ) + 0.0 ), 1.0 );
	SpecularColor = vec3<f32>( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3<f32>( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3<f32>( ( 1.0 - object.nodeUniform3 ) ) );
	EmissiveColor = ( object.nodeUniform4 * vec3<f32>( object.nodeUniform5 ) );
	nodeVar142 = normalize( vec3<f32>( ( - nodeVar124 ), ( - nodeVar125 ), 1.0 ) );
	nodeVar143 = length( ( nodeVar20 - object.nodeUniform8 ) );
	nodeVar144 = smoothstep( 720.0, 2300.0, nodeVar143 );
	nodeVar145 = mix( 0.84, 0.18, nodeVar144 );
	normalView = normalize( ( render.cameraViewMatrix * vec4<f32>( ( object.nodeUniform7 * normalize( mix( vec3<f32>( 0.0, 0.0, 1.0 ), nodeVar142, ( mix( 0.3, 1.0, nodeVar140 ) * nodeVar145 ) ) ) ), 0.0 ) ).xyz );
	nodeVar146 = ( render.nodeUniform9 - render.nodeUniform10 );
	nodeVar147 = vec4<f32>( nodeVar146, 0.0 );
	nodeVar148 = ( render.cameraViewMatrix * nodeVar147 );
	nodeVar149 = normalize( nodeVar148.xyz );
	nodeVar150 = nodeVar149;
	nodeVar151 = dot( normalView, nodeVar150 );
	nodeVar152 = ( vec3<f32>( clamp( nodeVar151, 0.0, 1.0 ) ) * render.nodeUniform11 );
	nodeVar153 = nodeVar152;
	directDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar154 = ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) );
	nodeVar155 = ( nodeVar153 * nodeVar154 );
	nodeVar156 = ( directDiffuse + nodeVar155 );
	directDiffuse = nodeVar156;
	directSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	positionViewDirection = normalize( v_positionViewDirection );
	nodeVar157 = normalize( ( nodeVar150 + positionViewDirection ) );
	nodeVar158 = clamp( dot( positionViewDirection, nodeVar157 ), 0.0, 1.0 );
	nodeVar159 = exp2( ( ( ( nodeVar158 * -5.55473 ) - 6.98316 ) * nodeVar158 ) );
	nodeVar160 = ( Roughness * Roughness );
	nodeVar161 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( Roughness, clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) );
	nodeVar162 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( Roughness, clamp( dot( normalView, nodeVar150 ), 0.0, 1.0 ) ) );
	nodeVar163 = ( SpecularColorBlended + ( ( vec3<f32>( 1.0 ) - SpecularColorBlended ) * vec3<f32>( 0.047619 ) ) );
	nodeVar164 = ( 1.0 - ( nodeVar161.xy.x + nodeVar161.xy.y ) );
	nodeVar165 = ( 1.0 - ( nodeVar162.xy.x + nodeVar162.xy.y ) );
	nodeVar166 = ( ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeVar159 ) ) ) + vec3<f32>( ( 1.0 * nodeVar159 ) ) ) * vec3<f32>( V_GGX_SmithCorrelated( nodeVar160, clamp( dot( normalView, nodeVar150 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( D_GGX( nodeVar160, clamp( dot( normalView, nodeVar157 ), 0.0, 1.0 ) ) ) ) + ( ( ( ( ( ( SpecularColorBlended * vec3<f32>( nodeVar161.xy.x ) ) + vec3<f32>( ( 1.0 * nodeVar161.xy.y ) ) ) * ( ( SpecularColorBlended * vec3<f32>( nodeVar162.xy.x ) ) + vec3<f32>( ( 1.0 * nodeVar162.xy.y ) ) ) ) * nodeVar163 ) / ( ( vec3<f32>( 1.0 ) - ( ( vec3<f32>( ( nodeVar164 * nodeVar165 ) ) * nodeVar163 ) * nodeVar163 ) ) + vec3<f32>( 0.000001 ) ) ) * vec3<f32>( ( nodeVar164 * nodeVar165 ) ) ) );
	nodeVar167 = ( nodeVar153 * nodeVar166 );
	nodeVar168 = ( directSpecular + nodeVar167 );
	directSpecular = nodeVar168;
	radiance = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar169 = clamp( roughnessToMip( Roughness ), -2.0, object.nodeUniform15 );
	nodeVar170 = floor( nodeVar169 );
	nodeVar171 = nodeVar170;
	nodeVar172 = normalize( ( render.cameraWorldMatrix * vec4<f32>( normalize( mix( reflect( ( - positionViewDirection ), normalView ), normalView, ( ( ( Roughness * Roughness ) * Roughness ) * Roughness ) ) ), 0.0 ) ).xyz );
	nodeVar173 = getFace( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( nodeVar172.x, ( - nodeVar172.y ), nodeVar172.z ), 1.0 ) ).xyz );
	nodeVar174 = max( ( 4.0 - nodeVar171 ), 0.0 );
	nodeVar171 = max( nodeVar171, 4.0 );
	nodeVar175 = exp2( nodeVar171 );
	nodeVar176 = ( ( getUV( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( nodeVar172.x, ( - nodeVar172.y ), nodeVar172.z ), 1.0 ) ).xyz, nodeVar173 ) * vec2<f32>( ( nodeVar175 - 2.0 ) ) ) + vec2<f32>( 1.0 ) );

	if ( ( nodeVar173 > 2.0 ) ) {

		nodeVar176.y = ( nodeVar176.y + nodeVar175 );
		nodeVar173 = ( nodeVar173 - 3.0 );
		

	}

	nodeVar176.x = ( nodeVar176.x + ( nodeVar173 * nodeVar175 ) );
	nodeVar176.x = ( nodeVar176.x + ( nodeVar174 * ( 3.0 * 16.0 ) ) );
	nodeVar176.y = ( nodeVar176.y + ( 4.0 * ( exp2( object.nodeUniform15 ) - nodeVar175 ) ) );
	nodeVar176.x = ( nodeVar176.x * object.nodeUniform18 );
	nodeVar176.y = ( nodeVar176.y * object.nodeUniform19 );
	nodeVar177 = textureSampleGrad( nodeUniform20, nodeUniform20_sampler, nodeVar176, vec2<f32>( 0.0, 0.0 ), vec2<f32>( 0.0, 0.0 ) );
	nodeVar178 = nodeVar177.xyz;
	nodeVar179 = fract( nodeVar169 );

	if ( ( nodeVar179 != 0.0 ) ) {

		nodeVar180 = ( nodeVar170 + 1.0 );
		nodeVar181 = getFace( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( nodeVar172.x, ( - nodeVar172.y ), nodeVar172.z ), 1.0 ) ).xyz );
		nodeVar182 = max( ( 4.0 - nodeVar180 ), 0.0 );
		nodeVar180 = max( nodeVar180, 4.0 );
		nodeVar183 = exp2( nodeVar180 );
		nodeVar184 = ( ( getUV( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( nodeVar172.x, ( - nodeVar172.y ), nodeVar172.z ), 1.0 ) ).xyz, nodeVar181 ) * vec2<f32>( ( nodeVar183 - 2.0 ) ) ) + vec2<f32>( 1.0 ) );

		if ( ( nodeVar181 > 2.0 ) ) {

			nodeVar184.y = ( nodeVar184.y + nodeVar183 );
			nodeVar181 = ( nodeVar181 - 3.0 );
			

		}

		nodeVar184.x = ( nodeVar184.x + ( nodeVar181 * nodeVar183 ) );
		nodeVar184.x = ( nodeVar184.x + ( nodeVar182 * ( 3.0 * 16.0 ) ) );
		nodeVar184.y = ( nodeVar184.y + ( 4.0 * ( exp2( object.nodeUniform15 ) - nodeVar183 ) ) );
		nodeVar184.x = ( nodeVar184.x * object.nodeUniform18 );
		nodeVar184.y = ( nodeVar184.y * object.nodeUniform19 );
		nodeVar185 = textureSampleGrad( nodeUniform20, nodeUniform20_sampler, nodeVar184, vec2<f32>( 0.0, 0.0 ), vec2<f32>( 0.0, 0.0 ) );
		nodeVar186 = nodeVar185.xyz;
		nodeVar178 = mix( nodeVar178, nodeVar186, nodeVar179 );
		

	}

	nodeVar187 = ( radiance + ( nodeVar178 * vec3<f32>( object.nodeUniform21 ) ) );
	radiance = nodeVar187;
	iblIrradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar188 = clamp( roughnessToMip( 1.0 ), -2.0, object.nodeUniform15 );
	nodeVar189 = floor( nodeVar188 );
	nodeVar190 = nodeVar189;
	normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
	nodeVar191 = getFace( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( normalWorld.x, ( - normalWorld.y ), normalWorld.z ), 1.0 ) ).xyz );
	nodeVar192 = max( ( 4.0 - nodeVar190 ), 0.0 );
	nodeVar190 = max( nodeVar190, 4.0 );
	nodeVar193 = exp2( nodeVar190 );
	nodeVar194 = ( ( getUV( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( normalWorld.x, ( - normalWorld.y ), normalWorld.z ), 1.0 ) ).xyz, nodeVar191 ) * vec2<f32>( ( nodeVar193 - 2.0 ) ) ) + vec2<f32>( 1.0 ) );

	if ( ( nodeVar191 > 2.0 ) ) {

		nodeVar194.y = ( nodeVar194.y + nodeVar193 );
		nodeVar191 = ( nodeVar191 - 3.0 );
		

	}

	nodeVar194.x = ( nodeVar194.x + ( nodeVar191 * nodeVar193 ) );
	nodeVar194.x = ( nodeVar194.x + ( nodeVar192 * ( 3.0 * 16.0 ) ) );
	nodeVar194.y = ( nodeVar194.y + ( 4.0 * ( exp2( object.nodeUniform15 ) - nodeVar193 ) ) );
	nodeVar194.x = ( nodeVar194.x * object.nodeUniform18 );
	nodeVar194.y = ( nodeVar194.y * object.nodeUniform19 );
	nodeVar195 = textureSampleGrad( nodeUniform20, nodeUniform20_sampler, nodeVar194, vec2<f32>( 0.0, 0.0 ), vec2<f32>( 0.0, 0.0 ) );
	nodeVar196 = nodeVar195.xyz;
	nodeVar197 = fract( nodeVar188 );

	if ( ( nodeVar197 != 0.0 ) ) {

		nodeVar198 = ( nodeVar189 + 1.0 );
		nodeVar199 = getFace( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( normalWorld.x, ( - normalWorld.y ), normalWorld.z ), 1.0 ) ).xyz );
		nodeVar200 = max( ( 4.0 - nodeVar198 ), 0.0 );
		nodeVar198 = max( nodeVar198, 4.0 );
		nodeVar201 = exp2( nodeVar198 );
		nodeVar202 = ( ( getUV( ( object.nodeUniform16 * vec4<f32>( vec3<f32>( normalWorld.x, ( - normalWorld.y ), normalWorld.z ), 1.0 ) ).xyz, nodeVar199 ) * vec2<f32>( ( nodeVar201 - 2.0 ) ) ) + vec2<f32>( 1.0 ) );

		if ( ( nodeVar199 > 2.0 ) ) {

			nodeVar202.y = ( nodeVar202.y + nodeVar201 );
			nodeVar199 = ( nodeVar199 - 3.0 );
			

		}

		nodeVar202.x = ( nodeVar202.x + ( nodeVar199 * nodeVar201 ) );
		nodeVar202.x = ( nodeVar202.x + ( nodeVar200 * ( 3.0 * 16.0 ) ) );
		nodeVar202.y = ( nodeVar202.y + ( 4.0 * ( exp2( object.nodeUniform15 ) - nodeVar201 ) ) );
		nodeVar202.x = ( nodeVar202.x * object.nodeUniform18 );
		nodeVar202.y = ( nodeVar202.y * object.nodeUniform19 );
		nodeVar203 = textureSampleGrad( nodeUniform20, nodeUniform20_sampler, nodeVar202, vec2<f32>( 0.0, 0.0 ), vec2<f32>( 0.0, 0.0 ) );
		nodeVar204 = nodeVar203.xyz;
		nodeVar196 = mix( nodeVar196, nodeVar204, nodeVar197 );
		

	}

	nodeVar205 = ( iblIrradiance + ( ( nodeVar196 * vec3<f32>( 3.141592653589793 ) ) * vec3<f32>( object.nodeUniform21 ) ) );
	iblIrradiance = nodeVar205;
	irradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar206 = ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) );
	nodeVar207 = ( irradiance * nodeVar206 );
	nodeVar208 = nodeVar207;
	indirectDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar209 = ( indirectDiffuse + nodeVar208 );
	indirectDiffuse = nodeVar209;
	singleScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	singleScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar210 = dot( normalView, positionViewDirection );
	nodeVar211 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( Roughness, clamp( nodeVar210, 0.0, 1.0 ) ) );
	nodeVar212 = ( SpecularColor * vec3<f32>( nodeVar211.xy.x ) );
	nodeVar213 = ( SpecularF90 * nodeVar211.xy.y );
	nodeVar214 = ( nodeVar212 + vec3<f32>( nodeVar213 ) );
	nodeVar215 = ( singleScatteringDielectric + nodeVar214 );
	singleScatteringDielectric = nodeVar215;
	nodeVar216 = ( vec3<f32>( 1.0 ) - SpecularColor );
	nodeVar217 = nodeVar216;
	nodeVar218 = ( nodeVar217 * vec3<f32>( 0.047619 ) );
	nodeVar219 = ( SpecularColor + nodeVar218 );
	nodeVar220 = ( nodeVar214 * nodeVar219 );
	nodeVar221 = ( nodeVar211.xy.x + nodeVar211.xy.y );
	nodeVar222 = ( 1.0 - nodeVar221 );
	nodeVar223 = nodeVar222;
	nodeVar224 = ( vec3<f32>( nodeVar223 ) * nodeVar219 );
	nodeVar225 = ( vec3<f32>( 1.0 ) - nodeVar224 );
	nodeVar226 = nodeVar225;
	nodeVar227 = ( nodeVar220 / nodeVar226 );
	nodeVar228 = ( nodeVar227 * vec3<f32>( nodeVar223 ) );
	nodeVar229 = ( multiScatteringDielectric + nodeVar228 );
	multiScatteringDielectric = nodeVar229;
	nodeVar230 = dot( normalView, positionViewDirection );
	nodeVar231 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( Roughness, clamp( nodeVar230, 0.0, 1.0 ) ) );
	nodeVar232 = ( DiffuseColor.xyz * vec3<f32>( nodeVar231.xy.x ) );
	nodeVar233 = ( SpecularF90 * nodeVar231.xy.y );
	nodeVar234 = ( nodeVar232 + vec3<f32>( nodeVar233 ) );
	nodeVar235 = ( singleScatteringMetallic + nodeVar234 );
	singleScatteringMetallic = nodeVar235;
	nodeVar236 = ( vec3<f32>( 1.0 ) - DiffuseColor.xyz );
	nodeVar237 = nodeVar236;
	nodeVar238 = ( nodeVar237 * vec3<f32>( 0.047619 ) );
	nodeVar239 = ( DiffuseColor.xyz + nodeVar238 );
	nodeVar240 = ( nodeVar234 * nodeVar239 );
	nodeVar241 = ( nodeVar231.xy.x + nodeVar231.xy.y );
	nodeVar242 = ( 1.0 - nodeVar241 );
	nodeVar243 = nodeVar242;
	nodeVar244 = ( vec3<f32>( nodeVar243 ) * nodeVar239 );
	nodeVar245 = ( vec3<f32>( 1.0 ) - nodeVar244 );
	nodeVar246 = nodeVar245;
	nodeVar247 = ( nodeVar240 / nodeVar246 );
	nodeVar248 = ( nodeVar247 * vec3<f32>( nodeVar243 ) );
	nodeVar249 = ( multiScatteringMetallic + nodeVar248 );
	multiScatteringMetallic = nodeVar249;
	nodeVar250 = mix( singleScatteringDielectric, singleScatteringMetallic, Metalness );
	nodeVar251 = ( radiance * nodeVar250 );
	nodeVar252 = mix( multiScatteringDielectric, multiScatteringMetallic, Metalness );
	nodeVar253 = ( iblIrradiance * vec3<f32>( 0.3183098861837907 ) );
	nodeVar254 = ( nodeVar252 * nodeVar253 );
	nodeVar255 = ( nodeVar251 + nodeVar254 );
	nodeVar256 = nodeVar255;
	nodeVar257 = ( singleScatteringDielectric + multiScatteringDielectric );
	nodeVar258 = ( vec3<f32>( 1.0 ) - nodeVar257 );
	nodeVar259 = nodeVar258;
	nodeVar260 = ( DiffuseContribution * nodeVar259 );
	nodeVar261 = ( nodeVar260 * nodeVar253 );
	nodeVar262 = nodeVar261;
	indirectSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	nodeVar263 = ( indirectSpecular + nodeVar256 );
	indirectSpecular = nodeVar263;
	nodeVar264 = ( indirectDiffuse + nodeVar262 );
	indirectDiffuse = nodeVar264;
	ambientOcclusion = 1.0;
	nodeVar265 = ( indirectDiffuse * vec3<f32>( ambientOcclusion ) );
	indirectDiffuse = nodeVar265;
	nodeVar266 = dot( normalView, positionViewDirection );
	nodeVar267 = ( clamp( nodeVar266, 0.0, 1.0 ) + ambientOcclusion );
	nodeVar268 = ( Roughness * -16.0 );
	nodeVar269 = ( 1.0 - nodeVar268 );
	nodeVar270 = nodeVar269;
	nodeVar271 = ( - nodeVar270 );
	nodeVar272 = exp2( nodeVar271 );
	nodeVar273 = pow( nodeVar267, nodeVar272 );
	nodeVar274 = ( 1.0 - nodeVar273 );
	nodeVar275 = nodeVar274;
	nodeVar276 = ( ambientOcclusion - nodeVar275 );
	nodeVar277 = ( indirectSpecular * vec3<f32>( clamp( nodeVar276, 0.0, 1.0 ) ) );
	indirectSpecular = nodeVar277;
	nodeVar278 = ( directDiffuse + indirectDiffuse );
	totalDiffuse = nodeVar278;
	nodeVar279 = ( directSpecular + indirectSpecular );
	totalSpecular = nodeVar279;
	nodeVar280 = ( totalDiffuse + totalSpecular );
	outgoingLight = nodeVar280;
	Output = max( vec4<f32>( ( outgoingLight + EmissiveColor ), DiffuseColor.w ), vec4<f32>( 0.0 ) );
	nodeVar281 = ( v_positionWorld - vec3<f32>( 0.0, 0.0, 0.0 ) );
	nodeVar282 = length( nodeVar281 );
	nodeVar283 = max( ( ( nodeVar282 / 1000.0 ) - 0.07 ), 0.0 );
	nodeVar284 = ( pow( ( max( ( nodeVar282 - 70.0 ), 0.0 ) / 1700.0 ), 1.28 ) * 0.34 );
	nodeVar285 = ( ( 1.0 - smoothstep( 8.0, 46.0, v_positionWorld.z ) ) * smoothstep( 520.0, 1600.0, nodeVar282 ) );
	nodeVar286 = exp( ( - ( ( ( vec3<f32>( 0.06549479999999999, 0.1011724, 0.19106559999999997 ) * vec3<f32>( nodeVar283 ) ) + vec3<f32>( nodeVar284 ) ) + vec3<f32>( ( nodeVar285 * 0.08 ) ) ) ) );
	nodeVar287 = normalize( ( v_positionWorld - render.cameraPosition ) );
	nodeVar288 = textureSample( nodeUniform22, nodeUniform22_sampler, vec2<f32>( ( ( atan2( nodeVar287.z, nodeVar287.x ) * 0.15915494309189535 ) + 0.5 ), ( ( asin( clamp( nodeVar287.y, -1.0, 1.0 ) ) * 0.3183098861837907 ) + 0.5 ) ) );
	nodeVar289 = nodeVar288.xyz;
	nodeVar290 = normalize( vec3<f32>( nodeVar287.x, nodeVar287.y, 0.004 ) );
	nodeVar291 = textureSample( nodeUniform22, nodeUniform22_sampler, vec2<f32>( ( ( atan2( nodeVar290.z, nodeVar290.x ) * 0.15915494309189535 ) + 0.5 ), ( ( asin( clamp( nodeVar290.y, -1.0, 1.0 ) ) * 0.3183098861837907 ) + 0.5 ) ) );
	nodeVar292 = vec4<f32>( ( ( Output.xyz * nodeVar286 ) + ( mix( mix( mix( nodeVar289, nodeVar291.xyz, ( smoothstep( -0.38, 0.0, nodeVar287.z ) * ( 1.0 - smoothstep( 0.0, 0.14, nodeVar287.z ) ) ) ), vec3<f32>( 1.0, 0.8, 0.52 ), ( pow( clamp( dot( nodeVar287, vec3<f32>( -0.9393727128473789, 1.1503997859949083e-16, 0.34289780745545134 ) ), 0.0, 1.0 ), 3.4 ) * 0.34 ) ), vec3<f32>( 0.84, 0.82, 0.72 ), ( nodeVar285 * 0.18 ) ) * ( vec3<f32>( 1.0, 1.0, 1.0 ) - nodeVar286 ) ) ), Output.w );
	Output = nodeVar292;

	// result

	output.color = nodeVar292;

	return output;

}
