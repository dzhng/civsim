from pathlib import Path
import subprocess,os,signal,json
root=Path.cwd();pid=54344;log=root/'throwaway/validation-wait-diagnostic/review-pause.json'
cmd=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True)
assert 'claude -p --model opus --effort high --tools Read,Grep,Glob' in cmd,cmd
cwd=subprocess.check_output(['lsof','-a','-p',str(pid),'-d','cwd','-Fn'],text=True)
assert '\nn'+str(root)+'\n' in cwd,cwd
assert subprocess.run(['pgrep','-P',str(pid)],stdout=subprocess.DEVNULL).returncode==1,'Review has live child; do not measure'
os.kill(pid,signal.SIGSTOP)
try:
 assert subprocess.run(['pgrep','-P',str(pid)],stdout=subprocess.DEVNULL).returncode==1,'Child raced pause; do not measure'
 log.write_text(json.dumps({'pid':pid,'state':'stopped for validation diagnostic','command':cmd.strip()}))
 result=subprocess.run(['node','throwaway/validation-wait-diagnostic/run.mjs'])
finally:
 try:os.kill(pid,signal.SIGCONT)
 except ProcessLookupError:pass
 log.write_text(json.dumps({'pid':pid,'state':'resumed after validation diagnostic','command':cmd.strip()}))
raise SystemExit(result.returncode)
