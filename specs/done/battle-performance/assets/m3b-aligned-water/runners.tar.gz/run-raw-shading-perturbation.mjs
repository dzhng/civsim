// SCRATCH, NOT SHIPPING CODE. Prepared, not run.
//
// Serves the perturbed build and reports both gates. EXPECTED: aligned.passed is
// false. A true here means the aligned comparison stopped seeing raw shading.
import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { gzipSync } from "node:zlib";
import { chromium } from "../../web/node_modules/playwright/index.mjs";
import { GPU_HARDWARE_FLAGS } from "../../web/renderer-probe-lib.mjs";

const root = process.cwd();
const out = `${root}/throwaway/aligned-water`;
const server = spawn(
  `${root}/web/node_modules/.bin/vite`,
  [
    "preview",
    "--config",
    "apps/battle-perf-lab/src/raw/water.vite.config.mts",
    "--outDir",
    `${out}/dist`,
    "--port",
    "5299",
    "--strictPort",
  ],
  { cwd: root, stdio: ["ignore", "pipe", "pipe"] },
);
let log = "";
server.stdout.on("data", (b) => (log += b));
server.stderr.on("data", (b) => (log += b));

let browser;
try {
  await new Promise((resolve, reject) => {
    const start = Date.now();
    const poll = setInterval(() => {
      if (log.includes("Local:")) {
        clearInterval(poll);
        resolve();
      } else if (server.exitCode !== null || Date.now() - start > 30000) {
        clearInterval(poll);
        reject(Error(log));
      }
    }, 100);
  });
  browser = await chromium.launch({ channel: "chrome", headless: true, args: GPU_HARDWARE_FLAGS });
  const page = await browser.newPage();
  const errors = [];
  const warnings = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
    if (m.type() === "warning") warnings.push(m.text());
  });
  await page.goto("http://localhost:5299/water-check.html?samples=1");
  await page.waitForFunction(() => window.__waterCheck !== undefined, null, { timeout: 180000 });
  const report = await page.evaluate(() => window.__waterCheck);
  await writeFile(`${out}/perturbed-report.json.gz`, gzipSync(JSON.stringify({ report, errors, warnings })));
  console.log(
    JSON.stringify(
      {
        expectation: "aligned.passed must be false under a raw shading perturbation",
        passed: report.passed,
        alignedPassed: report.aligned?.passed,
        alignedMaxAbs: report.aligned?.results?.map((r) => [r.label, r.comparison.maxAbs]),
        errors,
        warnings,
      },
      null,
      1,
    ),
  );
} finally {
  await browser?.close();
  server.kill("SIGTERM");
  await new Promise((resolve) =>
    server.exitCode !== null ? resolve() : server.once("exit", resolve),
  );
  await writeFile(`${out}/perturbed-server.log`, log);
}
