# Combined kernel-input candidate, before measurement

Control is current production b42782f4… (packed target bodies). Candidate is
98e4d2e6 + c8580623 on codex/battle-target-live-inputs: remove the unread fight_near
counter, defer retained-friend flags, and reuse unit directions during separation.
This measures the two small passes together; no individual speedup attribution.

Build both as fresh immutable production release-WASM artifacts with the same
flags; assert control byte identity. Run one serialized Node ABBA at canonical
9000–9308 and12000–12308, with all five existing hash assertions. No owned GPU,
build or test overlaps CPU timing. Preserve external host-load uncertainty and
any failed run. Do not rerun because a timing result is disappointing.

Adopt as a combined performance candidate only if both Bs beat both As at both
windows with all hashes unchanged. Otherwise inspect the result before choosing
a smaller next experiment; no weaker performance threshold by silence. Even a
pass remains Node feasibility, not live browser acceptance or30Hz completion.
After adoption, verify canonical worker/direct parity and an integrated production
build byte-identical to the measured candidate. The current checkpoint matrix
must finish before builds/timing begin. Scripts refuse existing output.
