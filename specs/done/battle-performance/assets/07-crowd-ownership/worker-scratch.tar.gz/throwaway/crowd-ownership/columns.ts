/** Seeded column fixtures for the crowd-ownership differential oracle.
 *
 * These are the inputs the live facade actually hands the crowd owner: typed
 * position/alive columns, the frontend's per-soldier playback objects (which the
 * frontend mutates in place between frames), static unit/team mapping and a
 * terrain sampler. The playback shapes deliberately cover every retention rule
 * the admitted snapshot has to preserve: endpoint aliasing, shared frozen locals,
 * `{ kind: "base" }` destinations, present/absent rider overlays. */
import type { SoldierPlayback } from "../../packages/crowd-runtime/src/actionTimeline";
import type { CrowdBuildInputs } from "../../packages/crowd-runtime/src/instanceData";

/** One frozen pose array, shared by several soldiers: the readonly contract the
 *  owner must keep by reference rather than copying. */
export const SHARED_LOCALS = Object.freeze([0.5, -1.25, 3, 0.125]);
export const OTHER_LOCALS = Object.freeze([9, 8, 7]);

function rng(seed: number) {
  let x = seed >>> 0;
  return () => {
    x ^= x << 13;
    x >>>= 0;
    x ^= x >>> 17;
    x ^= x << 5;
    x >>>= 0;
    return x / 0x100000000;
  };
}

/** The five playback shapes, chosen by index so every fixture frame contains all
 *  of them. Each returns freshly allocated objects; the caller mutates them in
 *  place across frames exactly as the frontend timeline does. */
export function playbackFor(index: number, appearanceId: number, phase: number): SoldierPlayback {
  const destination = { clip: ["idle", "march", "attack", "die"][index % 4], phase };
  switch (index % 5) {
    case 0:
      // Endpoint aliasing: a held pose samples its own destination.
      return {
        appearanceId,
        base: { source: { kind: "clip", sample: destination }, destination, weight: 1 },
      };
    case 1:
      // A distinct sample object: the source is a different clip mid-transition.
      return {
        appearanceId,
        base: {
          source: { kind: "clip", sample: { clip: "idle", phase: phase * 0.5 } },
          destination,
          weight: 0.25 + phase * 0.5,
        },
      };
    case 2:
      // A frozen source shared with every other soldier of this shape.
      return {
        appearanceId,
        base: { source: { kind: "frozen", locals: SHARED_LOCALS }, destination, weight: phase },
      };
    case 3:
      // A rider overlay whose destination is the base pose itself.
      return {
        appearanceId,
        base: { source: { kind: "frozen", locals: OTHER_LOCALS }, destination, weight: 0.75 },
        riderUpperBody: {
          source: { kind: "clip", sample: { clip: "shoot", phase } },
          destination: { kind: "base" },
          weight: 0.5,
        },
      };
    default:
      // A rider overlay with its own aliased endpoints.
      {
        const upper = { clip: "shoot", phase: 1 - phase };
        return {
          appearanceId,
          base: {
            source: { kind: "clip", sample: { clip: "march", phase } },
            destination,
            weight: 0.9,
          },
          riderUpperBody: {
            source: { kind: "clip", sample: upper },
            destination: upper,
            weight: 0.3,
          },
        };
      }
  }
}

export interface Frame {
  label: string;
  inputs: CrowdBuildInputs;
  /** The live playback objects behind `inputs.playback`, so a test can mutate
   *  them after a submission and prove the admitted records did not follow. */
  playback: SoldierPlayback[];
}

/** Appearance ids used by the fixtures; ids 3 and 4 ride a mount. */
export const APPEARANCE_IDS = [0, 1, 2, 3, 4];
export const MOUNTED_CLASSES = [3, 4];

export function frame(label: string, count: number, seed: number, shift = 0): Frame {
  const random = rng(seed);
  const positions = new Float32Array(count * 2);
  const facings = new Float32Array(count);
  const alive = new Uint8Array(count);
  const soldierUnit = new Uint32Array(count);
  const unitTeam: number[] = [];
  const playback: SoldierPlayback[] = [];
  for (let i = 0; i < count; i++) {
    positions[i * 2] = (random() - 0.5) * 400;
    positions[i * 2 + 1] = (random() - 0.5) * 400;
    facings[i] = (random() - 0.5) * Math.PI * 2;
    alive[i] = random() > 0.2 ? 1 : 0;
    soldierUnit[i] = i % 6;
    playback.push(playbackFor(i + shift, APPEARANCE_IDS[i % APPEARANCE_IDS.length], random()));
  }
  for (let unit = 0; unit < 6; unit++) unitTeam.push(unit % 2);
  return {
    label,
    playback,
    inputs: {
      positions,
      facings,
      alive,
      count,
      soldierUnit,
      unitTeam,
      playback,
      mountedClasses: MOUNTED_CLASSES,
      terrainHeight: (x, y) => Math.sin(x * 0.01) * 3 + Math.cos(y * 0.013) * 2,
    },
  };
}

/** Some frames omit the optional inputs entirely: the facing default follows the
 *  faction, elevation collapses to 0 and nothing may resurrect a previous value. */
export function bareFrame(label: string, count: number, seed: number): Frame {
  const full = frame(label, count, seed);
  return {
    label,
    playback: full.playback,
    inputs: { positions: full.inputs.positions, playback: full.playback, count },
  };
}
