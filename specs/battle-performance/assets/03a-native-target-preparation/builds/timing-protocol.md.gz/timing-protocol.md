# Native feasibility timing protocol (before runs)

No measurements yet. First require candidate correctness, mutation checks and
independent review. Preserve c8580623 as the isolated predecessor; it is not the
production baseline. Production remains the packed-target pass, WASM b42782f4.
The native profiler workload differs from canonical Game (root-workload-audit.md).

The sim already has native parallel work in other passes. A feature-off control
versus feature-on candidate would therefore confound target preparation with
existing parallelism. Build predecessor and candidate both in ordinary serial
configuration and both with parallel enabled at the same fixed four-thread
Rayon configuration. Record one-thread parallel staging overhead against the one-thread predecessor
as a predeclared third pair; this separates batching cost from parallel gain.
Never attribute all feature-on speedup to this new target change.

Use the existing fighting15500 command with earliest tick1500, unless inspection
shows it misses persistent melee; any workload revision must be recorded before
timing. Keep its own initial/final hashes, actual contact/start tick, living and
fighting counts. Do not reuse canonical WASM hashes or the unrelated native35ms
threshold. No instrumentation feature. Build to separate immutable target dirs,
record compiler/flags/source/executable hashes before timing, and serialize fresh
processes with no owned builds/tests/GPU work during measurement. Preserve host
load and warnings; external host activity prevents an absolute release claim.

Run each matched pair once in ABBA order (predecessor, candidate, candidate,
predecessor), with fixed thread count/features within a pair. Existing profiler
internal repeats remain visible; summarize per-invocation means and each repeat,
not a cherry-picked minimum. Compare serial paths, then one-thread staging, then four-thread paths.
All three ABBA pairs are declared before any run; there is no rescue round. All hashes/populations and actual measured windows must match. A useful
parallel result must improve both candidate invocations over both controls;
serial-path regression must be reported separately and resolved before adoption.
A noisy overlap is inconclusive, not permission to repeat unchanged until green.

This result can justify a separate browser/WASM research slice only. Neither
native speed nor passing hashes authorizes production integration of the earlier
unadopted counter/facing changes. Actual browser threading needs new lifecycle,
export-view, deterministic Game and performance evidence.
