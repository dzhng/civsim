// Scratch runner only: the lab's own vitest include covers tests/, report/ and
// trials/, so the live facade and the typegpu candidate's own tests are part of
// no suite today. This config reuses the lab's resolution — plus the bare
// specifiers those trees import, which only the web workspace installs — without
// pulling in src/shadow-control (red at 89365503, retired policy).
import { fileURLToPath } from "node:url";
import base from "../../apps/battle-perf-lab/vitest.config.mts";

const web = (path: string) =>
  fileURLToPath(new URL(`../../web/node_modules/${path}`, import.meta.url));

export default {
  ...base,
  resolve: {
    alias: {
      ...base.resolve.alias,
      "three/webgpu": web("three/build/three.webgpu.js"),
      "three/tsl": web("three/build/three.tsl.js"),
      // Longest first: the bare alias must not swallow the examples subpath.
      "three/examples/": web("three/examples/"),
      three: web("three/build/three.module.js"),
      typegpu: web("typegpu/index.js"),
    },
  },
  test: { ...base.test, include: ["src/live/tests/*.test.ts", "candidates/**/tests/*.test.ts"] },
};
