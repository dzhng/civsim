import {readFile,writeFile} from 'node:fs/promises';
import {PNG} from '../../web/node_modules/pngjs/lib/png.js';
const base='throwaway/m1b-verification/';
const before=JSON.parse(await readFile(base+'reference-scene/report.json','utf8'));
const after=JSON.parse(await readFile(base+'promoted-scene/report.json','utf8'));
const rows=[];
for(const old of before.results){
 const next=after.results.find(r=>r.label===old.label);if(!next)throw Error('Missing checkpoint');
 const a=PNG.sync.read(await readFile(base+'reference-scene/'+old.label+'-actual.png'));
 const b=PNG.sync.read(await readFile(base+'promoted-scene/'+old.label+'-actual.png'));
 if(a.width!==b.width||a.height!==b.height)throw Error('Dimension mismatch');
 let changed=0,max=0,total=0;
 for(let i=0;i<a.data.length;i+=4){let diff=false;for(let c=0;c<4;c++){const d=Math.abs(a.data[i+c]-b.data[i+c]);diff||=d!==0;max=Math.max(max,d);total+=d;}changed+=Number(diff);}
 rows.push({label:old.label,width:a.width,height:a.height,changedPixels:changed,maxChannelDifference:max,meanChannelDifference:total/a.data.length,beforeCountsMatch:old.countsMatch,afterCountsMatch:next.countsMatch});
}
const report={scope:'pre/post package move, same raw control and fixed physical scene; no timing claim',rows,beforeErrors:before.errors,afterErrors:after.errors,beforeRemaining:before.remaining,afterRemaining:after.remaining};
await writeFile(base+'scene-comparison.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
