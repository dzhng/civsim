Review in-progress implementation, not yet final:
- createSeatingAudit adds a rotating1024-item scan and many mutable fields. A completed sweep combines multiple changing crowd frames; unchanged count/terrain is not unchanged population positions. It cannot claim that one presented population is wholly seated. Frozen images only audit once, so populations>1024 may stay unknown indefinitely. User demanded smooth camera; existing prompt forbids repeated O(N) stats reads, not permission to add unmeasured per-frame sample scans. Prefer no invented seating verdict; keep obligation explicit and implement a deliberate one-frame diagnostic at verification time, or bounded observation from real current upload ownership. Do not accept new state machine just to fit source.matches.
- Raw substrate/projection must not label lab TypeGPU/vgpu asraw. Selected-only diagnostics already gate via rawScene; labels need same truthful scope.
- current lastView assignment after battle-draw beforestartupreadiness may be valid actual submitted frame but renderedFrameId increments later. Failed startup should not associate camera with previous frame id. Check final tests/contract.
- finite elevation/surface must not silently pass Math.abs(NaN)>tolerance false if any seating checker remains.
Later settled-shape review candidates:
- RAW_BATTLE_PROJECTION duplicates existing renderer-core cameraUniform.PROJECTION_IDENTITY. Prefer direct shared owner; no second definition asserting the same projector name.
- OPEN_DIAGNOSTIC_OBLIGATIONS runtime prose embeds build-plan narrative in every stats result; use concise stable absent-measurement identifiers, durable reasoning belongs in docs/spec. Keep null fields explicit. Tests should check absence, not prose.
- depthStats comment 'read back off' might imply GPU readback; say descriptor/pipeline policy observation.
- Preserve M9a last measured identity semantics; no accidental re-label during camera-record fix.
