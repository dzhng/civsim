import {build} from '../../web/node_modules/vite/dist/node/index.js';
import {mkdir,symlink,writeFile,readdir} from 'node:fs/promises';
const root=process.cwd(),out=root+'/throwaway/shadow-sampling-review', candidate='/Users/david/dev/game-battle-shadow-sampling';
process.env.BATTLE_NATIVE_BACKEND='raw';
for(const [arm,source] of [['control',root],['candidate',candidate]]){
 let injected=0;
 await build({configFile:source+'/apps/battle-perf-lab/src/live/vite.config.mts',plugins:[{name:'scratch-timing-access',enforce:'pre',transform(code,id){if(!id.endsWith('/live/NativeBattleRenderer.ts'))return;const anchor='this.telemetry = telemetry;';if(code.split(anchor).length!==2)throw Error('telemetry anchor mismatch');injected++;return code.replace(anchor,anchor+' globalThis.__sampleGpuEvents = (cursor) => telemetry.eventsSince(cursor);');}}],build:{outDir:out+'/'+arm,copyPublicDir:false}});
 if(injected!==1)throw Error('observation hook not installed once');
 for(const name of await readdir(root+'/web/public')) { if(name==='assets'){ for(const entry of await readdir(root+'/web/public/assets')) await symlink(root+'/web/public/assets/'+entry,out+'/'+arm+'/assets/'+entry); } else await symlink(root+'/web/public/'+name,out+'/'+arm+'/'+name); }
 await writeFile(out+'/'+arm+'-observation.json',JSON.stringify({source,injected}));
}
