# Root preliminary review

The immutable candidate is3f573c64 on unadopted c8580623. It is not integrated.
Root inspected plan/scan/ordered completion, the bitwise live-position guard,
charge-weapon ordering and the explicit output comparisons. No new writable scan
input found so far: apply_impale moves positions; damage/death remain staged.

Reject the worker's claim that the15.5k native rung corresponds exactly to the
canonical Menu workload. It matches initial roster shape only. The native probe
uses Sim seed7, AI both teams and no initial player attack orders; canonical Game
uses0x5eedc0de, map seed7, AI team1 plus nearest-enemy orders on team0, and includes
export refresh. Root's prior workload audit already names these differences.
The deleted worker probe cannot turn roster agreement into trajectory identity.

Retain the worker's scoped lifetime/mutation claims for independent verification.
Do not infer cheap rescans from261 cases on168 soldiers, or a tuned cache/thread
choice from BATCH256/min_len32. Existing native parallel weapon repulsion requires
feature/thread-matched controls. No8-thread tuning sweep or stage-attribution run
is authorized by the bounded timing protocol at this checkpoint.

The worker broadened checks well beyond the requested focused set; preserve actual
logs/counts rather than repeat broad suites. Root checks the new differential and
specific mutations only after independent review finishes. TargetGeometry and Plan
have fixed bounded staging, but batch overhead in quiet windows is still unmeasured.
