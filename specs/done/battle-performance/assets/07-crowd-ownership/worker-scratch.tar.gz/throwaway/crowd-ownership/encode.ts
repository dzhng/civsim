/** A structural encoding of a retained crowd record set, including the identity
 *  relations plain deep-equality cannot see: which pool object a slot reuses
 *  across frames, whether a blend's source aliases its own destination, and
 *  whether a frozen pose array is the very array that was submitted. */
import type { CrowdInstance } from "../../packages/crowd-runtime/src/instanceData";
import type { ClipBlend, RiderBlend } from "../../packages/crowd-runtime/src/actionTimeline";

export class IdentityRegistry {
  private readonly ids = new Map<object, number>();
  id(value: object): number {
    let id = this.ids.get(value);
    if (id === undefined) this.ids.set(value, (id = this.ids.size));
    return id;
  }
}

function blend(value: ClipBlend | RiderBlend, registry: IdentityRegistry) {
  const destination =
    "kind" in value.destination
      ? "base"
      : { clip: value.destination.clip, phase: value.destination.phase };
  const source =
    value.source.kind === "frozen"
      ? {
          kind: "frozen",
          // Identity, not contents: a frozen pose must stay the submitted array.
          locals: registry.id(value.source.locals),
          values: [...value.source.locals],
          frozen: Object.isFrozen(value.source.locals),
        }
      : {
          kind: "clip",
          aliasesDestination: value.source.sample === value.destination,
          sample: { clip: value.source.sample.clip, phase: value.source.sample.phase },
        };
  return { weight: value.weight, destination, source };
}

export function encode(records: readonly CrowdInstance[], registry: IdentityRegistry) {
  return records.map((record) => ({
    // Reuse across frames shows up as a repeated id; a fresh allocation does not.
    slot: registry.id(record),
    x: record.x,
    y: record.y,
    facing: record.facing,
    classId: record.classId,
    faction: record.faction,
    alive: record.alive,
    clip: record.clip,
    phase: record.phase,
    seed: record.seed,
    mounted: record.mounted,
    lod: record.lod,
    // Distinguishes an absent key from an explicitly undefined one.
    elevationKey: "elevation" in record,
    elevation: record.elevation === undefined ? null : record.elevation,
    playback:
      record.playback === undefined
        ? null
        : {
            shell: registry.id(record.playback),
            appearanceId: record.playback.appearanceId,
            base: blend(record.playback.base, registry),
            riderUpperBody: record.playback.riderUpperBody
              ? blend(record.playback.riderUpperBody, registry)
              : null,
          },
  }));
}
