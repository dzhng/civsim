from pathlib import Path
import subprocess,os,json,re,time,hashlib,datetime
root=Path('/Users/david/dev/game-battle-performance-spec');base=root/'throwaway/native-target-build';out=base/'runs';out.mkdir(exist_ok=True)
assert not any(out.iterdir()), 'Preserve an existing run; do not repeat to seek a win'
meta=json.loads((base/'builds.json').read_text());binaries={(b['arm'],b['mode']):b for b in meta['builds']};assert len(binaries)==4 and all(b['exit']==0 for b in meta['builds'])
pattern=re.compile(r'fighting target 15500 repeat (\d+) soldiers (\d+) contact (\d+) window (\d+)\.\.(\d+) alive (\d+)->(\d+) min_fighting (\d+) mean_ms ([0-9.]+) stddev_ms ([0-9.]+) hash (0x[0-9a-f]+)')
results=[];identity=None
configurations = [('serial', None), ('parallel-one', 1), ('parallel-four', 4)]
for mode, threads in configurations:
 for order,arm in enumerate(['control','candidate','candidate','control']):
  build=binaries[arm,'serial' if threads is None else 'parallel'];exe=Path(build['executable']);assert hashlib.sha256(exe.read_bytes()).hexdigest()==build['sha256']
  name=f'{mode}-{order}-{arm}';env={**os.environ,'RAYON_NUM_THREADS':str(threads or 1)}
  before={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadAverage':os.getloadavg(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,comm,pcpu'],text=True)}
  print('START',name,flush=True);began=time.monotonic()
  try:r=subprocess.run([str(exe),'fighting','15500','1500'],env=env,capture_output=True,text=True,timeout=600)
  except subprocess.TimeoutExpired as error:
   (out/(name+'-timeout.json')).write_text(json.dumps({'error':'600-second native deadline','before':before},indent=2)+'\n');raise
  (out/(name+'.log')).write_text(r.stdout+r.stderr)
  samples=[]
  for m in pattern.finditer(r.stdout):
   g=m.groups();samples.append(dict(zip(['repeat','soldiers','contact','start','end','aliveStart','aliveEnd','minFighting'],map(int,g[:8])),meanMs=float(g[8]),stddevMs=float(g[9]),hash=g[10]))
  record={'arm':arm,'mode':mode,'order':order,'threads':threads,'executableSha256':build['sha256'],'sourceHead':build['sourceHead'],'command':[str(exe),'fighting','15500','1500'],'exit':r.returncode,'elapsedSeconds':time.monotonic()-began,'before':before,'after':{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadAverage':os.getloadavg()},'samples':samples,'measurement':'Native Battle.tick fixture; not canonical Menu Game or browser timing. No stage instrumentation. Root serializes owned timing/build/test/GPU jobs.'}
  (out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0 and len(samples)==2,(name,r.returncode,len(samples))
  identities=[{k:v for k,v in s.items() if k not in ['repeat','meanMs','stddevMs']} for s in samples]
  assert identities[0]==identities[1], 'Internal repeat workload mismatch'
  if identity is None:identity=identities[0]
  assert all(x==identity for x in identities),'Cross-arm native workload mismatch'
  assert hashlib.sha256(exe.read_bytes()).hexdigest()==build['sha256']
  results.append({'arm':arm,'mode':mode,'order':order,'meanMs':sum(s['meanMs'] for s in samples)/2,'samples':samples})
  (out/'partial.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,results[-1]['meanMs'],flush=True)
summary={'results':results,'identity':identity,'nativeOnly':True,'productionAdopted':False,'gates':{}}
for mode, threads in configurations:
 a=[r['meanMs'] for r in results if r['mode']==mode and r['arm']=='control'];b=[r['meanMs'] for r in results if r['mode']==mode and r['arm']=='candidate'];summary['gates'][mode]={'control':a,'candidate':b,'bothCandidatesBeatBothControls':max(b)<min(a)}
(out/'outcomes.json').write_text(json.dumps(summary,indent=2)+'\n');print('COMPLETE',summary['gates'],flush=True)
