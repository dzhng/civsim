import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
const root=process.cwd(),dir=root+'/throwaway/high-shadow-review/reference-hardware';await mkdir(dir,{recursive:true});
const outcomes=[];
for(const [name,config,pageName,key,queries] of [
 ['shadow','shadow','shadow-check.html','__frameCheck',['?backend=raw']],
 ['frame','frame','frame-check.html','__frameCheck',['?backend=raw&samples=1&shadows=1&scenery=1','?backend=raw&samples=4&shadows=1&scenery=1']],
 ['terrain','terrainScene','terrainScene-check.html','__terrainSceneCheck',['?samples=1','?samples=4']],
 ['lifecycle','frame-lifecycle','frame-lifecycle-check.html','__frameLifecycle',['']]]){
 if(name!=='terrain')continue;
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config',`apps/battle-perf-lab/src/raw/${config}.vite.config.mts`,'--outDir',root+`/throwaway/high-shadow-review/reference-terrain`,'--port','5298','--strictPort'],{stdio:['ignore','pipe','pipe']});
 let log='',browser;server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
 try{
  await new Promise((resolve,reject)=>{const began=Date.now();let timer=setInterval(()=>{if(log.includes('Local:')){clearInterval(timer);resolve();}else if(server.exitCode!==null||Date.now()-began>30000){clearInterval(timer);reject(Error(log));}},100);});
  browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});
  for(let i=0;i<queries.length;i++){
   const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
   await page.goto(`http://localhost:5298/${pageName}${queries[i]}`);await page.waitForFunction(key=>window[key]!==undefined,key,{timeout:120000});
   const report=await page.evaluate(key=>window[key],key);const result={name,query:queries[i],errors,report,scope:'hardware correctness; no timing verdict'};
   await writeFile(`${dir}/${name}-${i}.json`,JSON.stringify(result,null,2)+'\n');outcomes.push({name,query:queries[i],passed:report.passed===true&&errors.length===0});console.log(outcomes.at(-1));await page.close();
  }
 }finally{await browser?.close();server.kill('SIGTERM');await writeFile(`${dir}/${name}-preview.log`,log);await new Promise(resolve=>server.exitCode!==null?resolve():server.once('exit',resolve));}
}
await writeFile(dir+'/outcomes.json',JSON.stringify(outcomes,null,2)+'\n');if(outcomes.some(r=>!r.passed))process.exitCode=1;
