# Pre-relocation reference

All five Vite builds succeeded at f3afcffd: actual raw Menu, full scene, raw frame,
frame lifecycle and pose control. No Rust changed in main; production WASM remains
b42782f4. Compiled artifact hashes and borrowed public/atlas content hashes are
under reference/. These are fixed code builds with fingerprinted borrowed assets;
they are not an independent copy of every asset. Preserve assets or verify those
hashes before the post-move comparison.

The existing full-scene hardware correctness driver exited0. Report has no browser
or GPU errors and0 tracked live textures/buffers after disposal. All8 source/raw
audience counts match across tactical/wide/horizon/far-LOD,15560 soldiers. The
report explicitly says rankable=false. Source/raw pixel differences remain; root
inspected tactical-settled-actual and makes no shadow-quality acceptance claim.

The next relocation check compares raw reference images to raw promoted images,
not merely each to Three. Initial async setup differences must be retained and
classified rather than silently dismissed. Final M1b gates still include shared
snapCheck controls, raw frame/pose numerical tests and unchanged30k floor, with
hardware timing serialized after all owned CPU/build/test work ends.

Scene preview session18762 was stopped after successful driver52537. No GPU or
preview remains from this run. Build session7995 completed0. The existing
verify-pose.mjs is a TypeGPU/vgpu comparison (it rejects raw), so raw pose proof
must use the production raw-pose-palette scene instead of relabelling that script.
