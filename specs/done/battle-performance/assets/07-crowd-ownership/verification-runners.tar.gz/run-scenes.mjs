import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
const root=process.cwd(),out=root+'/throwaway/crowd-ownership-hardware';
for(const arm of ['control','candidate'])for(const cameraOnly of [false,true]){
 const name=`scene-${arm}-${cameraOnly?'camera':'submit'}`;let browser,log='';const errors=[],warnings=[];
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config','apps/battle-perf-lab/src/raw/scene.vite.config.mts','--outDir',out+'/scene-'+arm,'--port','5298','--strictPort'],{stdio:['ignore','pipe','pipe']});server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
 try{
  await new Promise((resolve,reject)=>{const start=Date.now(),t=setInterval(()=>{if(log.includes('Local:')){clearInterval(t);resolve();}else if(server.exitCode!==null||Date.now()-start>30000){clearInterval(t);reject(Error(log));}},100);});
  browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});const page=await browser.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
  await page.goto('http://localhost:5298/scene-check.html?backend=raw&atlasCatalog=/assets/soldiers/impostors/catalog.json'+(cameraOnly?'&cameraOnly':''));await page.waitForFunction(()=>window.__sceneCheck!==undefined,null,{timeout:180000});const report=await page.evaluate(()=>window.__sceneCheck);
  await writeFile(out+'/'+name+'.json.gz',gzipSync(JSON.stringify({report,errors,warnings,purpose:'matched correctness only; no timing claim'})));console.log(JSON.stringify({name,error:report.error,frames:report.results?.length,remaining:report.remaining,errors,warnings}));
  if(report.error||errors.length||warnings.length||report.errors?.length||report.results?.length!==8||report.remaining?.textures!==0||report.remaining?.buffers!==0)throw Error(name+' failed correctness');
 }finally{await browser?.close();server.kill('SIGTERM');await new Promise(r=>server.exitCode!==null?r():server.once('exit',r));await writeFile(out+'/'+name+'-server.log',log);}
}
