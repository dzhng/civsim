import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {PNG} from '../../web/node_modules/pngjs/lib/png.js';
const out=process.cwd()+'/throwaway/crowd-ownership-hardware',rows=[];
await mkdir(out+'/scene-images',{recursive:true});
for(const mode of ['submit','camera']){
 const load=async arm=>JSON.parse(gunzipSync(await readFile(`${out}/scene-${arm}-${mode}.json.gz`))).report;
 const a=await load('control'),b=await load('candidate');
 if(a.instances!==b.instances)throw Error('Population changed');
 for(const old of a.results){const next=b.results.find(r=>r.label===old.label);if(!next)throw Error('Missing '+old.label);
  const bytes=x=>Buffer.from(x.slice(x.indexOf(',')+1),'base64');const aa=PNG.sync.read(bytes(old.actual)),bb=PNG.sync.read(bytes(next.actual));
  if(aa.width!==bb.width||aa.height!==bb.height)throw Error('Dimensions changed');let changedPixels=0,maxChannelDelta=0;
  for(let i=0;i<aa.data.length;i+=4){let changed=false;for(let c=0;c<4;c++){const d=Math.abs(aa.data[i+c]-bb.data[i+c]);changed||=d!==0;maxChannelDelta=Math.max(maxChannelDelta,d);}changedPixels+=Number(changed);}
  const crowdStatsMatch=JSON.stringify(old.actualStats.crowd)===JSON.stringify(next.actualStats.crowd);
  rows.push({mode,label:old.label,changedPixels,maxChannelDelta,crowdStatsMatch,width:aa.width,height:aa.height});
  if(mode==='submit'&&['tactical-settled','horizon-settled'].includes(old.label))await writeFile(`${out}/scene-images/${old.label}.png`,bytes(next.actual));
 }
}
await writeFile(out+'/scene-comparison.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows));
if(rows.some(r=>r.changedPixels||!r.crowdStatsMatch))process.exitCode=1;
