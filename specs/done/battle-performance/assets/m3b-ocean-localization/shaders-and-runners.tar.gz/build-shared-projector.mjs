import{build}from'../../web/node_modules/vite/dist/node/index.js';
const root=process.cwd();let changed=false;
await build({configFile:root+'/apps/battle-perf-lab/src/raw/water.vite.config.mts',build:{outDir:root+'/throwaway/ocean-residual-review/shared-projector',copyPublicDir:false},plugins:[{name:'localize-hdr-comparison',enforce:'pre',transform(code,id){
if(id.endsWith('/packages/photoreal-renderer/src/battle/seaLayer.ts')) {
 const target='  mesh.name = "battle-ocean-plane";';
 if(!code.includes(target))throw Error('Missing ocean mesh');
 return code.replace('import { attribute } from "three/tsl";', 'import { attribute, uniform, positionLocal } from "three/tsl";').replace(target, '  const comparisonProjection = new THREE.Matrix4();\n  mesh.userData.comparisonProjection = comparisonProjection;\n  material.vertexNode = uniform(comparisonProjection).mul(vec4(positionLocal, 1.0));\n'+target);
}
if(id.endsWith('/apps/battle-perf-lab/src/waterControl.ts')) {
 const target='      applyCamera3d(camera, params);';
 if(!code.includes(target))throw Error('Missing control camera');
 return code.replace('import type { Camera3DParams }', 'import { viewProjMatrix, type Camera3DParams }').replace(target,target+'\n      world.scene.traverse((object) => { object.userData.comparisonProjection?.fromArray(viewProjMatrix(params)); });');
}
if(!id.endsWith('/apps/battle-perf-lab/src/numericalReadback.ts'))return;const targets=['  let maxAbs = 0,','    maxAbs = Math.max(maxAbs, difference);','    maxRelative,\n    rmse:'];for(const target of targets)if(!code.includes(target))throw Error('Missing instrumentation target '+target);changed=true;return code.replace(targets[0],'  let maxAbsIndex = -1;\n  let maxAbs = 0,').replace(targets[1],'    if (difference > maxAbs) { maxAbs = difference; maxAbsIndex = i; }').replace(targets[2],'    maxAbsIndex,\n    maxAbsActual: actual[maxAbsIndex] ?? null,\n    maxAbsExpected: expected[maxAbsIndex] ?? null,\n    maxRelative,\n    rmse:');}}]});if(!changed)throw Error('Instrumentation did not run');
