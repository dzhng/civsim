import { fileURLToPath } from "node:url";

// Scratch oracle only. A plain config object (no `vitest/config` import) because
// this folder sits outside the workspace that owns node_modules. Root is the repo
// root so the probe imports package sources by relative path, with no aliases.
export default {
  root: fileURLToPath(new URL("../../", import.meta.url)),
  test: {
    environment: "node",
    include: ["throwaway/crowd-ownership/*.test.ts"],
    globals: false,
  },
};
