# Root disposition

F1: accept explicit resolved1e7 provenance and small-margin risk; reject blocking
or zero/no-op wording. Direct pinned CPU oracle measures nonzero extents changing
with far. The proposed light seam is labelled inference and remains unproved;
keep the max/min distinction until coverage/visual evidence warrants correction.

F2: current native sceneCamera already resolves far to1e7, so the claimed current
undefined/zero scalar bug is false. Accept explicit absent/infinite/sentinel
normalization for the future pure policy to prevent accidental misuse.

F3: reject WebGL divergence as a defect verdict. Current product uses WebGPU CSM;
retain fade to lit at the capped far limit, and state the reference explicitly.

F4: accept cold/pre-render admission lag from actual call order. Correct its
wording: empty cascade-only culling views does not mean zero rendered casters;
main-visible bodies can still cast. Native needs truthful same-frame coverage,
not source lag parity. No source runtime edit in this planning pass.

F5: accept. Existing environment matrix and camera near are actual shared owners.
Use208 bytes (two96-byte records plus16-byte capped-far/count block), rather than
duplicating view-row/near. Require one admitted canonical frame for all writers.

F6/F7: accept explicit normalization offset and overlap partition test. Compare
with floating tolerance, not an impossible universal exact GPU equality claim.

F8: accept separately named High lower-depth guard difference and texel-space
softness. Retain native valid-depth guard and prove coverage; do not silently
classify that as source parity or fold it into the original whole-map baseline.

All resource counts/layout arithmetic, separate caster camera buffers and existing
sampling constants independently checked. Root CPU-only source-oracle outputs
retain synthetic matrices/breaks/extents for four far planes; no GPU/visual proof.
