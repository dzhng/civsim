import{readFile,writeFile}from'node:fs/promises';import{gunzipSync}from'node:zlib';import{PNG}from'../../web/node_modules/pngjs/lib/png.js';
const root=process.cwd()+'/throwaway/crowd-ownership-hardware',imgs=[];
for(const arm of['control','candidate']){const r=JSON.parse(gunzipSync(await readFile(root+`/scene-${arm}-camera.json.gz`))).report.results.find(r=>r.label==='horizon-settled');const data=Buffer.from(r.actual.split(',')[1],'base64');await writeFile(root+'/scene-images/horizon-camera-'+arm+'.png',data);imgs.push(PNG.sync.read(data));}
let x0=Infinity,y0=Infinity,x1=-1,y1=-1;const points=[];
for(let y=0;y<imgs[0].height;y++)for(let x=0;x<imgs[0].width;x++){const i=(y*imgs[0].width+x)*4;if(imgs[0].data.subarray(i,i+4).equals(imgs[1].data.subarray(i,i+4)))continue;x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);points.push({x,y,before:[...imgs[0].data.subarray(i,i+4)],after:[...imgs[1].data.subarray(i,i+4)]});}
const r={bounds:[x0,y0,x1,y1],points};await writeFile(root+'/scene-difference-pixels.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({bounds:r.bounds,first:points.slice(0,8),count:points.length}));
