import * as THREE from '../../web/node_modules/three/build/three.webgpu.js';
import { CSMShadowNode } from '../../web/node_modules/three/examples/jsm/csm/CSMShadowNode.js';
import { writeFile } from 'node:fs/promises';
const cases=[];
for (const far of [1000,1500,10000,1e7]) {
 const camera=new THREE.PerspectiveCamera(55,1.6,0.5,far);
 camera._reversedDepth=true;
 camera.coordinateSystem=THREE.WebGPUCoordinateSystem;
 camera.up.set(0,0,1);camera.position.set(50,-80,120);camera.lookAt(0,0,0);
 camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 const scene=new THREE.Scene();const sun=new THREE.DirectionalLight();
 sun.position.set(0.3,-0.4,0.8).normalize();sun.target.position.set(0,0,0);
 sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.near=1;sun.shadow.camera.far=2500;
 sun.shadow.bias=-0.00003;sun.shadow.normalBias=0.6;
 scene.add(sun,sun.target);
 const csm=new CSMShadowNode(sun,{cascades:2,maxFar:1500,mode:'practical',lightMargin:300});
 csm.fade=true;csm._init({camera,renderer:{coordinateSystem:THREE.WebGPUCoordinateSystem,reversedDepthBuffer:true}});
 csm.updateBefore();
 cases.push({far,near:camera.near,breaks:[...csm.breaks],frustums:csm.frustums.map(f=>({near:f.vertices.near.map(p=>p.toArray()),far:f.vertices.far.map(p=>p.toArray())})),lights:csm.lights.map(l=>({position:l.position.toArray(),target:l.target.position.toArray(),bias:l.shadow.bias,normalBias:l.shadow.normalBias,bounds:{left:l.shadow.camera.left,right:l.shadow.camera.right,near:l.shadow.camera.near,far:l.shadow.camera.far}}))});
 csm.dispose();
}
await writeFile(new URL('./source-oracle.json',import.meta.url),JSON.stringify({scope:'CPU-only direct pinned CSM methods; no GPU or timing proof, synthetic cameras',cases},null,2)+'\n');
console.log(cases.map(c=>({far:c.far,break:c.breaks[0],widths:c.lights.map(l=>l.bounds.right-l.bounds.left),bias:c.lights.map(l=>l.bias)})));
