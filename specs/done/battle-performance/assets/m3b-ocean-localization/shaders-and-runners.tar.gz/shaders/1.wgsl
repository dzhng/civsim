// Three.js r185 - Node System

// directives


// structs


// uniforms

struct objectStruct {
	nodeUniform0 : f32,
	nodeUniform1 : f32,
	nodeUniform2 : f32,
	nodeUniform3 : f32,
	nodeUniform4 : vec3<f32>,
	nodeUniform5 : f32,
	nodeUniform7 : mat3x3<f32>,
	nodeUniform8 : vec2<f32>,
	nodeUniform13 : mat4x4<f32>,
	nodeUniform15 : f32,
	nodeUniform16 : mat4x4<f32>,
	nodeUniform18 : f32,
	nodeUniform19 : f32,
	nodeUniform21 : f32
};
@binding( 0 ) @group( 1 )
var<uniform> object : objectStruct;

struct renderStruct {
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	nodeUniform11 : vec3<f32>,
	nodeUniform9 : vec3<f32>,
	nodeUniform10 : vec3<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	cameraPosition : vec3<f32>
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

// varyings

struct VaryingsStruct {
	@location( 0 ) nodeVarying3 : vec2<f32>,
	@location( 1 ) v_positionViewDirection : vec3<f32>,
	@location( 2 ) v_positionWorld : vec3<f32>,
	@builtin( position ) builtinClipSpace : vec4<f32>
};
var<private> varyings : VaryingsStruct;

// vars
var<private> nodeVar0 : f32;
var<private> nodeVar1 : f32;
var<private> nodeVar2 : f32;
var<private> nodeVar3 : f32;
var<private> nodeVar4 : f32;
var<private> nodeVar5 : f32;
var<private> nodeVar6 : f32;
var<private> nodeVar7 : f32;
var<private> nodeVar8 : f32;
var<private> nodeVar9 : f32;
var<private> nodeVar10 : f32;
var<private> nodeVar11 : f32;
var<private> nodeVar12 : f32;
var<private> nodeVar13 : f32;
var<private> nodeVar14 : f32;
var<private> nodeVar15 : f32;
var<private> nodeVar16 : f32;
var<private> nodeVar17 : f32;
var<private> nodeVar18 : f32;
var<private> nodeVar19 : f32;
var<private> modelViewMatrix : mat4x4<f32>;
var<private> VERTEX_nodeVar293 : vec4<f32>;
var<private> positionLocal : vec3<f32>;
var<private> v_modelViewProjection : vec4<f32>;
var<private> v_positionView : vec3<f32>;
var<private> VERTEX_v_modelViewProjection : vec4<f32>;

// codes


@vertex
fn main( @location( 0 ) position : vec3<f32> ) -> VaryingsStruct {

	// flow
	// code

	positionLocal = position;
	nodeVar0 = ( ( sin( ( ( ( dot( vec2<f32>( 0.9936, 0.1132 ), position.xy ) * 0.06816952696105023 ) - ( object.nodeUniform0 * 0.3434621896128685 ) ) + 1.4445185748148395 ) ) * 0.5 ) + 0.5 );
	nodeVar1 = ( ( sin( ( ( ( dot( vec2<f32>( 0.9157, 0.4018 ), position.xy ) * 0.07282319541029207 ) - ( object.nodeUniform0 * 0.354992076652964 ) ) + 5.406467639197834 ) ) * 0.5 ) + 0.5 );
	nodeVar2 = ( ( sin( ( ( ( dot( vec2<f32>( 0.7585, 0.6517 ), position.xy ) * 0.08923711546655305 ) - ( object.nodeUniform0 * 0.39296742933864454 ) ) + 2.5043572818772324 ) ) * 0.5 ) + 0.5 );
	nodeVar3 = ( ( sin( ( ( ( dot( vec2<f32>( 0.4565, 0.8897 ), position.xy ) * 0.09256313052445493 ) - ( object.nodeUniform0 * 0.40022370789657236 ) ) + 2.1629999741538026 ) ) * 0.5 ) + 0.5 );
	nodeVar4 = ( ( sin( ( ( ( dot( vec2<f32>( 0.1923, 0.9813 ), position.xy ) * 0.10633246403790828 ) - ( object.nodeUniform0 * 0.42895993717149816 ) ) + 5.517105324695108 ) ) * 0.5 ) + 0.5 );
	nodeVar5 = ( ( sin( ( ( ( dot( vec2<f32>( -0.0506, 0.9987 ), position.xy ) * 0.1358232879377432 ) - ( object.nodeUniform0 * 0.4848092682732639 ) ) + 3.797562421550177 ) ) * 0.5 ) + 0.5 );
	nodeVar6 = ( ( sin( ( ( ( dot( vec2<f32>( -0.4173, 0.9088 ), position.xy ) * 0.16657437168610817 ) - ( object.nodeUniform0 * 0.5368931784003809 ) ) + 1.8312313893253558 ) ) * 0.5 ) + 0.5 );
	nodeVar7 = ( ( sin( ( ( ( dot( vec2<f32>( -0.6739, 0.7388 ), position.xy ) * 0.1871109380583681 ) - ( object.nodeUniform0 * 0.5690276658783798 ) ) + 5.700527025009868 ) ) * 0.5 ) + 0.5 );
	nodeVar8 = ( ( sin( ( ( ( dot( vec2<f32>( -0.8617, 0.5075 ), position.xy ) * 0.2278167258883249 ) - ( object.nodeUniform0 * 0.6278799240954691 ) ) + 4.7868431022853235 ) ) * 0.5 ) + 0.5 );
	nodeVar9 = ( ( sin( ( ( ( dot( vec2<f32>( -0.9553, 0.2958 ), position.xy ) * 0.21923186671318912 ) - ( object.nodeUniform0 * 0.6159360661929989 ) ) + 2.679924160764698 ) ) * 0.5 ) + 0.5 );
	nodeVar10 = ( ( sin( ( ( ( dot( vec2<f32>( -0.9979, -0.0648 ), position.xy ) * 0.31321960618145567 ) - ( object.nodeUniform0 * 0.7362211060430895 ) ) + 0.33144367460928875 ) ) * 0.5 ) + 0.5 );
	nodeVar11 = ( ( sin( ( ( ( dot( vec2<f32>( -0.9303, -0.3668 ), position.xy ) * 0.2915631229698376 ) - ( object.nodeUniform0 * 0.7103135359046289 ) ) + 5.59819089683915 ) ) * 0.5 ) + 0.5 );
	nodeVar12 = ( ( sin( ( ( ( dot( vec2<f32>( -0.7647, -0.6444 ), position.xy ) * 0.36466542658154383 ) - ( object.nodeUniform0 * 0.7943850993394428 ) ) + 1.5282420422747962 ) ) * 0.5 ) + 0.5 );
	nodeVar13 = ( ( sin( ( ( ( dot( vec2<f32>( -0.5166, -0.8563 ), position.xy ) * 0.39943962492053403 ) - ( object.nodeUniform0 * 0.8313987490314052 ) ) + 5.5949659313329345 ) ) * 0.5 ) + 0.5 );
	nodeVar14 = ( ( sin( ( ( ( dot( vec2<f32>( -0.2276, -0.9737 ), position.xy ) * 0.4180429341317366 ) - ( object.nodeUniform0 * 0.8505390107620132 ) ) + 0.4345941566544691 ) ) * 0.5 ) + 0.5 );
	nodeVar15 = ( ( sin( ( ( ( dot( vec2<f32>( 0.1505, -0.9886 ), position.xy ) * 0.5691291032608696 ) - ( object.nodeUniform0 * 0.9924055658486013 ) ) + 5.530018165763443 ) ) * 0.5 ) + 0.5 );
	nodeVar16 = ( ( sin( ( ( ( dot( vec2<f32>( 0.4309, -0.9024 ), position.xy ) * 0.6734389389067524 ) - ( object.nodeUniform0 * 1.0795255016696514 ) ) + 0.6440417181639329 ) ) * 0.5 ) + 0.5 );
	nodeVar17 = ( ( sin( ( ( ( dot( vec2<f32>( 0.5983, -0.8013 ), position.xy ) * 0.7059758764044944 ) - ( object.nodeUniform0 * 1.1052963215825677 ) ) + 5.087161441303587 ) ) * 0.5 ) + 0.5 );
	nodeVar18 = ( ( sin( ( ( ( dot( vec2<f32>( 0.8359, -0.5488 ), position.xy ) * 0.7699981985294118 ) - ( object.nodeUniform0 * 1.154326454077862 ) ) + 6.0900466283169115 ) ) * 0.5 ) + 0.5 );
	nodeVar19 = ( ( sin( ( ( ( dot( vec2<f32>( 0.9869, -0.1611 ), position.xy ) * 0.9119282002902759 ) - ( object.nodeUniform0 * 1.2562154113650723 ) ) + 1.7528584445014586 ) ) * 0.5 ) + 0.5 );
	positionLocal = vec3<f32>( position.xy, ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( 0.0 + ( ( ( nodeVar0 * nodeVar0 ) - 0.333 ) * 1.7655 ) ) + ( ( ( nodeVar1 * nodeVar1 ) - 0.333 ) * 1.3079 ) ) + ( ( ( nodeVar2 * nodeVar2 ) - 0.333 ) * 1.49435 ) ) + ( ( ( nodeVar3 * nodeVar3 ) - 0.333 ) * 0.8547000000000001 ) ) + ( ( ( nodeVar4 * nodeVar4 ) - 0.333 ) * 1.35135 ) ) + ( ( ( nodeVar5 * nodeVar5 ) - 0.333 ) * 0.6534 ) ) + ( ( ( nodeVar6 * nodeVar6 ) - 0.333 ) * 0.9740500000000001 ) ) + ( ( ( nodeVar7 * nodeVar7 ) - 0.333 ) * 0.52305 ) ) + ( ( ( nodeVar8 * nodeVar8 ) - 0.333 ) * 0.4686 ) ) + ( ( ( nodeVar9 * nodeVar9 ) - 0.333 ) * 0.5890500000000001 ) ) + ( ( ( nodeVar10 * nodeVar10 ) - 0.333 ) * 0.39545 ) ) + ( ( ( nodeVar11 * nodeVar11 ) - 0.333 ) * 0.39435000000000003 ) ) + ( ( ( nodeVar12 * nodeVar12 ) - 0.333 ) * 0.43010000000000004 ) ) + ( ( ( nodeVar13 * nodeVar13 ) - 0.333 ) * 0.33385000000000004 ) ) + ( ( ( nodeVar14 * nodeVar14 ) - 0.333 ) * 0.40095000000000003 ) ) + ( ( ( nodeVar15 * nodeVar15 ) - 0.333 ) * 0.30360000000000004 ) ) + ( ( ( nodeVar16 * nodeVar16 ) - 0.333 ) * 0.33 ) ) + ( ( ( nodeVar17 * nodeVar17 ) - 0.333 ) * 0.2651 ) ) + ( ( ( nodeVar18 * nodeVar18 ) - 0.333 ) * 0.29590000000000005 ) ) + ( ( ( nodeVar19 * nodeVar19 ) - 0.333 ) * 0.27280000000000004 ) ) + 0.0 ) );
	varyings.nodeVarying3 = position.xy;
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform13 );
	v_positionView = ( modelViewMatrix * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	varyings.v_positionViewDirection = ( - v_positionView );
	varyings.v_positionWorld = ( object.nodeUniform13 * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	VERTEX_nodeVar293 = ( render.cameraProjectionMatrix * vec4<f32>( v_positionView, 1.0 ) );
	VERTEX_v_modelViewProjection = VERTEX_nodeVar293;

	// result

	varyings.builtinClipSpace = VERTEX_v_modelViewProjection;

	return varyings;

}
