# Consumer migration notes

The standing30k scene pauses simulation with p; it explicitly does not freeze.
Thus raw must continue real draws without adding a force-redraw hook. Static150
rAF sample collection presently repeats latest source gpuTimeMs; raw will collect
unique completed frame IDs, preserving the existing >=75 sample floor rather
than extending until enough good samples happen. Pan GPU samples also need unique
IDs. Keep source metric distinctly labeled while its route remains production.

Grass residency has existing real base/focus/rebuild data. Raw grassField.stats
returns residency, uploads, ringRecordRanges, layers. Layer records/capacities are
real; source tier triangle/thinning counts are a CPU mirror (capped sampled scan),
not GPU readback. These are recorded in30k's report but NOT asserted as population
floors. Missing raw counts should be null with scope, not a copied CPU scan or0.
Actual residency/population/coverage assertions stay unchanged. General depth
contract additionally checks seating, cues/effects, draw activity; these need
real producer observations or a further explicit diagnostics pass, not constants.

Do not alter campaign depth contract. Production source stays default until M9;
raw pre-cutover harness uses existing lab import substitution. No product switch.
