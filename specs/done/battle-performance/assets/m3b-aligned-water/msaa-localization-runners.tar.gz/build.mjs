import{build}from'../../web/node_modules/vite/dist/node/index.js';
const main=process.cwd(),root='/Users/david/dev/game-battle-water-comparison';let changed=false;
await build({configFile:root+'/apps/battle-perf-lab/src/raw/water.vite.config.mts',build:{outDir:main+'/throwaway/ocean-msaa-localization/candidate',copyPublicDir:false},plugins:[{name:'locate-msaa-residual',enforce:'pre',transform(code,id){
 if(!id.endsWith('/apps/battle-perf-lab/src/numericalReadback.ts'))return;
 const targets=['  let maxAbs = 0,','    maxAbs = Math.max(maxAbs, difference);','    maxRelative,\n    rmse:'];for(const t of targets)if(!code.includes(t))throw Error('Missing instrumentation target '+t);
 changed=true;return code.replace(targets[0],'  let maxAbsIndex = -1;\n  let maxAbs = 0,').replace(targets[1],'    if(difference > maxAbs) { maxAbs = difference; maxAbsIndex = i; }').replace(targets[2],'    maxAbsIndex,\n    maxAbsActual: actual[maxAbsIndex] ?? null,\n    maxAbsExpected: expected[maxAbsIndex] ?? null,\n    maxRelative,\n    rmse:');
}}]});if(!changed)throw Error('Localization not applied');
