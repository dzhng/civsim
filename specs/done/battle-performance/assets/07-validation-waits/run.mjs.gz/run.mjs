import {chromium} from '../../web/node_modules/playwright/index.mjs';
import {GPU_HARDWARE_FLAGS} from '../../web/renderer-probe-lib.mjs';
import {spawn,execFileSync} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import {snapCheck} from '../../web/snapshot.mjs';
const root=process.cwd(),out=root+'/throwaway/validation-wait-diagnostic';
const arms=[['diagnostic',out+'/candidate']];
await writeFile(out+'/processes-before.txt',execFileSync('ps',['-axo','pid,pcpu,command']));
for(const [arm,build] of arms){
 const dir=out+'/'+arm;await mkdir(dir,{recursive:true});let browser,log='';const errors=[],checks=[];
 const check=(name,pass,detail)=>checks.push({name,pass,detail});
 const server=spawn(root+'/web/node_modules/.bin/vite',['preview','--config','apps/battle-perf-lab/src/live/vite.config.mts','--outDir',build,'--port','5298','--strictPort'],{env:{...process.env,BATTLE_NATIVE_BACKEND:'raw'},stdio:['ignore','pipe','pipe']});
 server.stdout.on('data',b=>log+=b);server.stderr.on('data',b=>log+=b);
 try{
  await new Promise((resolve,reject)=>{const start=Date.now(),t=setInterval(()=>{if(log.includes('Local:')){clearInterval(t);resolve();}else if(server.exitCode!==null||Date.now()-start>30000){clearInterval(t);reject(Error(log));}},100);});
  browser=await chromium.launch({channel:'chrome',headless:true,args:GPU_HARDWARE_FLAGS});const page=await browser.newPage({viewport:{width:1280,height:800}});page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://localhost:5298/?map=gen&seed=7&ai=off');await page.waitForFunction(()=>window.__ready===true&&window.__game.stats().renderStats.ready,undefined,{timeout:120000});
  await page.evaluate(async()=>{window.dispatchEvent(new KeyboardEvent('keydown',{key:'p'}));await window.__game.freezeAtTick(30);const g=window.__game,need=Math.max(0,Math.ceil((30500-g.stats().soldiers)/500));for(let i=0;i<need;i++){const row=Math.floor(i/10),col=i%10;g.spawnClass(-540+col*120,-400+row*90,Math.PI/2,500,28,0,row%2);}});
  await page.waitForFunction(()=>{const s=window.__game.stats();return s.soldiers>=30000&&s.renderStats.soldiers===s.soldiers&&s.renderStats.expectedSoldiers===s.soldiers},undefined,{timeout:120000});
  await page.addStyleTag({content:'#gameover, #hud, #buttons, #pausemenu, #banner, #selbox, #minimap, #unitcards, #toolbar { display: none !important; }'});
  await page.evaluate(()=>{const c=window.__cam;c.yaw=0;c.pitchBias=0;c.zoom=3;c.clampView?.();c.setViewCenter(0,-310);c.clampView?.();});
  await page.waitForFunction(()=>{const g=window.__game.stats().renderStats.terrain.grass;return g.layers[0].recordCount>0&&!g.residency.rebuild.pending&&window.__game.frameMetrics().renderer.skippedFrozenFrame},undefined,{timeout:30000});
  await snapCheck(page,'wide',check,{shot:await page.screenshot(),baseDir:dir+'/'});
  const before=await page.evaluate(()=>({tick:window.__game.tickCount(),hash:window.__game.stateHash(),stats:window.__game.stats(),camera:window.__cam.params()}));
  await page.evaluate(()=>window.__game.freeze(false));
  const measured=await page.evaluate(async()=>{
   const g=window.__game,c=window.__cam;const raf=()=>new Promise(requestAnimationFrame);
   for(let i=0;i<120;i++)await raf();window.__validationWaitTrace=[];const segments=[];
   for(const moving of [false,true]){const rows=[],start=performance.now();let last=-1;while(performance.now()-start<12000){const now=await raf(),t=(now-start)/12000;
    if(moving){const wave=(1-Math.cos(t*Math.PI*2))/2;c.zoom=3+5*wave;c.yaw=.2*Math.sin(t*Math.PI*2);c.pitchBias=0;c.clampView?.();c.setViewCenter(150*Math.sin(t*Math.PI*2),-310+180*wave);c.clampView?.();}
    const m=g.frameMetrics(),id=m.renderer.renderedFrameId;if(id!==last){rows.push({now,...m});last=id;}
   }segments.push({moving,start,end:performance.now(),rows});}
   return {segments,waits:window.__validationWaitTrace,overflow:!!window.__validationWaitOverflow};
  });
  const {segments,waits,overflow}=measured;const after=await page.evaluate(()=>({tick:window.__game.tickCount(),hash:window.__game.stateHash(),stats:window.__game.stats(),camera:window.__cam.params()}));
  check('pinned population tick and state',before.tick===30&&after.tick===30&&before.hash===after.hash&&before.stats.soldiers===30560&&after.stats.soldiers===30560,{beforeTick:before.tick,afterTick:after.tick,beforeHash:before.hash,afterHash:after.hash});
  check('rendering remains active',segments.every(s=>s.rows.length>100&&s.rows.every(r=>!r.renderer.skippedFrozenFrame)),segments.map(s=>({moving:s.moving,frames:s.rows.length})));
  await page.evaluate(()=>window.__game.disposeRenderer());check('no browser errors',errors.length===0,errors);
  await writeFile(dir+'/report.json',JSON.stringify({arm,build,before,after,segments,waits,overflow,checks,errors}));console.log(arm,JSON.stringify(checks));
  if(checks.some(c=>!c.pass))throw Error(arm+' failed correctness');
 }finally{await browser?.close();server.kill('SIGTERM');await new Promise(r=>server.exitCode!==null?r():server.once('exit',r));await writeFile(dir+'/server.log',log);}
}
await writeFile(out+'/processes-after.txt',execFileSync('ps',['-axo','pid,pcpu,command']));
