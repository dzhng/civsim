import {build} from '../../web/node_modules/vite/dist/node/index.js';
import {symlink,readdir,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const main=process.cwd(),root='/Users/david/dev/game-battle-crowd-ownership',out=main+'/throwaway/crowd-ownership-hardware/candidate';
process.env.BATTLE_NATIVE_BACKEND='raw';
await build({root:root+'/web',configFile:root+'/apps/battle-perf-lab/src/live/vite.config.mts',build:{outDir:out,copyPublicDir:false}});
for(const name of await readdir(main+'/web/public')){if(name==='assets'){for(const entry of await readdir(main+'/web/public/assets'))await symlink(main+'/web/public/assets/'+entry,out+'/assets/'+entry);}else await symlink(main+'/web/public/'+name,out+'/'+name);}
await writeFile(main+'/throwaway/crowd-ownership-hardware/build-head.txt',execFileSync('git',['-C',root,'rev-parse','HEAD']));
