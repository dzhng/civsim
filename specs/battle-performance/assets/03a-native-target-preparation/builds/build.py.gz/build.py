from pathlib import Path
import subprocess,tarfile,io,json,hashlib,os,shutil
root=Path('/Users/david/dev/game-battle-performance-spec');out=root/'throwaway/native-target-build'
heads={'control':'c8580623981c3539868cf5593a34968a4b09b813','candidate':'54dae8ea'}
meta={'rustc':subprocess.check_output(['rustc','-vV'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'environment':{k:os.environ.get(k) for k in ['RUSTFLAGS','RUSTC_BOOTSTRAP','CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS']},'builds':[]}
for arm,rev in heads.items():
 head=subprocess.check_output(['git','rev-parse',rev],cwd=root,text=True).strip();source=out/(arm+'-source');source.mkdir(exist_ok=True)
 archive=subprocess.check_output(['git','archive',head,'Cargo.toml','Cargo.lock','crates'],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(source,filter='data')
 for mode in ['serial','parallel']:
  target=out/f'{arm}-{mode}-target';env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_TARGET_DIR':str(target)}
  cmd=['cargo','build','--locked','--release','-p','sim','--bin','profile_tick']+(['--features','parallel'] if mode=='parallel' else [])
  with (out/f'{arm}-{mode}.log').open('w') as log:r=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
  record={'arm':arm,'mode':mode,'sourceHead':head,'sourceArchiveSha256':hashlib.sha256(archive).hexdigest(),'command':cmd,'exit':r.returncode}
  if r.returncode==0:
   executable=out/f'{arm}-{mode}-profile_tick';shutil.copy2(target/'release/profile_tick',executable);record.update(executable=str(executable),sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),bytes=executable.stat().st_size)
  meta['builds'].append(record);(out/'builds.json').write_text(json.dumps(meta,indent=2)+'\n');print(record,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
print('COMPLETE build only; no native performance run',flush=True)
