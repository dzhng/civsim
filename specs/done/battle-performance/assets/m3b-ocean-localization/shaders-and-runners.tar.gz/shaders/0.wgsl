

struct Camera {
  // camera3d's reverse-Z perspective view-projection — the ONE projector.
  viewProj: mat4x4<f32>,
  invViewProj: mat4x4<f32>,
  // World-space eye position (vec3 padded to 16B by znear).
  eye: vec3<f32>,
  znear: f32,
  // focus — the camera's ground view centre. Consumers: distance-keyed surface
  // effects (frameShell terrain haze, water shore ramp, water glint falloff).
  focus: vec2f,
  // width/height — device-pixel viewport. Consumers: screen-space offsets and
  // NDC→pixel mapping in the label/marker shaders.
  width: f32,
  height: f32,
  // zoom — device pixels per world unit at the look target (the campaign chart
  // scale). Consumer: the campaign map's sea-shimmer zoom gate. Detail gate
  // only, never projection.
  zoom: f32,
  // tilt — sin(camera pitch): 1 = top-down chart, → 0 toward the horizon.
  // Consumer: the campaign map's sea-shimmer tilt gate.
  tilt: f32,
  // time — animation clock (seconds) for water/scenery; 0 in frozen snapshots.
  time: f32,
  // zfar — far plane distance; 0 = infinite-far sentinel.
  zfar: f32,
  // Sun azimuth/elevation (radians) — the frame's light direction.
  sunAz: f32,
  sunEl: f32,
  pad0: f32,
  pad1: f32,
};
@group(0) @binding(0) var<uniform> cam: Camera;

fn sunDirection() -> vec3f {
  let ce = cos(cam.sunEl);
  return vec3f(ce * cos(cam.sunAz), ce * sin(cam.sunAz), sin(cam.sunEl));
}


// The one projector: camera3d's real perspective projection. Writes real
// reverse-Z clip-space depth (near → 1, far → 0) against the engine-wide
// depth32float world depth buffer.
fn projectWorld(world: vec3f) -> vec4f {
  return cam.viewProj * vec4f(world, 1.0);
}

// The battle fog grading axis: signed ground distance from the view centre
// along view-forward (the eye→focus ground direction). The ground and grass
// passes ramp their distance haze against it, so ground beyond the view centre
// fades toward the horizon while the near field stays clear.
fn viewForwardDist(world: vec2f) -> f32 {
  let fwd = normalize(cam.focus - cam.eye.xy);
  return dot(world - cam.focus, fwd);
}

    struct Environment {
      worldToView:mat4x4f, observer:vec4f, sunDirection:vec4f, sunRadiance:vec4f, settings:vec4f
    };
    @group(3) @binding(0) var<uniform> environment:Environment;
    @group(3) @binding(1) var environmentSky:texture_2d<f32>;
    @group(3) @binding(2) var environmentPmrem:texture_2d<f32>;
    @group(3) @binding(3) var environmentDfg:texture_2d<f32>;
    @group(3) @binding(4) var environmentSampler:sampler;
    
    fn cubeFace(d:vec3f)->f32 {
  let a=abs(d);
  if(a.x>a.z) {
    if(a.x>a.y){return select(3.0,0.0,d.x>0.0);}
    return select(4.0,1.0,d.y>0.0);
  }
  if(a.z>a.y){return select(5.0,2.0,d.z>0.0);}
  return select(4.0,1.0,d.y>0.0);
}
fn cubeUv(d:vec3f,face:f32)->vec2f {
  var p=vec2f(0);
  if(face==0){p=vec2f(d.z,d.y)/abs(d.x);}
  else if(face==1){p=vec2f(-d.x,-d.z)/abs(d.y);}
  else if(face==2){p=vec2f(-d.x,d.y)/abs(d.z);}
  else if(face==3){p=vec2f(-d.z,d.y)/abs(d.x);}
  else if(face==4){p=vec2f(-d.x,d.z)/abs(d.y);}
  else{p=vec2f(d.x,d.y)/abs(d.z);}
  return 0.5*(p+vec2f(1));
}
fn cubeDirection(uv:vec2f,face:f32)->vec3f {
  let p=uv*2.0-vec2f(1);
  if(face==0){return vec3f(1,p.y,p.x);}
  if(face==1){return vec3f(-p.x,1,-p.y);}
  if(face==2){return vec3f(-p.x,p.y,1);}
  if(face==3){return vec3f(-1,p.y,-p.x);}
  if(face==4){return vec3f(-p.x,-1,p.y);}
  return vec3f(p.x,p.y,-1);
}
fn cubeSample(env:texture_2d<f32>,linear:sampler,d:vec3f,mip:f32,maxMip:f32)->vec3f {
  var face=cubeFace(d);
  let filterIndex=max(4.0-mip,0.0);
  let size=exp2(max(mip,4.0));
  var uv=cubeUv(d,face)*(size-2.0)+vec2f(1);
  if(face>2.0){uv.y+=size;face-=3.0;}
  uv.x+=face*size;
  uv.x+=filterIndex*48.0;
  uv.y+=4.0*(exp2(maxMip)-size);
  uv/=vec2f(textureDimensions(env));
  return textureSampleGrad(env,linear,uv,vec2f(0),vec2f(0)).rgb;
}
fn roughnessMip(r:f32)->f32 {
  if(r>=0.8){return (1.0-r)/0.2-2.0;}
  if(r>=0.4){return (0.8-r)*3.0/0.4-1.0;}
  if(r>=0.305){return (0.4-r)/0.095+2.0;}
  if(r>=0.21){return (0.305-r)/0.095+3.0;}
  return -2.0*log2(1.16*r);
}
fn samplePmrem(env:texture_2d<f32>,linear:sampler,d:vec3f,r:f32,maxMip:f32)->vec3f {
  let mip=clamp(roughnessMip(r),-2.0,maxMip);
  let f=fract(mip);
  let a=cubeSample(env,linear,d,floor(mip),maxMip);
  if(f==0){return a;}
  return mix(a,cubeSample(env,linear,d,floor(mip)+1.0,maxMip),f);
}
    fn standardPbr(base:vec3f,emissive:vec3f,authoredRoughness:f32,geometryRoughness:f32,metal:f32,ao:f32,
  n:vec3f,v:vec3f,l:vec3f,sunRadiance:vec3f,shadow:f32,environmentIntensity:f32,
  pmrem:texture_2d<f32>,linear:sampler,maxMip:f32,dfg:texture_2d<f32>,dfgSampler:sampler)->vec3f {
  let roughness=min(max(authoredRoughness,0.0525)+geometryRoughness,1.0);
  let nl=clamp(dot(n,l),0.0,1.0);
  let nv=clamp(dot(n,v),0.0,1.0);
  let h=normalize(l+v);
  let nh=clamp(dot(n,h),0.0,1.0);
  let vh=clamp(dot(v,h),0.0,1.0);
  let alpha=roughness*roughness;
  let a2=alpha*alpha;
  let fresnel=exp2((-5.55473*vh-6.98316)*vh);
  let f0=mix(vec3f(0.04),base,metal);
  let f=f0*(1.0-fresnel)+vec3f(fresnel);
  let gv=nl*sqrt(a2+(1.0-a2)*nv*nv);
  let gl=nv*sqrt(a2+(1.0-a2)*nl*nl);
  let visibility=0.5/max(gv+gl,0.000001);
  let denominator=1.0-nh*nh*(1.0-a2);
  let distribution=a2/(denominator*denominator)*0.3183098861837907;
  let singleDirect=f*visibility*distribution;
  let fabV=textureSampleLevel(dfg,dfgSampler,vec2f(roughness,nv),0.0).rg;
  let fabL=textureSampleLevel(dfg,dfgSampler,vec2f(roughness,nl),0.0).rg;
  let ssV=f0*fabV.x+vec3f(fabV.y);
  let ssL=f0*fabL.x+vec3f(fabL.y);
  let emsV=1.0-(fabV.x+fabV.y);
  let emsL=1.0-(fabL.x+fabL.y);
  let favg=f0+(vec3f(1)-f0)*0.047619;
  let directMs=ssV*ssL*favg/(vec3f(1)-emsV*emsL*favg*favg+vec3f(0.000001))*(emsV*emsL);
  let diffuseContribution=base*(1.0-metal);
  let irradiance=nl*(sunRadiance*shadow);
  let directDiffuse=irradiance*(diffuseContribution*0.3183098861837907);
  let directSpecular=irradiance*(singleDirect+directMs);

  let dielectricSs=vec3f(0.04)*fabV.x+vec3f(fabV.y);
  let dielectricAvg=vec3f(0.04)+(vec3f(1)-vec3f(0.04))*0.047619;
  let dielectricMs=dielectricSs*dielectricAvg/(vec3f(1)-emsV*dielectricAvg)*emsV;
  let metallicSs=base*fabV.x+vec3f(fabV.y);
  let metallicAvg=base+(vec3f(1)-base)*0.047619;
  let metallicMs=metallicSs*metallicAvg/(vec3f(1)-emsV*metallicAvg)*emsV;
  let singleScatter=mix(dielectricSs,metallicSs,metal);
  let multiScatter=mix(dielectricMs,metallicMs,metal);
  let diffuse=diffuseContribution*(vec3f(1)-(dielectricSs+dielectricMs));
  let reflected=normalize(mix(reflect(-v,n),n,roughness*roughness*roughness*roughness));
  let radiance=samplePmrem(pmrem,linear,vec3f(reflected.x,-reflected.y,reflected.z),roughness,maxMip)*environmentIntensity;
  let iblIrradiance=samplePmrem(pmrem,linear,vec3f(n.x,-n.y,n.z),1.0,maxMip)*3.141592653589793*environmentIntensity;
  let cosineIrradiance=iblIrradiance*0.3183098861837907;
  let aoSpecular=clamp(ao-(1.0-pow(nv+ao,exp2(-(1.0+16.0*roughness)))),0.0,1.0);
  let indirectSpecular=(radiance*singleScatter+multiScatter*cosineIrradiance)*aoSpecular;
  let indirectDiffuse=diffuse*cosineIrradiance*ao;
  return max((directDiffuse+indirectDiffuse)+(directSpecular+indirectSpecular)+emissive,vec3f(0));
}
    fn equirectUv(direction: vec3f) -> vec2f {
  return vec2f(atan2(direction.z, direction.x) * 1.5915494309189535e-1f + 0.5,
    asin(clamp(direction.y, -1.0, 1.0)) * 3.1830988618379069e-1f + 0.5);
}
    fn applyAerial(surface:vec4f,position:vec3f,camera:vec3f,observer:vec3f,lut:texture_2d<f32>,linear:sampler)->vec4f {
    let reach=position-observer;
    let distM=length(reach);
    let distKm=max(distM/1000.0-7.0000000000000007e-2f,0.0);
    let rangeDepth=pow(max(distM-7.0000000000000000e+1f,0.0)/1.7000000000000000e+3f,1.2800000000000000e+0f)*3.4000000000000002e-1f;
    let heightMist=1.0-smoothstep(8.0000000000000000e+0f,4.6000000000000000e+1f,position.z);
    let farMist=smoothstep(5.2000000000000000e+2f,1.6000000000000000e+3f,distM);
    let mistWeight=heightMist*farMist;
    let transmit=exp(-(vec3f(6.5494799999999992e-2f,1.0117240000000000e-1f,1.9106559999999997e-1f)*distKm+vec3f(rangeDepth)+vec3f(mistWeight*8.0000000000000002e-2f)));
    let view=normalize(position-camera);
    let viewSky=textureSample(lut,linear,equirectUv(view)).rgb;
    let horizonView=normalize(vec3f(view.x,view.y,4.0000000000000001e-3f));
    let horizonSky=textureSample(lut,linear,equirectUv(horizonView)).rgb;
    let below=smoothstep(-3.8000000000000000e-1f,0.0,view.z);
    let above=1.0-smoothstep(0.0,1.4000000000000001e-1f,view.z);
    let sunMie=pow(clamp(dot(view,vec3f(-9.3937271284737889e-1f,1.1503997859949083e-16f,3.4289780745545134e-1f)),0.0,1.0),3.3999999999999999e+0f)*3.4000000000000002e-1f;
    let skyLight=mix(mix(viewSky,horizonSky,below*above),vec3f(1.0000000000000000e+0f,8.0000000000000004e-1f,5.2000000000000002e-1f),sunMie);
    let mistSkyLight=mix(skyLight,vec3f(8.3999999999999997e-1f,8.1999999999999995e-1f,7.1999999999999997e-1f),mistWeight*1.7999999999999999e-1f);
    return vec4f(surface.rgb*transmit+mistSkyLight*(vec3f(1)-transmit),surface.a);
  }
    fn geometryRoughnessFromView(normalView:vec3f)->f32 {
  let n=normalize(normalView);let d=max(abs(dpdx(n)),abs(dpdy(n)));return max(max(d.x,d.y),d.z);
 }
fn geometryRoughnessWithView(normalWorld:vec3f,worldToView:mat4x4f)->f32 {
  return geometryRoughnessFromView((worldToView*vec4f(normalWorld,0)).xyz);
 }
fn shadeEnvironment(base:vec3f,emissive:vec3f,roughness:f32,geomRoughness:f32,metal:f32,ao:f32,normalWorld:vec3f,worldPosition:vec3f,shadow:f32,eye:vec3f,observer:vec3f,sunDirection:vec3f,sunRadiance:vec3f,environmentIntensity:f32,maxMip:f32,sky:texture_2d<f32>,pmrem:texture_2d<f32>,dfg:texture_2d<f32>,linear:sampler)->vec4f {
 let lit=standardPbr(base,emissive,roughness,geomRoughness,metal,ao,normalize(normalWorld),normalize(eye-worldPosition),sunDirection,sunRadiance,shadow,environmentIntensity,pmrem,linear,maxMip,dfg,linear);
 return applyAerial(vec4f(lit,1),worldPosition,eye,observer,sky,linear);
 }
    fn geometryRoughness(normalWorld:vec3f)->f32 {
      return geometryRoughnessWithView(normalWorld,environment.worldToView);
    }
    fn shadeWorldSurface(base:vec3f,emissive:vec3f,roughness:f32,geomRoughness:f32,metal:f32,ao:f32,normalWorld:vec3f,worldPosition:vec3f,shadow:f32)->vec4f {
      return shadeEnvironment(base,emissive,roughness,geomRoughness,metal,ao,normalWorld,worldPosition,shadow,cam.eye,environment.observer.xyz,environment.sunDirection.xyz,environment.sunRadiance.xyz,environment.settings.y,environment.settings.x,environmentSky,environmentPmrem,environmentDfg,environmentSampler);
    }
  fn terrainHash(p:vec2f)->f32 {
 let p3=fract(vec3f(p.x,p.y,p.x)*0.1031);
 let q=p3+dot(p3,p3.yzx+vec3f(33.33));
 return fract((q.x+q.y)*q.z);
}
fn terrainNoise(p:vec2f)->f32 {
 let i=floor(p);let f=fract(p);let u=f*f*(vec2f(3)-f*2.0);
 return mix(mix(terrainHash(i),terrainHash(i+vec2f(1,0)),u.x),mix(terrainHash(i+vec2f(0,1)),terrainHash(i+vec2f(1,1)),u.x),u.y);
}
fn terrainFbm(p:vec2f)->f32 {return terrainNoise(p)*0.52+terrainNoise(p*2.11+vec2f(4.3,1.7))*0.31+terrainNoise(p*4.07+vec2f(9.1,6.4))*0.17;}
fn terrainRidge(p:vec2f)->f32 {let r=1.0-abs(terrainNoise(p)*2.0-1.0);return r*r;}
fn terrainWaterHash(p:vec2f)->f32{return fract(sin(dot(p,vec2f(127.1,311.7)))*43758.5453);}
fn terrainWaterNoise(p:vec2f)->f32{
 let i=floor(p);let f=fract(p);let u=f*f*(vec2f(3)-f*2.0);
 return mix(mix(terrainWaterHash(i),terrainWaterHash(i+vec2f(1,0)),u.x),mix(terrainWaterHash(i+vec2f(0,1)),terrainWaterHash(i+vec2f(1,1)),u.x),u.y);
}
fn terrainLinear(c:vec3f)->vec3f{return select(pow(c*0.9478672986+vec3f(0.0521327014),vec3f(2.4)),c*0.0773993808,c<=vec3f(0.04045));}
  struct WaterState {baseZ:f32,shoreX:f32,pad:vec2f};
  @group(1) @binding(0) var<uniform> water:WaterState;
  struct WaterField {height:f32,normal:vec3f,foam:f32};
  fn waterField(p:vec2f,t:f32)->WaterField {
    var h=0.0;var slope=vec2f(0);
    
    let phase0=dot(vec2f(0.9936,0.1132),p)*0.06816952696105023-t*0.3434621896128685+1.4445185748148395;
    let hump0=sin(phase0)*0.5+0.5;
    h+=(hump0*hump0-0.333)*1.7655;
    slope+=vec2f(0.9936,0.1132)*(hump0*cos(phase0)*0.2407065996994684);
  

    let phase1=dot(vec2f(0.9157,0.4018),p)*0.07282319541029207-t*0.354992076652964+5.406467639197834;
    let hump1=sin(phase1)*0.5+0.5;
    h+=(hump1*hump1-0.333)*1.3079;
    slope+=vec2f(0.9157,0.4018)*(hump1*cos(phase1)*0.190490914554242);
  

    let phase2=dot(vec2f(0.7585,0.6517),p)*0.08923711546655305-t*0.39296742933864454+2.5043572818772324;
    let hump2=sin(phase2)*0.5+0.5;
    h+=(hump2*hump2-0.333)*1.49435;
    slope+=vec2f(0.7585,0.6517)*(hump2*cos(phase2)*0.2667029669948871);
  

    let phase3=dot(vec2f(0.4565,0.8897),p)*0.09256313052445493-t*0.40022370789657236+2.1629999741538026;
    let hump3=sin(phase3)*0.5+0.5;
    h+=(hump3*hump3-0.333)*0.8547000000000001;
    slope+=vec2f(0.4565,0.8897)*(hump3*cos(phase3)*0.1582274153185033);
  

    let phase4=dot(vec2f(0.1923,0.9813),p)*0.10633246403790828-t*0.42895993717149816+5.517105324695108;
    let hump4=sin(phase4)*0.5+0.5;
    h+=(hump4*hump4-0.333)*1.35135;
    slope+=vec2f(0.1923,0.9813)*(hump4*cos(phase4)*0.2873847505552547);
  

    let phase5=dot(vec2f(-0.0506,0.9987),p)*0.1358232879377432-t*0.4848092682732639+3.797562421550177;
    let hump5=sin(phase5)*0.5+0.5;
    h+=(hump5*hump5-0.333)*0.6534;
    slope+=vec2f(-0.0506,0.9987)*(hump5*cos(phase5)*0.1774938726770428);
  

    let phase6=dot(vec2f(-0.4173,0.9088),p)*0.16657437168610817-t*0.5368931784003809+1.8312313893253558;
    let hump6=sin(phase6)*0.5+0.5;
    h+=(hump6*hump6-0.333)*0.9740500000000001;
    slope+=vec2f(-0.4173,0.9088)*(hump6*cos(phase6)*0.32450353348170735);
  

    let phase7=dot(vec2f(-0.6739,0.7388),p)*0.1871109380583681-t*0.5690276658783798+5.700527025009868;
    let hump7=sin(phase7)*0.5+0.5;
    h+=(hump7*hump7-0.333)*0.52305;
    slope+=vec2f(-0.6739,0.7388)*(hump7*cos(phase7)*0.19573675230285886);
  

    let phase8=dot(vec2f(-0.8617,0.5075),p)*0.2278167258883249-t*0.6278799240954691+4.7868431022853235;
    let hump8=sin(phase8)*0.5+0.5;
    h+=(hump8*hump8-0.333)*0.4686;
    slope+=vec2f(-0.8617,0.5075)*(hump8*cos(phase8)*0.2135098355025381);
  

    let phase9=dot(vec2f(-0.9553,0.2958),p)*0.21923186671318912-t*0.6159360661929989+2.679924160764698;
    let hump9=sin(phase9)*0.5+0.5;
    h+=(hump9*hump9-0.333)*0.5890500000000001;
    slope+=vec2f(-0.9553,0.2958)*(hump9*cos(phase9)*0.2582770621748081);
  

    let phase10=dot(vec2f(-0.9979,-0.0648),p)*0.31321960618145567-t*0.7362211060430895+0.33144367460928875;
    let hump10=sin(phase10)*0.5+0.5;
    h+=(hump10*hump10-0.333)*0.39545;
    slope+=vec2f(-0.9979,-0.0648)*(hump10*cos(phase10)*0.2477253865289133);
  

    let phase11=dot(vec2f(-0.9303,-0.3668),p)*0.2915631229698376-t*0.7103135359046289+5.59819089683915;
    let hump11=sin(phase11)*0.5+0.5;
    h+=(hump11*hump11-0.333)*0.39435000000000003;
    slope+=vec2f(-0.9303,-0.3668)*(hump11*cos(phase11)*0.22995583508631093);
  

    let phase12=dot(vec2f(-0.7647,-0.6444),p)*0.36466542658154383-t*0.7943850993394428+1.5282420422747962;
    let hump12=sin(phase12)*0.5+0.5;
    h+=(hump12*hump12-0.333)*0.43010000000000004;
    slope+=vec2f(-0.7647,-0.6444)*(hump12*cos(phase12)*0.313685199945444);
  

    let phase13=dot(vec2f(-0.5166,-0.8563),p)*0.39943962492053403-t*0.8313987490314052+5.5949659313329345;
    let hump13=sin(phase13)*0.5+0.5;
    h+=(hump13*hump13-0.333)*0.33385000000000004;
    slope+=vec2f(-0.5166,-0.8563)*(hump13*cos(phase13)*0.2667058375594406);
  

    let phase14=dot(vec2f(-0.2276,-0.9737),p)*0.4180429341317366-t*0.8505390107620132+0.4345941566544691;
    let hump14=sin(phase14)*0.5+0.5;
    h+=(hump14*hump14-0.333)*0.40095000000000003;
    slope+=vec2f(-0.2276,-0.9737)*(hump14*cos(phase14)*0.3352286288802396);
  

    let phase15=dot(vec2f(0.1505,-0.9886),p)*0.5691291032608696-t*0.9924055658486013+5.530018165763443;
    let hump15=sin(phase15)*0.5+0.5;
    h+=(hump15*hump15-0.333)*0.30360000000000004;
    slope+=vec2f(0.1505,-0.9886)*(hump15*cos(phase15)*0.3455751915000001);
  

    let phase16=dot(vec2f(0.4309,-0.9024),p)*0.6734389389067524-t*1.0795255016696514+0.6440417181639329;
    let hump16=sin(phase16)*0.5+0.5;
    h+=(hump16*hump16-0.333)*0.33;
    slope+=vec2f(0.4309,-0.9024)*(hump16*cos(phase16)*0.4444696996784566);
  

    let phase17=dot(vec2f(0.5983,-0.8013),p)*0.7059758764044944-t*1.1052963215825677+5.087161441303587;
    let hump17=sin(phase17)*0.5+0.5;
    h+=(hump17*hump17-0.333)*0.2651;
    slope+=vec2f(0.5983,-0.8013)*(hump17*cos(phase17)*0.37430840966966294);
  

    let phase18=dot(vec2f(0.8359,-0.5488),p)*0.7699981985294118-t*1.154326454077862+6.0900466283169115;
    let hump18=sin(phase18)*0.5+0.5;
    h+=(hump18*hump18-0.333)*0.29590000000000005;
    slope+=vec2f(0.8359,-0.5488)*(hump18*cos(phase18)*0.45568493388970593);
  

    let phase19=dot(vec2f(0.9869,-0.1611),p)*0.9119282002902759-t*1.2562154113650723+1.7528584445014586;
    let hump19=sin(phase19)*0.5+0.5;
    h+=(hump19*hump19-0.333)*0.27280000000000004;
    slope+=vec2f(0.9869,-0.1611)*(hump19*cos(phase19)*0.4975480260783746);
  
    let crest=smoothstep(0.28600000000000003,0.8525000000000001,h);
    let agitation=smoothstep(0.12,0.58,dot(slope,slope));
    let speckle=terrainWaterNoise(p*0.5+vec2f(t*0.1,t*0.05))*0.42+terrainWaterNoise(p*1.3-vec2f(t*0.06,t*0.09))*0.34+terrainWaterNoise(p*3.0+vec2f(t*0.04,t*(-0.07)))*0.24;
    return WaterField(h,normalize(vec3f(-slope,1)),crest*agitation*smoothstep(0.56,0.78,speckle)*0.74);
  }
  struct VertexOut {@invariant @builtin(position) clip:vec4f,@location(0) position:vec3f,@location(1) shore:f32};
  @vertex fn vertex(@location(0) p:vec3f,@location(1) shore:f32)->VertexOut {
    let position=vec3f(p.xy,waterField(p.xy,cam.time).height*1.0+water.baseZ);
    return VertexOut(projectWorld(position),position,shore);
  }
  @fragment fn fragment(v:VertexOut)->@location(0) vec4f {
    let p=v.position.xy;
    let sample=waterField(p,cam.time);
    let viewDist=length(p-cam.focus);
    
    let shore=abs(p.x-water.shoreX);
    let depth01=smoothstep(12.0,300.0,shore);
    let turbidity=smoothstep(0.04,0.26,depth01);
    let agitation=smoothstep(0.0,3200.0,shore);
    let foam=clamp(sample.foam*agitation,0.0,1.0);
    let strength=mix(0.3,1.0,agitation)*mix(0.84,0.18,smoothstep(720.0,2300.0,viewDist));
    
    let normal=normalize(mix(vec3f(0,0,1),sample.normal,strength));
    let shallow=mix(vec3f(0.66,0.58,0.4),vec3f(0.22,0.58,0.6),turbidity);
    let albedo=terrainLinear(mix(mix(shallow,vec3f(0.025,0.095,0.22),depth01),vec3f(0.92,0.93,0.94),foam));
    let roughness=mix(0.105,0.78,foam);
    return shadeWorldSurface(albedo,vec3f(0),roughness,0.0,0.0,1.0,normal,v.position,1.0);
  }