import{build}from'../../web/node_modules/vite/dist/node/index.js';
const root=process.cwd();let changed=false;
await build({configFile:root+'/apps/battle-perf-lab/src/raw/water.vite.config.mts',build:{outDir:root+'/throwaway/ocean-residual-review/normals',copyPublicDir:false},plugins:[{name:'localize-hdr-comparison',enforce:'pre',transform(code,id){
if(id.endsWith('/packages/photoreal-renderer/src/battle/seaLayer.ts')) {
 const target='  material.roughnessNode = surface.roughness;';
 if(code.split(target).length!==2)throw Error('Expected one ocean surface');
 return code.replace(target,target+'\n  material.fragmentNode = vec4(surfaceNormal.mul(0.5).add(0.5), 1.0);\n  material.fog = false;');
}
if(id.endsWith('/packages/battle-renderer/src/shaders/water.ts')) {
 const target='return shadeWorldSurface(albedo,vec3f(0),roughness,0.0,0.0,1.0,normal,v.position,1.0);';
 if(!code.includes(target))throw Error('Expected water shading return');
 return code.replace(target,'return vec4f(normal*0.5+vec3f(0.5),1.0);');
}
if(!id.endsWith('/apps/battle-perf-lab/src/numericalReadback.ts'))return;const targets=['  let maxAbs = 0,','    maxAbs = Math.max(maxAbs, difference);','    maxRelative,\n    rmse:'];for(const target of targets)if(!code.includes(target))throw Error('Missing instrumentation target '+target);changed=true;return code.replace(targets[0],'  let maxAbsIndex = -1;\n  let maxAbs = 0,').replace(targets[1],'    if (difference > maxAbs) { maxAbs = difference; maxAbsIndex = i; }').replace(targets[2],'    maxAbsIndex,\n    maxAbsActual: actual[maxAbsIndex] ?? null,\n    maxAbsExpected: expected[maxAbsIndex] ?? null,\n    maxRelative,\n    rmse:');}}]});if(!changed)throw Error('Instrumentation did not run');
