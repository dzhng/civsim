import{build}from'../../web/node_modules/vite/dist/node/index.js';import{symlink,readdir}from'node:fs/promises';import{execFileSync}from'node:child_process';
const root=process.cwd(),out=root+'/throwaway/current-camera-review';
const old=new Map(['packages/photoreal-renderer/src/battle/battleWorld.ts','apps/battle-perf-lab/src/raw/scene-check.ts'].map(p=>[root+'/'+p,execFileSync('git',['show','7afb39cf:'+p],{encoding:'utf8'})]));
for(const mode of ['source-floor','scene-control','scene-candidate']){
 await build({...(mode==='source-floor'?{root:root+'/web'}:{}),configFile:root+(mode==='source-floor'?'/web/vite.config.ts':'/apps/battle-perf-lab/src/raw/scene.vite.config.mts'),plugins:mode==='scene-control'?[{name:'immutable-pre-camera-control',enforce:'pre',load(id){return old.get(id.split('?')[0]);}}]:[],build:{outDir:out+'/'+mode,copyPublicDir:false}});
 for(const name of await readdir(root+'/web/public')){if(name==='assets'){for(const entry of await readdir(root+'/web/public/assets'))await symlink(root+'/web/public/assets/'+entry,out+'/'+mode+'/assets/'+entry);}else await symlink(root+'/web/public/'+name,out+'/'+mode+'/'+name);}
}
